import SwiftUI

struct NotificationsView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var trendsEnabled = false
    @State private var newHealthRecordsEnabled = true
    @State private var showHealthChecklist = false
    
    var body: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 20) {
                Toggle(isOn: $trendsEnabled) {
                    VStack(alignment: .leading) {
                        Text("Trends")
                            .font(.headline)
                        Text("Receive a notification when there’s a new trend in your Health data.")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                }
                .padding()
                .background(RoundedRectangle(cornerRadius: 10).fill(Color(UIColor.systemBackground)))
                .shadow(radius: 1)
                
                Toggle(isOn: $newHealthRecordsEnabled) {
                    VStack(alignment: .leading) {
                        Text("New Health Records")
                            .font(.headline)
                        Text("Receive a notification when new health records like lab results or medications are downloaded from one of your accounts.")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                }
                .padding()
                .background(RoundedRectangle(cornerRadius: 10).fill(Color(UIColor.systemBackground)))
                .shadow(radius: 1)
                
                Button(action: {
                    showHealthChecklist = true
                }) {
                    Text("View More in Health Checklist")
                        .foregroundColor(.blue)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(RoundedRectangle(cornerRadius: 10).fill(Color(UIColor.systemBackground)))
                        .shadow(radius: 1)
                        .sheet(isPresented: $showHealthChecklist) {
                            HealthChecklistView()
                        }
                }
                
                Text("Health features and their notifications can also be managed in Health Checklist.")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .padding(.horizontal)
                
                Spacer()
            }
            .padding()
            .navigationTitle("Notifications")
            .navigationBarItems(leading:HStack {
                Image(systemName: "chevron.left")
                    .foregroundColor(.blue)
                    Button("Profile") {
                        presentationMode.wrappedValue.dismiss()
                    }
                .foregroundColor(.blue)
                }, trailing: Button("Done", action: {
                presentationMode.wrappedValue.dismiss()
            }))
        }
    }
}

struct NotificationsView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            NotificationsView()
                .preferredColorScheme(.light)
            
            NotificationsView()
                .preferredColorScheme(.dark)
        }
    }
}
