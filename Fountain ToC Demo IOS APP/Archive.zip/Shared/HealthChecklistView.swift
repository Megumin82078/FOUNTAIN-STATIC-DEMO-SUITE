import SwiftUI

struct HealthChecklistView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var showWalletCard = false
    @State private var showNotifications = false
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // 顶部图标
                    Image(systemName: "checkmark.seal.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 80, height: 80)
                        .foregroundColor(.red)
                        .padding(.top, 20)
                    
                    // 标题与描述
                    Text("Health Checklist")
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    Text("Set up your iPhone to keep an eye on things for you.")
                        .font(.body)
                        .foregroundColor(.gray)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 20)
                    
                    Text("The following reflect the settings of \"iOS Simulator\".")
                        .font(.footnote)
                        .foregroundColor(.gray)
                        .multilineTextAlignment(.center)
                    
                    // Inactive Section
                    SectionView(title: "Inactive") {
                        Button(action: {
                            // 关闭当前视图
                            // presentationMode.wrappedValue.dismiss()
                            
                            // 延迟一小段时间后显示 WalletCardView
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                                showWalletCard = true
                            }
                        }) {
                            ChecklistItemView(
                                icon: "staroflife.fill", 
                                iconColor: .red, 
                                title: "Fountain Card", 
                                description: "Fountain Card gives first responders vital information in an emergency.", 
                                linkText: "Set Up"
                            )
                        }
                    }
                    
                    // Active Section
                    SectionView(title: "Active") {
                        Button(action: {
                            // 关闭当前视图
                            // presentationMode.wrappedValue.dismiss()
                            
                            // 延迟一小段时间后显示 NotificationsView
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                                showNotifications = true
                            }
                        }) {
                            ChecklistItemView(
                                icon: "speaker.wave.2.fill", 
                                iconColor: .red, 
                                title: "Headphone Notifications", 
                                description: "Notifications are on. You'll receive a notification if you've been listening to loud headphone audio for long enough to affect your hearing.", 
                                isLink: false
                            )
                        }
                    }
                    
                    // Unavailable Section
                    // SectionView(title: "Unavailable") {
                    //     ChecklistItemView(icon: "sos.circle.fill", iconColor: .pink, title: "Emergency SOS", description: "Emergency SOS is not available on this device.", linkText: "Learn more...")
                    //     ChecklistItemView(icon: "figure.walk", iconColor: .yellow, title: "Walking Steadiness Notifications", description: "Your height has to be added to Health to enable this feature.", isLink: false)
                    // }
                }
                .padding(.bottom, 20)
            }
            .navigationBarTitle("Health Checklist", displayMode: .inline)
            .navigationBarItems(leading: Button(action: {
                // 返回操作
                presentationMode.wrappedValue.dismiss()
            }) {
                HStack {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.blue)
                     Button("Profile") {
                        presentationMode.wrappedValue.dismiss()
                    }
                        .foregroundColor(.blue)
                }
            }, trailing: Button("Done") {
                // 完成操作
                presentationMode.wrappedValue.dismiss()
            })
        }
        .sheet(isPresented: $showWalletCard) {
            WalletCardView()
        }
        .sheet(isPresented: $showNotifications) {
            NotificationsView()
        }
    }
}

struct SectionView<Content: View>: View {
    let title: String
    let content: Content
    
    init(title: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.content = content()
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title)
                .font(.headline)
                .fontWeight(.bold)
                .padding(.horizontal, 20)
            content
        }
    }
}

struct ChecklistItemView: View {
    let icon: String
    let iconColor: Color
    let title: String
    let description: String
    let linkText: String?
    let isLink: Bool
    
    init(icon: String, iconColor: Color, title: String, description: String, linkText: String? = nil, isLink: Bool = true) {
        self.icon = icon
        self.iconColor = iconColor
        self.title = title
        self.description = description
        self.linkText = linkText
        self.isLink = isLink
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack(spacing: 15) {
                Image(systemName: icon)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 30, height: 30)
                    .foregroundColor(iconColor)
                
                VStack(alignment: .leading, spacing: 2) {
                    Text(title)
                        .font(.headline)
                        .fontWeight(.bold)
                    
                    Text(description)
                        .font(.body)
                        .foregroundColor(.gray)
                        .fixedSize(horizontal: false, vertical: true)
                    
                    if let linkText = linkText, isLink {
                        Text(linkText)
                            .font(.body)
                            .foregroundColor(.blue)
                    }
                }
                Spacer()
                if !isLink {
                    Image(systemName: "chevron.right")
                        .foregroundColor(.gray)
                }
            }
            .padding()
            .background(Color(UIColor.systemBackground))
            .cornerRadius(12)
            .shadow(radius: 2)
        }
        .padding(.horizontal, 20)
    }
}

struct HealthChecklistView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            HealthChecklistView()
                .preferredColorScheme(.light)
            HealthChecklistView()
                .preferredColorScheme(.dark)
        }
    }
}
