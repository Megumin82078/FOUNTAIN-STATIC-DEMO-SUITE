import SwiftUI

struct MindfulnessDetailView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) private var colorScheme
    
    // 当前时间
    @State private var currentTime = "16:39"
    
    // 正念分钟数
    @State private var mindfulMinutes = 1
    
    // 根据当前主题获取背景色
    var backgroundColor: Color {
        colorScheme == .dark ? Color.black : Color.white
    }
    
    // 根据当前主题获取文本颜色
    var textColor: Color {
        colorScheme == .dark ? Color.white : Color.black
    }
    
    // 根据当前主题获取卡片背景色
    var cardBackgroundColor: Color {
        colorScheme == .dark ? Color(UIColor.systemGray6).opacity(0.4) : Color(UIColor.systemGray6).opacity(0.5)
    }
    
    // 根据当前主题获取分割线颜色
    var dividerColor: Color {
        colorScheme == .dark ? Color.gray.opacity(0.3) : Color.gray.opacity(0.2)
    }
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                // 自定义导航栏
                HStack {
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        HStack(spacing: 5) {
                            Image(systemName: "chevron.left")
                                .foregroundColor(Color.blue)
                                .font(.system(size: 16, weight: .semibold))
                            Text("Browse")
                                .foregroundColor(Color.blue)
                                .font(.system(size: 17))
                        }
                    }
                    
                    Spacer()
                }
                .padding(.horizontal)
                .padding(.top, 10)
                .padding(.bottom, 20)
                
                // 标题
                Text("Mindfulness")
                    .font(.system(size: 34, weight: .bold))
                    .foregroundColor(textColor)
                    .padding(.horizontal)
                    .padding(.bottom, 10)
                
                // 今天
                Text("Today")
                    .font(.system(size: 20))
                    .foregroundColor(Color.gray)
                    .padding(.horizontal)
                    .padding(.bottom, 20)
                
                // 正念分钟数卡片
                VStack(spacing: 0) {
                    NavigationLink(destination: MindfulnessMinutesView()) {
                        HStack(spacing: 12) {
                            // 图标
                            ZStack {
                                Circle()
                                    .fill(Color.teal.opacity(0.2))
                                    .frame(width: 32, height: 32)
                                
                                Image(systemName: "snowflake")
                                    .foregroundColor(Color.teal)
                                    .font(.system(size: 16))
                            }
                            
                            Text("Mindfulness Minutes")
                                .foregroundColor(textColor)
                                .font(.system(size: 17))
                            
                            Spacer()
                            
                            Text(currentTime)
                                .foregroundColor(Color.gray)
                                .font(.system(size: 15))
                                .padding(.trailing, 4)
                            
                            Image(systemName: "chevron.right")
                                .foregroundColor(Color(UIColor.systemGray4))
                                .font(.system(size: 14))
                        }
                        .padding(.vertical, 12)
                        .padding(.horizontal)
                    }
                    .buttonStyle(PlainButtonStyle())
                    
                    Divider()
                        .background(dividerColor)
                        .padding(.leading, 60)
                    
                    // 分钟数显示
                    HStack(alignment: .firstTextBaseline, spacing: 2) {
                        Text("\(mindfulMinutes)")
                            .font(.system(size: 48, weight: .regular))
                            .foregroundColor(textColor)
                        
                        Text("min")
                            .font(.system(size: 20))
                            .foregroundColor(textColor)
                            .padding(.leading, 2)
                            .padding(.top, 4)
                        
                        Spacer()
                    }
                    .padding(.top, 16)
                    .padding(.bottom, 20)
                    .padding(.horizontal)
                }
                .background(cardBackgroundColor)
                .cornerRadius(16)
                .padding(.horizontal)
                .shadow(color: Color.black.opacity(0.05), radius: 1, x: 0, y: 1)
                
                // 空白区域，占据剩余空间
                Spacer(minLength: 500)
            }
        }
        .background(backgroundColor.edgesIgnoringSafeArea(.all))
        .navigationBarHidden(true)
        .onAppear {
            // 获取当前时间
            let formatter = DateFormatter()
            formatter.dateFormat = "HH:mm"
            currentTime = formatter.string(from: Date())
        }
    }
}

struct MindfulnessDetailView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            MindfulnessDetailView()
                .preferredColorScheme(.dark)
                .previewDisplayName("Dark Mode")
            
            MindfulnessDetailView()
                .preferredColorScheme(.light)
                .previewDisplayName("Light Mode")
        }
    }
}
