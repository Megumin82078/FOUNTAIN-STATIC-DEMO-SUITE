import SwiftUI

struct AddMedicationView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) private var colorScheme
    @State private var medicationName: String = ""
    @State private var navigateToSelectType = false
    @State private var showAddSpecificationView = false


    // MARK: - Theme Colors (Fixed)
    private var backgroundColor: Color {
        colorScheme == .dark ? Color.black : Color.white
    }
    
    private var textColor: Color {
        colorScheme == .dark ? Color.white : Color.black
    }
    
    private var textFieldBackground: Color {
        colorScheme == .dark ? Color(red: 0.17, green: 0.17, blue: 0.18) : Color(.systemGray6)
    }
    
    private var buttonBackground: Color {
        colorScheme == .dark ? Color(red: 0.17, green: 0.17, blue: 0.18) : Color(.systemGray5)
    }

    var body: some View {
        NavigationView {
            VStack(spacing: 24) {
                // 导航头
                HStack {
                    Button("Cancel") {
                        presentationMode.wrappedValue.dismiss()
                    }
                    .foregroundColor(.blue)
                    Spacer()
                }
                .padding(.horizontal)
                .padding(.top, 20)

                // 药品图标
                ZStack {
                    Capsule()
                        .fill(Color.blue.opacity(0.8))
                        .frame(width: 60, height: 30)
                        .rotationEffect(.degrees(-30))
                        .offset(x: -30)
                    
                    Circle()
                        .fill(Color.cyan.opacity(0.7))
                        .frame(width: 40)
                        .offset(x: 20, y: -10)
                    
                    Circle()
                        .fill(Color.pink.opacity(0.7))
                        .frame(width: 50)
                        .offset(x: 10, y: 30)
                }
                .frame(width: 120, height: 120)
                
                // 输入区域
                VStack(spacing: 16) {
                    Text("Drug Name")
                        .font(.title2).bold()
                    
                    TextField("Add Drug Name", text: $medicationName)
                        .padding()
                        .background(textFieldBackground)
                        .cornerRadius(8)
                }
                .padding(.horizontal)
                
                Spacer()
                
                // 下一步按钮
                Button(action: { showAddSpecificationView = true }) {
                    Text("Next Step")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(medicationName.isEmpty ? buttonBackground : Color.blue)
                        .foregroundColor(medicationName.isEmpty ? .gray : .white)
                        .cornerRadius(8)
                }
                .disabled(medicationName.isEmpty)
                .padding(.horizontal)
                .sheet(isPresented: $showAddSpecificationView) {
                    AddMedicationSpecificationView(medicationName: "Ggg", medicationType: "胶囊")
                }
            }
            .background(backgroundColor)
            .navigationBarHidden(true)
        }
    }
}

// 预览
struct AddMedicationView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            AddMedicationView()
                .preferredColorScheme(.dark)
            
            AddMedicationView()
                .preferredColorScheme(.light)
        }
    }
}