import SwiftUI

struct MedicalIDView: View {
    @Environment(\.presentationMode) var presentationMode
    var body: some View {
        NavigationView {
            VStack {
                Spacer()
                
                // 卡片视图
                VStack {
                    Image(systemName: "staroflife.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 80, height: 80)
                        .foregroundColor(.red)
                        .padding(.top, 30)
                    
                    Text("Set Up Your Medical ID")
                        .font(.title3)
                        .fontWeight(.bold)
                        .padding(.top, 10)
                    
                    Text("In an emergency, first responders can look at your Medical ID to get life-saving information.")
                        .font(.body)
                        .foregroundColor(.gray)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 20)
                        .padding(.top, 5)
                    
                    Button(action: {
                        // 按钮操作
                    }) {
                        Text("Get Started")
                            .font(.headline)
                            .frame(maxWidth: .infinity, minHeight: 50)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .padding(.horizontal, 20)
                            .padding(.bottom, 30)
                    }
                }
                .background(Color(UIColor.systemBackground))
                .cornerRadius(15)
                .shadow(radius: 5)
                .padding(.horizontal, 20)
                
                Spacer()
            }
            .navigationBarTitle("Medical ID", displayMode: .inline)
            .navigationBarItems(leading: Button(action: {
                // 返回操作
            }) {
                HStack {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.blue)
                    Button("Profile") {
                        presentationMode.wrappedValue.dismiss()
                    }
                        .foregroundColor(.blue)
                }
            })
        }
    }
}

struct MedicalIDView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            MedicalIDView()
                .preferredColorScheme(.light)
            MedicalIDView()
                .preferredColorScheme(.dark)
        }
    }
}
