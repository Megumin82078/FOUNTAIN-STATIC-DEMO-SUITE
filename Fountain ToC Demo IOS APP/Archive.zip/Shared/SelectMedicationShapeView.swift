import SwiftUI

struct SelectMedicationShapeView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) private var colorScheme
    
    let medicationName: String
    let specification: String
    @State private var selectedShape: Int? = nil
    @State private var showSelectColorView = false

    
    // 主题适配颜色
    private var backgroundColor: Color {
        colorScheme == .dark ? Color.black : Color.white
    }
    
    private var textColor: Color {
        colorScheme == .dark ? Color.white : Color.black
    }
    
    private var secondaryTextColor: Color {
        colorScheme == .dark ? Color.gray : Color.gray.opacity(0.8)
    }
    
    private var buttonBackground: Color {
        colorScheme == .dark ? Color.blue : Color.blue
    }
    
    private var shapeSelectionColor: Color {
        colorScheme == .dark ? Color.white : Color.blue
    }
    
    // 药品形状图片名称数组
    let shapeImages = [
        "pill_capsule", "pill_round", "pill_oval", "pill_oblong",
        "pill_bottle", "pill_container", "pill_cup", "pill_tube",
        "pill_diamond", "pill_square", "pill_triangle", "pill_irregular"
    ]
    
    var body: some View {
        ZStack {
            backgroundColor.edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 0) {
                // 导航栏
                HStack {
                    Button(action: dismiss) {
                        HStack(spacing: 2) {
                            Image(systemName: "chevron.left")
                            Text("Back")
                        }
                        .foregroundColor(.blue)
                        .font(.system(size: 17))
                    }
                    
                    Spacer()
                    
                    Text(medicationName)
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundColor(textColor)
                    
                    Spacer()
                    
                    Button("Cancel", action: dismiss)
                        .foregroundColor(.blue)
                        .font(.system(size: 17))
                }
                .padding([.horizontal, .top])
                .padding(.bottom, 8)
                
                Text("Capsule, \(specification)")
                    .font(.system(size: 15))
                    .foregroundColor(secondaryTextColor)
                    .padding(.bottom, 20)
                
                // 药品图标
                ZStack {
                    Circle()
                        .fill(secondaryTextColor.opacity(0.3))
                        .frame(width: 120, height: 120)
                    
                    Image(systemName: "pill.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 50, height: 50)
                        .foregroundColor(textColor)
                }
                .padding(.bottom, 20)
                
                // 标题
                Text("Select Shape")
                    .font(.system(size: 28, weight: .bold))
                    .foregroundColor(textColor)
                    .padding(.bottom, 30)
                
                // 药品形状网格
                ScrollView {
                    VStack(spacing: 20) {
                        shapeGrid(0..<4)
                        shapeGrid(4..<8)
                        
                        // 更多标签
                        HStack {
                            Text("More")
                                .font(.system(size: 20, weight: .bold))
                                .foregroundColor(textColor)
                                .padding(.leading, 5)
                                .padding(.vertical, 10)
                            Spacer()
                        }
                        
                        shapeGrid(8..<12)
                    }
                    .padding(.horizontal)
                }
                
                Spacer()
                
                // 底部按钮
                VStack(spacing: 10) {
                    Button("Next Step", action: {
                        showSelectColorView = true
                    })
                    .mainButtonStyle(isEnabled: selectedShape != nil)
                    .sheet(isPresented: $showSelectColorView) {
                        SelectMedicationColorView(
                            medicationName: "Ggg", 
                            specification: "5 milligram",
                            medicationShape: "capsule"
                        )
                    }
                    
                    Button("Skip", action: dismiss)
                        .foregroundColor(.blue)
                        .padding(.bottom, 30)
                }
            }
        }
        .navigationBarHidden(true)
    }
    
    // MARK: - Helper Methods
    private func dismiss() {
        presentationMode.wrappedValue.dismiss()
    }
    
    private func proceedNext() {
        // 处理下一步操作
    }
    
    private func shapeGrid(_ range: Range<Int>) -> some View {
        HStack(spacing: 15) {
            ForEach(range, id: \.self) { index in
                shapeButton(index: index)
            }
        }
    }
    
    // 药品形状按钮
    private func shapeButton(index: Int) -> some View {
        Button(action: { selectedShape = index }) {
            ZStack {
                Circle()
                    .fill(buttonBackground)
                    .frame(width: 80, height: 80)
                
                shapeIcon(for: index)
                    .foregroundColor(textColor)
            }
            .overlay(
                Circle()
                    .stroke(selectedShape == index ? shapeSelectionColor : Color.clear, lineWidth: 3)
            )
        }
    }
    
    @ViewBuilder
    private func shapeIcon(for index: Int) -> some View {
        switch index {
        case 0:
            Image(systemName: "capsule.fill")
                .resizable()
                .scaledToFit()
                .frame(width: 50, height: 30)
        case 1:
            Image(systemName: "circle.fill")
                .resizable()
                .scaledToFit()
                .frame(width: 40, height: 40)
        case 4:
            Image(systemName: "cube.box.fill")
                .resizable()
                .scaledToFit()
                .frame(width: 40, height: 40)
        default:
            Image(systemName: "pill")
                .resizable()
                .scaledToFit()
                .frame(width: 40, height: 40)
        }
    }
}

// MARK: - 样式扩展
extension View {
    func mainButtonStyle(isEnabled: Bool) -> some View {
        self
            .font(.system(size: 17, weight: .medium))
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .fill(isEnabled ? Color.blue : Color.gray)
            )
            .padding(.horizontal)
    }
}

// MARK: - 预览
struct SelectMedicationShapeView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            SelectMedicationShapeView(medicationName: "Sample", specification: "5mg")
                .preferredColorScheme(.dark)
            
            SelectMedicationShapeView(medicationName: "Sample", specification: "5mg")
                .preferredColorScheme(.light)
        }
    }
}
