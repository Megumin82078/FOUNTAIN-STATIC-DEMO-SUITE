import SwiftUI

struct BladderIncontinenceView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.presentationMode) var presentationMode

    // Time range selection
    private let timeRanges = ["Day", "Week", "Month", "6 Months", "Year"]
    @State private var selectedTimeRange = 0

    // Y-axis labels
    private let yAxisLabels = ["Severe", "Moderate", "Mild", "Occurring", "Not Occurring"]

    var body: some View {
        // Content without any navigation containers
        VStack(spacing: 0) {
            // Custom navigation bar
            customNavigationBar
            
            ScrollView {
                VStack(spacing: 0) {
                    // Time range selector
                    timeRangeSelector
                        .padding(.horizontal, 16)
                        .padding(.top, 16)

                    // No data displayed
                    VStack(alignment: .leading, spacing: 8) {
                        Text("No Data")
                            .font(.system(size: 34, weight: .bold))
                            .foregroundColor(colorScheme == .dark ? .white : .black)

                        Text("March 2025")
                            .font(.system(size: 17))
                            .foregroundColor(.gray)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 16)
                    .padding(.top, 20)

                    // Chart
                    chartView
                        .padding(.top, 20)

                    // About Bladder Incontinence
                    aboutSection
                        .padding(.top, 40)
                        .padding(.horizontal, 16)
                        .padding(.bottom, 40)
                }
            }
        }
        .background(Color(colorScheme == .dark ? .black : .white).ignoresSafeArea())
        // This is critical - it tells SwiftUI to not use the default navigation bar
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
    }

    // Custom navigation bar
    private var customNavigationBar: some View {
        HStack {
            Button(action: { 
                // Use both dismiss methods to ensure it works in different contexts
                dismiss()
                presentationMode.wrappedValue.dismiss()
            }) {
                HStack(spacing: 2) {
                    Image(systemName: "chevron.left")
                    Text("Symptoms")
                }
                .foregroundColor(.blue)
                .font(.system(size: 17))
            }

            Spacer()

            Text("Bladder Incontinence")
                .font(.system(size: 17))
                .foregroundColor(colorScheme == .dark ? .white : .black)

            Spacer()

            Button("Add Data") {
                // Add data action
            }
            .font(.system(size: 17))
            .foregroundColor(.blue)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color(colorScheme == .dark ? UIColor.systemGray6 : UIColor.systemGray5).opacity(0.8))
        .overlay(Divider(), alignment: .bottom)
    }

    // Time range selector
    private var timeRangeSelector: some View {
        HStack(spacing: 0) {
            ForEach(Array(timeRanges.enumerated()), id: \.offset) { index, range in
                Button(action: { selectedTimeRange = index }) {
                    Text(range)
                        .font(.system(size: 17))
                        .foregroundColor(selectedTimeRange == index ? .white : (colorScheme == .dark ? .gray : .black))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                        .background(selectedTimeRange == index ?
                            Color(UIColor.systemGray5) : Color.clear)
                }
            }
        }
        .background(colorScheme == .dark ? Color(UIColor.systemGray6) : Color(UIColor.systemGray5))
        .cornerRadius(8)
    }

    // Chart
    private var chartView: some View {
        VStack(alignment: .leading, spacing: 0) {
            ForEach(yAxisLabels, id: \.self) { label in
                HStack(alignment: .center, spacing: 8) {
                    Text(label)
                        .font(.system(size: 13))
                        .foregroundColor(colorScheme == .dark ? .white : .black)
                        .frame(width: 100, alignment: .leading)
                        .padding(.leading, 16)

                    Rectangle()
                        .fill(colorScheme == .dark ? Color.gray.opacity(0.2) : Color.black.opacity(0.1))
                        .frame(height: 1)
                }
                .frame(height: 44)
            }

            // X-axis time labels
            HStack(spacing: 0) {
                Text("0:00")
                Spacer()
                Text("6:00")
                Spacer()
                Text("12:00")
                Spacer()
                Text("18:00")
            }
            .font(.system(size: 13))
            .foregroundColor(colorScheme == .dark ? .white : .black)
            .padding(.leading, 116)
            .padding(.trailing, 16)
            .padding(.top, 4)
        }
    }

    // About section
    private var aboutSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("About Bladder Incontinence")
                .font(.system(size: 22, weight: .bold))
                .foregroundColor(colorScheme == .dark ? .white : .black)

            VStack(alignment: .leading, spacing: 16) {
                Text("Bladder incontinence refers to the loss of bladder control leading to leakage of urine. It can range from the sudden urge to urinate caused by coughing, laughing, or sneezing to occasional leakage of urine.")
                    .fixedSize(horizontal: false, vertical: true)

                Text("Bladder incontinence may restrict activity and social interactions and can be a sign of urinary tract infections or bladder health issues.")
                    .fixedSize(horizontal: false, vertical: true)

                Text("Bladder muscles weaken over time, so incontinence is more common in older adults.")
                    .fixedSize(horizontal: false, vertical: true)
            }
            .font(.system(size: 17))
            .foregroundColor(.gray)
            .padding(16)
            .background(colorScheme == .dark ? Color(UIColor(red: 28/255, green: 28/255, blue: 30/255, alpha: 1)) : Color(UIColor(red: 240/255, green: 240/255, blue: 240/255, alpha: 1)))
            .cornerRadius(10)
        }
    }

    // About card with articles
    private var aboutCardView: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("About Respiratory")
                .font(.system(size: 22, weight: .bold))
                .foregroundColor(colorScheme == .dark ? .white : .black)
            
            // First article card
            ArticleCard(
                title: "Learn About Blood Oxygen Levels",
                subtitle: "What they mean and why they're important to your health.",
                gradientColors: [
                    Color(red: 0.85, green: 0.4, blue: 0.3),  // Red
                    Color(red: 0.4, green: 0.6, blue: 0.9),   // Blue
                    Color(red: 0.7, green: 0.85, blue: 0.9)   // Light blue
                ]
            )
            
            // Second article card
            ArticleCard(
                title: "What it Means if Your Cardio Fitness Is Low",
                subtitle: "And what you can do about it.",
                image: Image("cardio_fitness") // You'll need to add this image to your assets
            )
        }
    }

    // Article card component
    struct ArticleCard: View {
        let title: String
        let subtitle: String
        var gradientColors: [Color]? = nil
        var image: Image? = nil
        
        var body: some View {
            VStack(alignment: .leading, spacing: 8) {
                if let colors = gradientColors {
                    // Gradient wave background
                    ZStack {
                        LinearGradient(
                            colors: colors,
                            startPoint: .topTrailing,
                            endPoint: .bottomLeading
                        )
                        .frame(height: 200)
                        
                        // Wave shapes overlay
                        WaveShapesOverlay()
                    }
                    .frame(height: 200)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                } else if let img = image {
                    // Image background
                    img
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(height: 200)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(.system(size: 20, weight: .bold))
                        .foregroundColor(.primary)
                    
                    Text(subtitle)
                        .font(.system(size: 17))
                        .foregroundColor(.secondary)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
            }
            .background(Color(UIColor.systemBackground))
            .cornerRadius(10)
            .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
        }
    }

    // Wave shapes overlay component
    struct WaveShapesOverlay: View {
        var body: some View {
            GeometryReader { geometry in
                Path { path in
                    let width = geometry.size.width
                    let height = geometry.size.height
                    let midHeight = height * 0.5
                    
                    // Create wave path
                    path.move(to: CGPoint(x: 0, y: height))
                    
                    // First wave
                    var x: CGFloat = 0
                    while x <= width {
                        let y = sin((x/width) * .pi * 2) * 20 + midHeight
                        path.addLine(to: CGPoint(x: x, y: y))
                        x += 1
                    }
                    
                    path.addLine(to: CGPoint(x: width, y: height))
                    path.addLine(to: CGPoint(x: 0, y: height))
                }
                .fill(Color.white.opacity(0.3))
                
                // Second wave with offset
                Path { path in
                    let width = geometry.size.width
                    let height = geometry.size.height
                    let midHeight = height * 0.6
                    
                    path.move(to: CGPoint(x: 0, y: height))
                    
                    var x: CGFloat = 0
                    while x <= width {
                        let y = sin((x/width) * .pi * 2 + .pi/2) * 15 + midHeight
                        path.addLine(to: CGPoint(x: x, y: y))
                        x += 1
                    }
                    
                    path.addLine(to: CGPoint(x: width, y: height))
                    path.addLine(to: CGPoint(x: 0, y: height))
                }
                .fill(Color.white.opacity(0.2))
            }
        }
    }
}

// Preview
struct BladderIncontinenceView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            BladderIncontinenceView()
                .preferredColorScheme(.dark)
                .previewDisplayName("Dark Mode")
            
            BladderIncontinenceView()
                .preferredColorScheme(.light)
                .previewDisplayName("Light Mode")
        }
    }
}
