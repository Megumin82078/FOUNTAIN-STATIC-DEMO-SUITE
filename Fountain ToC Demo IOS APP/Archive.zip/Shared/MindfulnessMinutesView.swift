import SwiftUI

struct MindfulnessMinutesView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) private var colorScheme
    
    // 时间范围选择
    enum TimeRange: String, CaseIterable, Identifiable {
        case day = "Day"
        case week = "Week"
        case month = "Month"
        case sixMonths = "6 Months"
        case year = "Year"
        
        var id: String { self.rawValue }
    }
    
    @State private var selectedTimeRange: TimeRange = .day
    
    // 正念数据点
    struct MindfulnessPoint: Identifiable {
        let id = UUID()
        let time: String
        let hour: Int
        let minutes: Int
    }
    
    // 示例数据 - 在18时有1分钟的正念记录
    let mindfulnessData: [MindfulnessPoint] = [
        MindfulnessPoint(time: "18:00", hour: 18, minutes: 1)
    ]
    
    // 根据当前主题获取背景色
    var backgroundColor: Color {
        colorScheme == .dark ? Color.black : Color.white
    }
    
    // 根据当前主题获取文本颜色
    var textColor: Color {
        colorScheme == .dark ? Color.white : Color.black
    }
    
    // 根据当前主题获取选择器背景色
    var segmentedControlBackgroundColor: Color {
        colorScheme == .dark ? Color(UIColor.systemGray6) : Color(UIColor.systemGray5)
    }
    
    // 根据当前主题获取选择器选中背景色
    var segmentedControlSelectedBackgroundColor: Color {
        colorScheme == .dark ? Color(UIColor.systemGray5) : Color(UIColor.systemGray4)
    }
    
    // 根据当前主题获取卡片背景色
    var cardBackgroundColor: Color {
        colorScheme == .dark ? Color(UIColor.systemGray6).opacity(0.3) : Color(UIColor.systemGray6).opacity(0.5)
    }
    
    // 根据当前主题获取网格线颜色
    var gridLineColor: Color {
        colorScheme == .dark ? Color.gray.opacity(0.2) : Color.gray.opacity(0.3)
    }
    
    var body: some View {
        ZStack(alignment: .top) {
            // 背景色
            backgroundColor.edgesIgnoringSafeArea(.all)
            
            // 内容
            VStack(spacing: 0) {
                // 自定义导航栏
                HStack {
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        HStack(spacing: 5) {
                            Image(systemName: "chevron.left")
                                .foregroundColor(Color.blue)
                                .font(.system(size: 16, weight: .semibold))
                            Text("Mindfulness")
                                .foregroundColor(Color.blue)
                                .font(.system(size: 17))
                        }
                    }
                    
                    Spacer()
                    
                    Text("Mindfulness Minutes")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundColor(textColor)
                    
                    Spacer()
                    
                    Button(action: {
                        // 添加数据操作
                    }) {
                        Text("Add Data")
                            .foregroundColor(Color.blue)
                            .font(.system(size: 17))
                    }
                }
                .padding(.horizontal)
                .padding(.top, 10)
                .padding(.bottom, 10)
                .background(backgroundColor)
                
                // 时间范围选择器
                HStack(spacing: 0) {
                    ForEach(TimeRange.allCases) { range in
                        Button(action: {
                            withAnimation {
                                selectedTimeRange = range
                            }
                        }) {
                            Text(range.rawValue)
                                .font(.system(size: 15))
                                .foregroundColor(selectedTimeRange == range ? textColor : Color.gray)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 8)
                                .background(
                                    selectedTimeRange == range ?
                                    segmentedControlSelectedBackgroundColor :
                                    Color.clear
                                )
                        }
                    }
                }
                .background(segmentedControlBackgroundColor)
                .cornerRadius(8)
                .padding(.horizontal)
                .padding(.top, 5)
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        // 分钟数显示
                        HStack(alignment: .firstTextBaseline, spacing: 2) {
                            Text("1")
                                .font(.system(size: 48, weight: .regular))
                                .foregroundColor(textColor)
                            
                            Text("min")
                                .font(.system(size: 20))
                                .foregroundColor(textColor)
                                .padding(.leading, 2)
                            
                            Spacer()
                        }
                        .padding(.top, 20)
                        .padding(.horizontal)
                        
                        Text("Today")
                            .font(.system(size: 17))
                            .foregroundColor(Color.gray)
                            .padding(.horizontal)
                        
                        // 图表区域
                        VStack(spacing: 0) {
                            ZStack {
                                // 网格线
                                VStack(spacing: 0) {
                                    ForEach(0..<4) { _ in
                                        Spacer()
                                        Divider()
                                            .background(gridLineColor)
                                    }
                                    Spacer()
                                }
                                
                                HStack(spacing: 0) {
                                    ForEach(0..<4) { _ in
                                        Divider()
                                            .background(gridLineColor)
                                        Spacer()
                                    }
                                    Divider()
                                        .background(gridLineColor)
                                }
                                
                                // 数据点
                                GeometryReader { geometry in
                                    ForEach(mindfulnessData) { point in
                                        let xPosition = CGFloat(point.hour) / 24.0 * geometry.size.width
                                        Circle()
                                            .fill(Color.teal)
                                            .frame(width: 8, height: 8)
                                            .position(x: xPosition, y: geometry.size.height / 2)
                                    }
                                }
                                
                                // 时间标签
                                VStack {
                                    Spacer()
                                    HStack {
                                        Text("0 时")
                                            .font(.system(size: 12))
                                            .foregroundColor(Color.gray)
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                        
                                        Text("6 时")
                                            .font(.system(size: 12))
                                            .foregroundColor(Color.gray)
                                            .frame(maxWidth: .infinity, alignment: .center)
                                        
                                        Text("12 时")
                                            .font(.system(size: 12))
                                            .foregroundColor(Color.gray)
                                            .frame(maxWidth: .infinity, alignment: .center)
                                        
                                        Text("18 时")
                                            .font(.system(size: 12))
                                            .foregroundColor(Color.gray)
                                            .frame(maxWidth: .infinity, alignment: .trailing)
                                    }
                                    .padding(.horizontal)
                                }
                            }
                            .frame(height: 300)
                            .padding(.top, 10)
                        }
                        .padding(.horizontal)
                        
                        // 关于正念分钟数
                        VStack(alignment: .leading, spacing: 15) {
                            Text("About Mindfulness Minutes")
                                .font(.system(size: 22, weight: .bold))
                                .foregroundColor(textColor)
                                .padding(.top, 30)
                                .padding(.horizontal)
                            
                            VStack(alignment: .leading, spacing: 15) {
                                Text("Mindfulness is the state of being actively and openly aware of the present. When practicing mindfulness, you observe your thoughts and feelings from a distance without judging them. Instead of letting the years rush by, mindfulness means living in the moment and experiencing it positively.")
                                    .font(.system(size: 17))
                                    .foregroundColor(textColor)
                                    .lineSpacing(4)
                            }
                            .padding()
                            .background(cardBackgroundColor)
                            .cornerRadius(12)
                            .padding(.horizontal)
                        }
                        .padding(.bottom, 30)
                    }
                }
            }
        }
        .navigationBarHidden(true)
    }
}

struct MindfulnessMinutesView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            MindfulnessMinutesView()
                .preferredColorScheme(.dark)
                .previewDisplayName("Dark Mode")
            
            MindfulnessMinutesView()
                .preferredColorScheme(.light)
                .previewDisplayName("Light Mode")
        }
    }
}
