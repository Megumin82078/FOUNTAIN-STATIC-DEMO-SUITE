import SwiftUI

struct HealthAnalysisView: View {
    @Environment(\.colorScheme) var colorScheme
    @State private var selectedRecommendation: HealthAIRecommendation?

    let aiRecommendations: [HealthAIRecommendation] = [
        HealthAIRecommendation(summary: "Your blood sugar levels are slightly elevated based on the last three measurements (6.4, 6.7, 6.5 mmol/L). Consider diet control and increased exercise.",
                               source: "Source: 2025/03/01 Health Check",
                               details: sampleDetails),

        HealthAIRecommendation(summary: "Your weight has been steadily increasing (70.5kg → 71.2kg), and your blood pressure readings are high (140/90 mmHg). Consider lifestyle adjustments.",
                               source: "Source: Weekly Weight & BP Records",
                               details: sampleDetails),

        HealthAIRecommendation(summary: "Recent physical exam shows increased cholesterol levels. Consider reducing high-fat foods and increasing fiber intake.",
                               source: "Source: 2025/02/15 Lab Test",
                               details: sampleDetails)
    ]

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 15) {
                    ForEach(aiRecommendations) { recommendation in
                        HealthAnalysisCard(recommendation: recommendation)
                            .onTapGesture {
                                selectedRecommendation = recommendation
                            }
                    }
                }
                .padding()
            }
            .navigationTitle("AI Health Analysis")
        }
        .sheet(item: $selectedRecommendation) { recommendation in
            HealthAnalysisDetailView(detail: recommendation.details)
        }
    }
}

struct HealthAnalysisCard: View {
    let recommendation: HealthAIRecommendation

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(recommendation.summary)
                .font(.body)
                .foregroundColor(.primary)
                .multilineTextAlignment(.leading)

            Divider()

            Text(recommendation.source)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding()
        .background(RoundedRectangle(cornerRadius: 15).fill(Color(UIColor.secondarySystemBackground)))
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 3)
    }
}

struct HealthAnalysisDetailView: View {
    let detail: HealthAnalysisDetail
    @Environment(\.dismiss) var dismiss

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 15) {
                    SectionHeader(title: "Data Analysis Details")
                    InfoRow(title: "Data Source", content: detail.dataSource)
                    InfoRow(title: "Analysis Logic", content: detail.analysisLogic)

                    SectionHeader(title: "Personalized Recommendations")
                    ForEach(detail.suggestions, id: \.self) { suggestion in
                        Text("• \(suggestion)")
                            .font(.body)
                            .foregroundColor(.primary)
                    }

                    SectionHeader(title: "Blood Sugar Trend (Last 6 Months)")
                    BloodSugarTrendView(data: detail.trendData)
                        .frame(height: 200)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 10).fill(Color(UIColor.secondarySystemBackground)))
                        .shadow(radius: 3)

                    SectionHeader(title: "Actions")
                    HStack {
                        ActionButton(title: "Set Reminder")
                        ActionButton(title: "Ask a Doctor")
                    }
                }
                .padding()
            }
            .navigationTitle("Analysis Details")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Close") {
                        dismiss()
                    }
                }
            }
        }
    }
}

struct SectionHeader: View {
    let title: String
    var body: some View {
        Text(title)
            .font(.headline)
            .foregroundColor(.blue)
            .padding(.top, 10)
    }
}

struct InfoRow: View {
    let title: String
    let content: String
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title)
                .font(.subheadline)
                .bold()
                .foregroundColor(.secondary)
            Text(content)
                .font(.body)
                .foregroundColor(.primary)
        }
    }
}

// 自定义折线图
struct BloodSugarTrendView: View {
    let data: [HealthDataPoint]

    var body: some View {
        GeometryReader { geometry in
            let maxValue = data.map { $0.value }.max() ?? 7.0
            let minValue = data.map { $0.value }.min() ?? 5.0

            Path { path in
                let width = geometry.size.width
                let height = geometry.size.height
                let stepX = width / CGFloat(data.count - 1)
                let normalizedPoints = data.map { CGFloat(($0.value - minValue) / (maxValue - minValue)) }
                
                for i in 0..<data.count {
                    let x = stepX * CGFloat(i)
                    let y = height * (1 - normalizedPoints[i]) 
                    if i == 0 {
                        path.move(to: CGPoint(x: x, y: y))
                    } else {
                        path.addLine(to: CGPoint(x: x, y: y))
                    }
                }
            }
            .stroke(Color.red, lineWidth: 2)
        }
    }
}

struct ActionButton: View {
    let title: String
    var body: some View {
        Button(action: {}) {
            Text(title)
                .font(.body)
                .foregroundColor(.white)
                .padding()
                .frame(maxWidth: .infinity)
                .background(RoundedRectangle(cornerRadius: 10).fill(Color.blue))
        }
    }
}

// 数据模型
struct HealthAIRecommendation: Identifiable {
    let id = UUID()
    let summary: String
    let source: String
    let details: HealthAnalysisDetail
}

struct HealthAnalysisDetail {
    let dataSource: String
    let analysisLogic: String
    let suggestions: [String]
    let trendData: [HealthDataPoint]
}

struct HealthDataPoint: Identifiable {
    let id = UUID()
    let month: String
    let value: Double
}

// 预览数据
let sampleDetails = HealthAnalysisDetail(
    dataSource: "Based on your 2025/03/01 health check and the last three fasting blood sugar tests (6.4, 6.7, 6.5 mmol/L).",
    analysisLogic: "Your average fasting blood sugar is 6.53 mmol/L, which is above the normal range, indicating a possible risk of prediabetes.",
    suggestions: [
        "Reduce high-sugar food intake and prioritize low-GI foods.",
        "Engage in at least 3 sessions of moderate-intensity aerobic exercise per week, 30 minutes each.",
        "Recheck blood sugar in a week to observe trends.",
        "If blood sugar remains high, consult an endocrinologist."
    ],
    trendData: [
        HealthDataPoint(month: "Oct", value: 5.8),
        HealthDataPoint(month: "Nov", value: 6.1),
        HealthDataPoint(month: "Dec", value: 6.3),
        HealthDataPoint(month: "Jan", value: 6.4),
        HealthDataPoint(month: "Feb", value: 6.7),
        HealthDataPoint(month: "Mar", value: 6.5)
    ]
)

// 预览
struct HealthAnalysisView_Previews: PreviewProvider {
    static var previews: some View {
        HealthAnalysisView()
            .preferredColorScheme(.light)

        HealthAnalysisView()
            .preferredColorScheme(.dark)
    }
}
