//
//  Apple_helath_cpApp.swift
//  Shared
//
//  Created by limenghui on 2025/2/17.
//

import SwiftUI

@main
struct Apple_helath_cpApp: App {
    var body: some Scene {
        WindowGroup {
            WelcomeView()
        }
    }
}
