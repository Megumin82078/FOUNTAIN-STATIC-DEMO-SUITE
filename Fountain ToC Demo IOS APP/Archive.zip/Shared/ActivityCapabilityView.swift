import SwiftUI

struct ActivityCapabilityView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) private var colorScheme
    
    var body: some View {
       ZStack {
            Color(.systemBackground).edgesIgnoringSafeArea(.all)
            
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    // Header
                    Text("Mobility")
                        .font(.system(size: 34, weight: .bold))
                        .foregroundColor(.primary)
                        .padding(.horizontal, 16)
                        .padding(.bottom, 30)
                    
                    // Today Section
                    Text("Today")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(.primary)
                        .padding(.horizontal, 16)
                        .padding(.bottom, 16)
                    
                    // Activity Cards
                    Group {
                        activityCard(
                            icon: "figure.walk",
                            title: "Stride Length",
                            value: "49",
                            unit: "cm",
                            time: "18:31"
                        )
                        
                        activityCard(
                            icon: "figure.walk",
                            title: "Walking Speed",
                            value: "1.2",
                            unit: "m/s",
                            time: "18:31"
                        )
                        activityCard(
                            icon: "figure.stand",
                            title: "Double Support Time",
                            value: "29.5",
                            unit: "%",
                            time: "18:31"
                        )
                        activityCard(
                            icon: "arrow.left.arrow.right",
                            title: "Step Asymmetry",
                            value: "7.7",
                            unit: "%",
                            time: "18:27"
                        )
                    }
                    .padding(.bottom, 24)
                    
                    // Last 7 Days Section
                    Text("Last 7 Days")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(.primary)
                        .padding(.horizontal, 16)
                        .padding(.bottom, 16)
                    
                    // Stability Card
                    stabilityCard()
                        .padding(.bottom, 24)
                    
                    // No Data Section
                    noDataSection()
                        .padding(.bottom, 24)
                    
                    // Articles Section
                    articlesSection()
                }
            }
        }
    }
    
    // MARK: - Components
    private func activityCard(icon: String, title: String, value: String, unit: String, time: String) -> some View {
        VStack(alignment: .leading, spacing: 0) {
             NavigationLink(destination: WalkingStrideLengthView().navigationBarHidden(true)) { 
                HStack {
                    HStack(spacing: 8) {
                        Image(systemName: icon)
                            .foregroundColor(.orange)
                            .font(.system(size: 16))
                        
                        Text(title)
                            .font(.system(size: 17))
                            .foregroundColor(.primary)
                    }
                    
                    Spacer()
                    
                    HStack(spacing: 4) {
                        Text(time)
                            .font(.system(size: 17))
                            .foregroundColor(.secondary)
                        
                        Image(systemName: "chevron.right")
                            .foregroundColor(.secondary)
                            .font(.system(size: 14))
                    }
                }
                .padding([.horizontal, .top], 16)
                .padding(.bottom, 8)
             }
            
            HStack(alignment: .firstTextBaseline, spacing: 2) {
                Text(value)
                    .font(.system(size: 34, weight: .regular))
                    .foregroundColor(.primary)
                
                Text(unit)
                    .font(.system(size: 17))
                    .foregroundColor(.primary)
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 16)
        }
        .background(Color(.secondarySystemBackground))
        .cornerRadius(13)
        .padding(.horizontal, 16)
        .padding(.bottom, 8)
    }
    
    private func stabilityCard() -> some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                HStack(spacing: 8) {
                    Image(systemName: "waveform.path")
                        .foregroundColor(.orange)
                        .font(.system(size: 16))
                    
                    Text("Walking Stability")
                        .font(.system(size: 17))
                        .foregroundColor(.primary)
                }
                
                Spacer()
                
                HStack(spacing: 4) {
                    Text("Mar 2")
                        .font(.system(size: 17))
                        .foregroundColor(.secondary)
                    
                    Image(systemName: "chevron.right")
                        .foregroundColor(.secondary)
                        .font(.system(size: 14))
                }
            }
            .padding([.horizontal, .top], 16)
            .padding(.bottom, 8)
            
            HStack {
                Text("Normal")
                    .font(.system(size: 34, weight: .regular))
                    .foregroundColor(.primary)
                
                Spacer()
                
                HStack(spacing: 2) {
                    RoundedRectangle(cornerRadius: 2)
                        .fill(Color.orange)
                        .frame(width: 44, height: 4)
                    
                    RoundedRectangle(cornerRadius: 2)
                        .fill(Color.gray.opacity(0.3))
                        .frame(width: 44, height: 4)
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 8)
            
            Text("Feb 23 - Mar 2")
                .font(.system(size: 15))
                .foregroundColor(.secondary)
                .padding(.horizontal, 16)
                .padding(.bottom, 16)
        }
        .background(Color(.secondarySystemBackground))
        .cornerRadius(13)
        .padding(.horizontal, 16)
    }
    
    private func noDataSection() -> some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("No Data Available")
                .font(.system(size: 22, weight: .bold))
                .foregroundColor(.primary)
                .padding(.horizontal, 16)
                .padding(.vertical, 16)
            
            VStack(spacing: 0) {
                ForEach([
                    "Walking Stability Notifications",
                    "Ground Contact Time",
                    "Vertical Oscillation",
                    "6-Minute Walk Test",
                    "Stair Speed: Ascent",
                    "Stair Speed: Descent"
                ], id: \.self) { item in
                    VStack(spacing: 0) {
                        HStack {
                            Text(item)
                                .font(.system(size: 17))
                                .foregroundColor(.primary)
                            
                            Spacer()
                            
                            Image(systemName: "chevron.right")
                                .foregroundColor(.secondary)
                                .font(.system(size: 14))
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                        
                        if item != "Stair Speed: Descent" {
                            Divider()
                                .background(Color(.separator))
                                .padding(.leading, 16)
                        }
                    }
                }
            }
            .background(Color(.secondarySystemBackground))
            .cornerRadius(13)
            .padding(.horizontal, 16)
        }
    }
    
    private func articlesSection() -> some View {
        VStack(alignment: .leading, spacing: 24) {
            Text("About Mobility")
                .font(.system(size: 22, weight: .bold))
                .foregroundColor(.primary)
                .padding(.horizontal, 16)
            
            articleCard(
                title: "Exercises to Improve Walking Stability",
                subtitle: "Understanding why walking stability declines and how to address it.",
                backgroundColor: Color.blue.opacity(0.8)
            )
            
            articleCard(
                title: "Understanding Walking Stability",
                subtitle: "What walking stability means and how to maintain it.",
                backgroundColor: Color(red: 0, green: 0.6, blue: 0.8)
            )
        }
        .padding(.top, 8)
    }
    
    private func articleCard(title: String, subtitle: String, backgroundColor: Color) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundColor(.white)
                    .multilineTextAlignment(.leading)
                
                Text(subtitle)
                    .font(.system(size: 15))
                    .foregroundColor(.white.opacity(0.8))
            }
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .frame(height: 120)
            .background(
                backgroundColor
                    .cornerRadius(13)
            )
        }
        .padding(.horizontal, 16)
    }
}

struct ActivityCapabilityView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ActivityCapabilityView()
                .preferredColorScheme(.dark)
            
            ActivityCapabilityView()
                .preferredColorScheme(.light)
        }
    }
}