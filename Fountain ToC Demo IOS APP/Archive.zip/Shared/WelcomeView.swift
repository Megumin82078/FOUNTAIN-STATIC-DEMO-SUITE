import SwiftUI

struct WelcomeView: View {
    @State private var isMainViewActive = false // 追踪是否进入主界面
    
    var body: some View {
        ZStack {
            Color(.systemBackground) // 适配深色模式
                .ignoresSafeArea()
            
            VStack {
                Spacer()
                
                ZStack {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color(.tertiarySystemBackground)) // 适配背景色
                        .frame(width: 100, height: 100)
                        .overlay(
                            Image(systemName: "heart.fill")
                                .resizable()
                                .foregroundColor(.pink)
                                .frame(width: 50, height: 50)
                        )
                    
                    ForEach(iconPositions, id: \..self) { position in
                        Image(systemName: position.icon)
                            .resizable()
                            .frame(width: 30, height: 30)
                            .foregroundColor(position.color)
                            .position(x: position.x, y: position.y)
                    }
                }
                .frame(width: 300, height: 300)
                
                Spacer()
                
                Text("Welcome to \"Fountain\"")
                    .font(.title)
                    .bold()
                    .foregroundColor(.primary) // Adapts to system foreground color

                Text("Your one-stop health data management platform.You can integrate all of your medical records, get personalized health insights, and view and authorize your own medical records in realtime record")
                    .font(.body)
                    .foregroundColor(.secondary) // Adapts to secondary text color
                    .multilineTextAlignment(.center)
                    .padding()
                
                Spacer()
                
                Button(action: {
                    isMainViewActive = true
                }) {
                    Text("continue")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .padding(.horizontal, 40)
                }
                .fullScreenCover(isPresented: $isMainViewActive) {
                    ContentView() // **全屏进入主界面**
                }
                
                // Rectangle()
                //     .frame(height: 5)
                //     .foregroundColor(Color.secondary.opacity(0.5))
                //     .padding(.top, 10)
            }
        }
    }
}

// 预览
struct WelcomeView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            WelcomeView()
                .preferredColorScheme(.light) // 浅色模式
            WelcomeView()
                .preferredColorScheme(.dark) // 深色模式
        }
    }
}

// 图标分布数据
struct IconPosition: Hashable {
    let icon: String
    let x: CGFloat
    let y: CGFloat
    let color: Color
}

let iconPositions: [IconPosition] = [
    IconPosition(icon: "bed.double.fill", x: 60, y: 50, color: .blue),
    IconPosition(icon: "flame.fill", x: 240, y: 80, color: .red),
    IconPosition(icon: "applelogo", x: 180, y: 240, color: .green),
    IconPosition(icon: "figure.walk", x: 40, y: 200, color: .purple),
    IconPosition(icon: "pills.fill", x: 260, y: 180, color: .yellow)
]
