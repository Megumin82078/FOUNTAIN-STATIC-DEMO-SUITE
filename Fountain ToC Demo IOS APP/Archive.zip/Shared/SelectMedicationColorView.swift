import SwiftUI

struct SelectMedicationColorView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) var colorScheme  // 适配深色/浅色模式
    @State private var showMedicationDetailView = false

    
    let medicationName: String
    let specification: String
    let medicationShape: String
    
    @State private var selectedForegroundColor: Color = .white
    @State private var selectedBackgroundColor: Color = .blue
    
    // 颜色选项
    let foregroundColors: [Color] = [
        .white, Color(UIColor.lightGray), Color(UIColor.systemYellow).opacity(0.7),
        Color(UIColor.systemOrange).opacity(0.7), Color(UIColor.systemGreen).opacity(0.7),
        Color(UIColor.systemMint), .cyan, .blue, .purple, .pink, .red, .orange
    ]
    
    let backgroundColors: [Color] = [
        .blue, Color(UIColor.darkGray), .yellow, .orange, .green, .mint,
        .cyan, .purple, .indigo, .pink, .red, Color(UIColor.brown)
    ]
    
    var body: some View {
        ZStack {
            // 动态适配背景色
            (colorScheme == .dark ? Color.black : Color.white)
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 0) {
                // 导航栏
                HStack {
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        HStack(spacing: 2) {
                            Image(systemName: "chevron.left")
                            Text("back")
                        }
                        .foregroundColor(.blue)
                        .font(.system(size: 17))
                    }
                    
                    Spacer()
                    
                    Text("\(medicationName)")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundColor(colorScheme == .dark ? .white : .black)
                    
                    Spacer()
                    
                    Button("cancel") {
                        presentationMode.wrappedValue.dismiss()
                    }
                    .foregroundColor(.blue)
                    .font(.system(size: 17))
                }
                .padding(.horizontal)
                .padding(.top, 16)
                .padding(.bottom, 8)
                
                Text("capsule, \(specification)")
                    .font(.system(size: 15))
                    .foregroundColor(.gray)
                    .padding(.bottom, 20)
                
                // 滚动内容区域
                ScrollView {
                    VStack(spacing: 0) {
                        // 药品图标预览
                        ZStack {
                            Circle()
                                .fill(selectedBackgroundColor)
                                .frame(width: 120, height: 120)
                            
                            if medicationShape == "capsule" {
                                Capsule()
                                    .fill(selectedForegroundColor)
                                    .frame(width: 60, height: 30)
                            } else if medicationShape == "roundness" {
                                Circle()
                                    .fill(selectedForegroundColor)
                                    .frame(width: 50, height: 50)
                            } else {
                                RoundedRectangle(cornerRadius: 5)
                                    .fill(selectedForegroundColor)
                                    .frame(width: 50, height: 30)
                            }
                        }
                        .padding(.bottom, 20)
                        
                        // 标题
                        Text("select color")
                            .font(.system(size: 28, weight: .bold))
                            .foregroundColor(colorScheme == .dark ? .white : .black)
                            .padding(.bottom, 30)
                        
                        // 颜色选择部分
                        VStack(alignment: .leading, spacing: 20) {
                            Text("sharp")
                                .font(.system(size: 17, weight: .medium))
                                .foregroundColor(colorScheme == .dark ? .white : .black)
                                .padding(.leading, 5)
                            
                            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 15), count: 6), spacing: 15) {
                                ForEach(0..<foregroundColors.count, id: \.self) { index in
                                    Button(action: {
                                        selectedForegroundColor = foregroundColors[index]
                                    }) {
                                        Circle()
                                            .fill(foregroundColors[index])
                                            .frame(width: 50, height: 50)
                                            .overlay(
                                                Circle()
                                                    .stroke(selectedForegroundColor == foregroundColors[index] ? Color.blue : Color.clear, lineWidth: 3)
                                            )
                                    }
                                }
                            }
                            .padding(.bottom, 20)
                            
                            Text("background")
                                .font(.system(size: 17, weight: .medium))
                                .foregroundColor(colorScheme == .dark ? .white : .black)
                                .padding(.leading, 5)
                            
                            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 15), count: 6), spacing: 15) {
                                ForEach(0..<backgroundColors.count, id: \.self) { index in
                                    Button(action: {
                                        selectedBackgroundColor = backgroundColors[index]
                                    }) {
                                        Circle()
                                            .fill(backgroundColors[index])
                                            .frame(width: 50, height: 50)
                                            .overlay(
                                                Circle()
                                                    .stroke(selectedBackgroundColor == backgroundColors[index] ? Color.blue : Color.clear, lineWidth: 3)
                                            )
                                    }
                                }
                            }
                        }
                        .padding(.horizontal)
                        
                        Spacer(minLength: 100)
                    }
                }
                
                // 下一步按钮
                Button(action: {
                   showMedicationDetailView = true
                }) {
                    Text("Next Step")
                        .font(.system(size: 17, weight: .medium))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                .sheet(isPresented: $showMedicationDetailView) {
                    MedicationDetailView(
                        medicationName: "Ggg",
                        specification: "5 milligram",
                        medicationType: "capsule"
                    )
                }
                .padding(.horizontal)
                .padding(.vertical, 20)
            }
        }
        .navigationBarHidden(true)
    }
}

struct SelectMedicationColorView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            SelectMedicationColorView(
                medicationName: "Ggg",
                specification: "5 毫克",
                medicationShape: "胶囊"
            )
            .preferredColorScheme(.light) // 测试浅色模式
            
            SelectMedicationColorView(
                medicationName: "Ggg",
                specification: "5 毫克",
                medicationShape: "胶囊"
            )
            .preferredColorScheme(.dark) // 测试深色模式
        }
    }
}
