import SwiftUI

struct EditMedicationListView: View {
    @Environment(\.dismiss) var dismiss
    @Environment(\.colorScheme) private var colorScheme
    
    // Medication list
    @State private var medications = [
        Medication(id: "1", name: "Aa", type: "External use", dosage: "1 milligram", schedule: "everyday")
    ]
    
    // Background color based on theme
    var backgroundColor: Color {
        colorScheme == .dark ? Color.black : Color.white
    }
    
    // Text color based on theme
    var textColor: Color {
        colorScheme == .dark ? Color.white : Color.black
    }
    
    // Card background color based on theme
    var cardBackgroundColor: Color {
        colorScheme == .dark ? Color(red: 0.17, green: 0.22, blue: 0.28) : Color(UIColor.systemGray6)
    }
    
    // Divider color based on theme
    var dividerColor: Color {
        colorScheme == .dark ? Color.gray.opacity(0.3) : Color.gray.opacity(0.2)
    }
    
    var body: some View {
        ZStack {
            // Background color
            backgroundColor.edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 0) {
                // Custom navigation bar
                HStack {
                    Spacer()
                    
                    Text("Edit Medication List")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundColor(textColor)
                    
                    Spacer()
                    
                    Button("Done") {
                        dismiss()
                    }
                    .foregroundColor(Color.blue)
                }
                .padding(.horizontal)
                .padding(.vertical, 12)
                
                ScrollView {
                    VStack(spacing: 0) {
                        // Add medication button
                        Button(action: {
                            // Add medication action
                        }) {
                            HStack {
                                Text("Add Medication")
                                    .font(.system(size: 17))
                                    .foregroundColor(Color.blue)
                                    .padding(.vertical, 15)
                                
                                Spacer()
                            }
                            .padding(.horizontal)
                            .background(cardBackgroundColor)
                            .cornerRadius(12)
                            .padding(.horizontal)
                            .padding(.top, 20)
                        }
                        .buttonStyle(PlainButtonStyle())
                        
                        // Your medications
                        HStack {
                            Text("Your Medications")
                                .font(.system(size: 17))
                                .foregroundColor(Color.gray)
                                .padding(.top, 30)
                                .padding(.bottom, 10)
                            
                            Spacer()
                        }
                        .padding(.horizontal)
                        
                        // Medications list
                        ForEach(medications) { medication in
                            medicationRow(medication: medication)
                        }
                        
                        // Archived medications
                        HStack {
                            Text("Archived Medications")
                                .font(.system(size: 17))
                                .foregroundColor(Color.gray)
                                .padding(.top, 30)
                                .padding(.bottom, 10)
                            
                            Spacer()
                        }
                        .padding(.horizontal)
                        
                        // Archived medications description
                        Text("Archived medications do not appear in the medications list or timing and cannot be added to a personal collection.")
                            .font(.system(size: 15))
                            .foregroundColor(Color.gray)
                            .padding(.horizontal)
                            .padding(.top, 5)
                        
                        Spacer(minLength: 50)
                    }
                }
            }
        }
        .navigationBarHidden(true)
    }
    
    // Medication row
    func medicationRow(medication: Medication) -> some View {
        HStack(spacing: 15) {
            // Delete icon
            Image(systemName: "trash.fill")
                .foregroundColor(Color.blue)
                .font(.system(size: 20))
            
            // Medication icon
            ZStack {
                Circle()
                    .fill(Color.blue.opacity(0.2))
                    .frame(width: 40, height: 40)
                
                Text("💊")
                    .font(.system(size: 20))
            }
            
            // Medication info
            VStack(alignment: .leading, spacing: 3) {
                Text(medication.name)
                    .font(.system(size: 17))
                    .foregroundColor(textColor)
                
                Text("\(medication.type), \(medication.dosage)")
                    .font(.system(size: 15))
                    .foregroundColor(Color.gray)
            }
            
            Spacer()
        }
        .padding(.vertical, 12)
        .padding(.horizontal)
        .background(cardBackgroundColor)
        .cornerRadius(12)
        .padding(.horizontal)
    }
}

// Medication model
struct Medication: Identifiable {
    var id: String
    var name: String
    var type: String
    var dosage: String
    var schedule: String
}

struct EditMedicationListView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            EditMedicationListView()
                .preferredColorScheme(.dark)
                .previewDisplayName("Dark Mode")
            
            EditMedicationListView()
                .preferredColorScheme(.light)
                .previewDisplayName("Light Mode")
        }
    }
}