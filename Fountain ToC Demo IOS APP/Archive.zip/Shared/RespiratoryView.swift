import SwiftUI

struct RespiratoryView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var colorScheme
    @State private  var pageTitle = "About Respiratory" 
    // Respiratory metrics
    private let list = [
        "Blood Oxygen",
        "Cardio Fitness",
        "Forced Expiratory Volume, 1 sec",
        "Forced Vital Capacity",
        "Inhaler Usage",
        "Peak Expiratory Flow Rate",
        "Respiratory Rate",
        "Six-Minute Walk"
    ]
    
    var body: some View {
        ZStack {
            // Background color based on theme
            backgroundColor
                .edgesIgnoringSafeArea(.all)
            
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    // Back button
                    Button(action: { dismiss() }) {
                        HStack(spacing: 2) {
                            Image(systemName: "chevron.left")
                                .font(.system(size: 16, weight: .semibold))
                            Text("Browse")
                                .font(.system(size: 17))
                        }
                        .foregroundColor(.blue)
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 16)
                    .padding(.bottom, 8)
                    
                    // Title
                    Text("Respiratory")
                        .font(.system(size: 34, weight: .bold))
                        .foregroundColor(textColor)
                        .padding(.horizontal, 16)
                        .padding(.bottom, 8)
                    
                    // No data available
                    Text("No Data Available")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(textColor)
                        .padding(.horizontal, 16)
                        .padding(.bottom, 16)
                    
                    // Metrics list
                    metricsListView
                        .padding(.bottom, 24)
                    
                    
                    // About card with gradient
                    aboutCardView
                        .padding(.horizontal, 16)
                        .padding(.bottom, 32)
                }
            }
        }
        .navigationBarHidden(true)
    }
    
    // Background color
    private var backgroundColor: Color {
        colorScheme == .dark ? .black : Color(UIColor.systemGroupedBackground)
    }
    
    // Text color
    private var textColor: Color {
        colorScheme == .dark ? .white : .black
    }
    
    // Metrics list
    private var metricsListView: some View {
        VStack(spacing: 0) {
            ForEach(list, id: \.self) { metric in
                VStack(spacing: 0) {
                    NavigationLink(destination: RespiratoryDetailView(title: metric)) {
                         HStack {
                            Text(metric)
                                .font(.system(size: 17))
                                .foregroundColor(textColor)
                            
                            Spacer()
                            
                            Image(systemName: "chevron.right")
                                .foregroundColor(Color.gray)
                                .font(.system(size: 14))
                        }
                        .padding(.vertical, 12)
                        .padding(.horizontal, 16)
                        
                        if metric != list.last {
                            Divider()
                                .background(Color.gray.opacity(0.15))
                                .padding(.leading, 16)
                        }
                    }
                }
            }
        }
        .background(cardBackgroundColor)
        .cornerRadius(10)
        .padding(.horizontal, 16)
    }
    
    // Card background color
    private var cardBackgroundColor: Color {
        colorScheme == .dark ? Color(UIColor.systemGray6) : .white
    }
    
    // About card with articles
    private var aboutCardView: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(pageTitle)
                .font(.system(size: 22, weight: .bold))
                .foregroundColor(colorScheme == .dark ? .white : .black)
            
            // First article card
            ArticleCard(
                title: "Learn About Blood Oxygen Levels",
                subtitle: "What they mean and why they're important to your health.",
                gradientColors: [
                    Color(red: 0.85, green: 0.4, blue: 0.3),  // Red
                    Color(red: 0.4, green: 0.6, blue: 0.9),   // Blue
                    Color(red: 0.7, green: 0.85, blue: 0.9)   // Light blue
                ]
            )
            
            // Second article card
            ArticleCard(
                title: "What it Means if Your Cardio Fitness Is Low",
                subtitle: "And what you can do about it.",
                image: Image("cardio_fitness") // You'll need to add this image to your assets
            )
        }
    }
}

// Article card component
struct ArticleCard: View {
    let title: String
    let subtitle: String
    var gradientColors: [Color]? = nil
    var image: Image? = nil
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            if let colors = gradientColors {
                // Gradient wave background
                ZStack {
                    LinearGradient(
                        colors: colors,
                        startPoint: .topTrailing,
                        endPoint: .bottomLeading
                    )
                    .frame(height: 200)
                    
                    // Wave shapes overlay
                    WaveShapesOverlay()
                }
                .frame(height: 200)
                .clipShape(RoundedRectangle(cornerRadius: 10))
            } else if let img = image {
                // Image background
                img
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(height: 200)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(.primary)
                
                Text(subtitle)
                    .font(.system(size: 17))
                    .foregroundColor(.secondary)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
        }
        .background(Color(UIColor.systemBackground))
        .cornerRadius(10)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
    }
}

// Wave shapes overlay component
struct WaveShapesOverlay: View {
    var body: some View {
        GeometryReader { geometry in
            Path { path in
                let width = geometry.size.width
                let height = geometry.size.height
                let midHeight = height * 0.5
                
                // Create wave path
                path.move(to: CGPoint(x: 0, y: height))
                
                // First wave
                var x: CGFloat = 0
                while x <= width {
                    let y = sin((x/width) * .pi * 2) * 20 + midHeight
                    path.addLine(to: CGPoint(x: x, y: y))
                    x += 1
                }
                
                path.addLine(to: CGPoint(x: width, y: height))
                path.addLine(to: CGPoint(x: 0, y: height))
            }
            .fill(Color.white.opacity(0.3))
            
            // Second wave with offset
            Path { path in
                let width = geometry.size.width
                let height = geometry.size.height
                let midHeight = height * 0.6
                
                path.move(to: CGPoint(x: 0, y: height))
                
                var x: CGFloat = 0
                while x <= width {
                    let y = sin((x/width) * .pi * 2 + .pi/2) * 15 + midHeight
                    path.addLine(to: CGPoint(x: x, y: y))
                    x += 1
                }
                
                path.addLine(to: CGPoint(x: width, y: height))
                path.addLine(to: CGPoint(x: 0, y: height))
            }
            .fill(Color.white.opacity(0.2))
        }
    }
}

// Preview
struct RespiratoryView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            RespiratoryView()
                .preferredColorScheme(.light)
                .previewDisplayName("Light Mode")
            
            RespiratoryView()
                .preferredColorScheme(.dark)
                .previewDisplayName("Dark Mode")
        }
    }
}
