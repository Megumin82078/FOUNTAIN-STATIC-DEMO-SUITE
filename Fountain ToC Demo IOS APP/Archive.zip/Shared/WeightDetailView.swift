import SwiftUI

// 体重数据模型
struct WeightData: Identifiable, Codable {
    let id = UUID()
    let date: Date
    let weight: Double // 单位: lbs
    
    init(date: Date, weight: Double) {
        self.date = date
        self.weight = weight
    }
}

struct WeightDetailView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) var colorScheme
    
    // 时间范围选择
    private let timeRanges = ["D", "W", "M", "6M", "Y"]
    @State private var selectedTimeRangeIndex = 0
    
    // 图表数据状态
    @State private var weightEntries: [WeightData] = []
    @State private var chartData: [WeightData] = []
    @State private var averageWeight: Double = 102.5 // 默认值
    @State private var minWeight: Double = 90.0
    @State private var maxWeight: Double = 120.0
    
    // 添加数据表单状态
    @State private var showAddDataSheet = false
    @State private var newWeight: String = ""
    @State private var selectedDate = Date()
    @State private var selectedTime = Date()
    
    // 颜色和主题
    var textColor: Color {
        colorScheme == .dark ? .white : .black
    }
    
    var backgroundColor: Color {
        colorScheme == .dark ? .black : .white
    }
    
    var secondaryBackgroundColor: Color {
        colorScheme == .dark ? Color(UIColor.systemGray6) : Color(UIColor.systemGray5)
    }
    
    var chartGridColor: Color {
        colorScheme == .dark ? Color.gray.opacity(0.3) : Color.gray.opacity(0.2)
    }
    
    var chartLineColor: Color {
        Color.purple
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // 自定义导航栏
            navigationBar
            
            ScrollView {
                VStack(spacing: 0) {
                    // 时间范围选择器
                    timeRangePicker
                        .padding(.horizontal, 16)
                        .padding(.top, 16)
                    
                    // 体重信息显示
                    weightInfoView
                        .padding(.horizontal, 16)
                        .padding(.top, 20)
                    
                    // 体重图表
                    customWeightChartView
                        .frame(height: 300)
                        .padding(.top, 16)
                        .padding(.horizontal, 16)
                }
            }
        }
        .background(backgroundColor.edgesIgnoringSafeArea(.all))
        .navigationBarHidden(true)
        .sheet(isPresented: $showAddDataSheet) {
            AddWeightDataView(
                isPresented: $showAddDataSheet,
                date: $selectedDate,
                time: $selectedTime,
                weight: $newWeight,
                onSave: saveNewWeightData
            )
        }
        .onAppear {
            loadWeightData()
            updateChartData()
        }
    }
    
    // MARK: - 组件视图
    
    // 导航栏
    private var navigationBar: some View {
        HStack {
            Button(action: { dismiss() }) {
                HStack(spacing: 4) {
                    Image(systemName: "chevron.left")
//                    Text("Summary")
                }
                .foregroundColor(.blue)
                .font(.system(size: 17))
            }
            
            Spacer()
            
            Text("Weight")
                .font(.system(size: 17, weight: .semibold))
                .foregroundColor(textColor)
            
            Spacer()
            
            Button("Add Data") {
                showAddDataSheet = true
            }
            .font(.system(size: 17))
            .foregroundColor(.blue)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(colorScheme == .dark ? Color.black : Color.white)
    }
    
    // 时间范围选择器
    private var timeRangePicker: some View {
        HStack(spacing: 0) {
            ForEach(0..<timeRanges.count, id: \.self) { index in
                Button(action: {
                    selectedTimeRangeIndex = index
                    updateChartData()
                }) {
                    Text(timeRanges[index])
                        .font(.system(size: 17))
                        .foregroundColor(selectedTimeRangeIndex == index ? 
                                         (colorScheme == .dark ? .white : .black) : 
                                         .gray)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                        .background(selectedTimeRangeIndex == index ? 
                                    secondaryBackgroundColor : Color.clear)
                }
            }
        }
        .background(colorScheme == .dark ? Color(UIColor.systemGray6).opacity(0.5) : Color(UIColor.systemGray6))
        .cornerRadius(8)
    }
    
    // 体重信息视图
    private var weightInfoView: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("AVERAGE")
                .font(.system(size: 13))
                .foregroundColor(.gray)
            
            HStack(alignment: .firstTextBaseline, spacing: 4) {
                Text("\(String(format: "%.1f", averageWeight))")
                    .font(.system(size: 48, weight: .regular))
                    .foregroundColor(textColor)
                
                Text("lbs")
                    .font(.system(size: 22))
                    .foregroundColor(.gray)
                    .padding(.leading, 2)
            }
            
            Text("Today")
                .font(.system(size: 17))
                .foregroundColor(.gray)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
    
    // 自定义体重图表视图
    private var customWeightChartView: some View {
        VStack(spacing: 0) {
            // 图表区域
            GeometryReader { geometry in
                ZStack {
                    // 背景网格
                    VStack(spacing: 0) {
                        ForEach(0..<4) { i in
                            Divider()
                                .background(chartGridColor)
                            Spacer()
                        }
                        Divider()
                            .background(chartGridColor)
                    }
                    
                    HStack(spacing: 0) {
                        ForEach(0..<5) { i in
                            Divider()
                                .background(chartGridColor)
                            Spacer()
                        }
                        Divider()
                            .background(chartGridColor)
                    }
                    
                    // 折线图 - 使用渐变和阴影增强视觉效果
                    if chartData.count > 1 {
                        WeightLineChart(
                            data: chartData,
                            minWeight: minWeight,
                            maxWeight: maxWeight,
                            lineColor: chartLineColor
                        )
                        .shadow(color: chartLineColor.opacity(0.3), radius: 3, x: 0, y: 2)
                    }
                    
                    // 数据点 - 增加外环和阴影效果
                    ForEach(chartData) { item in
                        let xPosition = getXPosition(for: item.date, width: geometry.size.width)
                        let yPosition = getYPosition(for: item.weight, height: geometry.size.height)
                        
                        ZStack {
                            // 外环
                            Circle()
                                .stroke(chartLineColor, lineWidth: 2)
                                .frame(width: 12, height: 12)
                            
                            // 内圆点
                            Circle()
                                .fill(backgroundColor)
                                .frame(width: 6, height: 6)
                        }
                        .shadow(color: chartLineColor.opacity(0.3), radius: 2, x: 0, y: 1)
                        .position(x: xPosition, y: yPosition)
                    }
                }
            }
            
            // X轴标签
            HStack {
                Text("12 AM")
                Spacer()
                Text("6")
                Spacer()
                Text("12 PM")
                Spacer()
                Text("6")
                Spacer()
                Text("")
            }
            .font(.system(size: 12))
            .foregroundColor(.gray)
            .padding(.top, 4)
            
            // Y轴标签
            HStack(alignment: .top) {
                VStack(alignment: .trailing, spacing: 0) {
                    Text("\(Int(maxWeight))")
                    Spacer()
                    Text("\(Int(maxWeight - (maxWeight - minWeight) / 3))")
                    Spacer()
                    Text("\(Int(maxWeight - 2 * (maxWeight - minWeight) / 3))")
                    Spacer()
                    Text("\(Int(minWeight))")
                }
                .font(.system(size: 12))
                .foregroundColor(.gray)
                
                Spacer()
            }
            .padding(.leading, -8)
            .padding(.top, -290)
        }
    }
    
    // MARK: - 辅助方法
    
    // 获取X坐标位置
    private func getXPosition(for date: Date, width: CGFloat) -> CGFloat {
        let dateRange = getDateRange()
        let totalSeconds = dateRange.upperBound.timeIntervalSince(dateRange.lowerBound)
        let seconds = date.timeIntervalSince(dateRange.lowerBound)
        
        let proportion = totalSeconds > 0 ? seconds / totalSeconds : 0
        return proportion * width
    }
    
    // 获取Y坐标位置
    private func getYPosition(for weight: Double, height: CGFloat) -> CGFloat {
        let range = maxWeight - minWeight
        let proportion = range > 0 ? (maxWeight - weight) / range : 0
        return proportion * height
    }
    
    // 获取日期范围
    private func getDateRange() -> ClosedRange<Date> {
        let calendar = Calendar.current
        let now = Date()
        let endDate = calendar.startOfDay(for: now)
        var startDate: Date
        
        switch selectedTimeRangeIndex {
        case 0: // 日
            startDate = calendar.date(byAdding: .day, value: -1, to: endDate)!
        case 1: // 周
            startDate = calendar.date(byAdding: .day, value: -7, to: endDate)!
        case 2: // 月
            startDate = calendar.date(byAdding: .month, value: -1, to: endDate)!
        case 3: // 6个月
            startDate = calendar.date(byAdding: .month, value: -6, to: endDate)!
        case 4: // 年
            startDate = calendar.date(byAdding: .year, value: -1, to: endDate)!
        default:
            startDate = calendar.date(byAdding: .day, value: -1, to: endDate)!
        }
        
        return startDate...calendar.date(byAdding: .day, value: 1, to: endDate)!
    }
    
    // 加载体重数据
    private func loadWeightData() {
        if let data = UserDefaults.standard.data(forKey: "savedWeightData") {
            if let decoded = try? JSONDecoder().decode([WeightData].self, from: data) {
                weightEntries = decoded
                updateAverageWeight()
                
                // 如果没有数据，添加一些样本数据
                if weightEntries.isEmpty {
                    addSampleData()
                }
            }
        } else {
            // 首次运行时添加样本数据
            addSampleData()
        }
    }
    
    // 添加样本数据
    private func addSampleData() {
        let calendar = Calendar.current
        let now = Date()
        
        // 添加3天前的数据
        if let threeDaysAgo = calendar.date(byAdding: .day, value: -3, to: now) {
            weightEntries.append(WeightData(date: threeDaysAgo, weight: 103.2))
        }
        
        // 添加2天前的数据
        if let twoDaysAgo = calendar.date(byAdding: .day, value: -2, to: now) {
            weightEntries.append(WeightData(date: twoDaysAgo, weight: 104.1))
        }
        
        // 添加1天前的数据
        if let oneDayAgo = calendar.date(byAdding: .day, value: -1, to: now),
           let noon = calendar.date(bySettingHour: 12, minute: 0, second: 0, of: oneDayAgo) {
            weightEntries.append(WeightData(date: noon, weight: 103.8))
        }
        
        // 添加今天的数据
        if let noon = calendar.date(bySettingHour: 12, minute: 0, second: 0, of: now) {
            weightEntries.append(WeightData(date: noon, weight: 102.5))
        }
        
        // 添加今天晚上的数据
        if let evening = calendar.date(bySettingHour: 18, minute: 0, second: 0, of: now) {
            weightEntries.append(WeightData(date: evening, weight: 101.3))
        }
        
        // 保存样本数据
        saveWeightData()
    }
    
    // 保存体重数据
    private func saveWeightData() {
        if let encoded = try? JSONEncoder().encode(weightEntries) {
            UserDefaults.standard.set(encoded, forKey: "savedWeightData")
        }
    }
    
    // 添加新的体重记录
    private func saveNewWeightData() {
        guard let weightValue = Double(newWeight), weightValue > 0 else { return }
        
        // 创建日期时间
        var dateComponents = Calendar.current.dateComponents([.year, .month, .day], from: selectedDate)
        let timeComponents = Calendar.current.dateComponents([.hour, .minute], from: selectedTime)
        dateComponents.hour = timeComponents.hour
        dateComponents.minute = timeComponents.minute
        
        if let combinedDate = Calendar.current.date(from: dateComponents) {
            let newEntry = WeightData(date: combinedDate, weight: weightValue)
            weightEntries.append(newEntry)
            saveWeightData()
            updateAverageWeight()
            updateChartData()
        }
        
        // 重置表单
        newWeight = ""
    }
    
    // 更新平均体重
    private func updateAverageWeight() {
        let calendar = Calendar.current
        let now = Date()
        
        // 查找今天的条目
        let todayEntries = weightEntries.filter {
            calendar.isDate($0.date, inSameDayAs: now)
        }
        
        // 如果有今天的数据，计算平均值
        if !todayEntries.isEmpty {
            let sum = todayEntries.reduce(0.0) { $0 + $1.weight }
            averageWeight = sum / Double(todayEntries.count)
        } else {
            // 否则查找最近的条目
            let sortedEntries = weightEntries.sorted { $0.date > $1.date }
            if let latestEntry = sortedEntries.first {
                averageWeight = latestEntry.weight
            }
        }
    }
    
    // 更新图表数据
    private func updateChartData() {
        let calendar = Calendar.current
        let now = Date()
        let dateRange = getDateRange()
        
        // 过滤出在时间范围内的条目
        let filteredEntries = weightEntries.filter {
            $0.date >= dateRange.lowerBound && $0.date <= dateRange.upperBound
        }
        
        // 按日期排序
        let sortedEntries = filteredEntries.sorted { $0.date < $1.date }
        
        chartData = sortedEntries
        
        // 更新最小和最大体重值，用于图表缩放
        if !sortedEntries.isEmpty {
            let weights = sortedEntries.map { $0.weight }
            if let min = weights.min(), let max = weights.max() {
                // 添加一些边距使图表更美观
                minWeight = min - 10
                maxWeight = max + 10
            }
        }
    }
}

// MARK: - 折线图组件
struct WeightLineChart: View {
    let data: [WeightData]
    let minWeight: Double
    let maxWeight: Double
    let lineColor: Color
    
    var body: some View {
        GeometryReader { geometry in
            // 添加渐变填充区域
            ZStack {
                // 渐变填充区域
                fillPath(in: geometry.size)
                    .fill(
                        LinearGradient(
                            gradient: Gradient(colors: [
                                lineColor.opacity(0.3),
                                lineColor.opacity(0.05)
                            ]),
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    )
                
                // 线条路径
                Path { path in
                    guard data.count > 1 else { return }
                    
                    let sortedData = data.sorted { $0.date < $1.date }
                    
                    // 计算第一个点的位置
                    let firstPoint = getPoint(for: sortedData[0], in: geometry.size)
                    path.move(to: firstPoint)
                    
                    // 绘制其余点 - 使用平滑曲线
                    for i in 1..<sortedData.count {
                        let point = getPoint(for: sortedData[i], in: geometry.size)
                        
                        // 使用贝塞尔曲线创建平滑效果
                        if i < sortedData.count - 1 {
                            let nextPoint = getPoint(for: sortedData[i+1], in: geometry.size)
                            let controlPoint1 = CGPoint(
                                x: point.x - (point.x - firstPoint.x) * 0.2,
                                y: point.y
                            )
                            let controlPoint2 = CGPoint(
                                x: nextPoint.x - (nextPoint.x - point.x) * 0.8,
                                y: nextPoint.y
                            )
                            path.addCurve(to: nextPoint, control1: controlPoint1, control2: controlPoint2)
                            path.move(to: point)
                        }
                        
                        path.addLine(to: point)
                    }
                }
                .stroke(lineColor, style: StrokeStyle(lineWidth: 2.5, lineCap: .round, lineJoin: .round))
            }
        }
    }
    
    // 创建填充区域的路径
    private func fillPath(in size: CGSize) -> Path {
        Path { path in
            guard data.count > 1 else { return }
            
            let sortedData = data.sorted { $0.date < $1.date }
            
            // 计算第一个点的位置
            let firstPoint = getPoint(for: sortedData[0], in: size)
            path.move(to: CGPoint(x: firstPoint.x, y: size.height)) // 从底部开始
            path.addLine(to: firstPoint) // 连接到第一个数据点
            
            // 绘制其余点
            for i in 1..<sortedData.count {
                let point = getPoint(for: sortedData[i], in: size)
                path.addLine(to: point)
            }
            
            // 连接到右下角和左下角，形成封闭区域
            if let lastPoint = sortedData.last.map({ getPoint(for: $0, in: size) }) {
                path.addLine(to: CGPoint(x: lastPoint.x, y: size.height))
                path.addLine(to: CGPoint(x: firstPoint.x, y: size.height))
            }
        }
    }
    
    // 计算数据点在图表中的位置
    private func getPoint(for item: WeightData, in size: CGSize) -> CGPoint {
        let dateRange = getDateRange(for: data)
        let totalSeconds = dateRange.upperBound.timeIntervalSince(dateRange.lowerBound)
        let seconds = item.date.timeIntervalSince(dateRange.lowerBound)
        
        let xProportion = totalSeconds > 0 ? seconds / totalSeconds : 0
        let x = xProportion * size.width
        
        let range = maxWeight - minWeight
        let yProportion = range > 0 ? (maxWeight - item.weight) / range : 0
        let y = yProportion * size.height
        
        return CGPoint(x: x, y: y)
    }
    
    // 获取数据的日期范围
    private func getDateRange(for data: [WeightData]) -> ClosedRange<Date> {
        if let minDate = data.map({ $0.date }).min(),
           let maxDate = data.map({ $0.date }).max() {
            return minDate...maxDate
        }
        return Date()...Date()
    }
}

// MARK: - 添加体重数据视图
struct AddWeightDataView: View {
    @Binding var isPresented: Bool
    @Binding var date: Date
    @Binding var time: Date
    @Binding var weight: String
    @Environment(\.colorScheme) var colorScheme
    var onSave: () -> Void
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Date & Time")) {
                    DatePicker("Date", selection: $date, displayedComponents: .date)
                    DatePicker("Time", selection: $time, displayedComponents: .hourAndMinute)
                }
                
                Section(header: Text("Weight")) {
                    HStack {
                        TextField("Weight", text: $weight)
                            .keyboardType(.decimalPad)
                        Text("lbs")
                            .foregroundColor(.gray)
                    }
                }
            }
            .navigationBarTitle("Add Weight", displayMode: .inline)
            .navigationBarItems(
                leading: Button("Cancel") {
                    isPresented = false
                },
                trailing: Button("Save") {
                    onSave()
                    isPresented = false
                }
                .disabled(weight.isEmpty || Double(weight) == nil)
            )
        }
    }
}

// MARK: - 预览
struct WeightDetailView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            WeightDetailView()
                .preferredColorScheme(.dark)
                .previewDisplayName("Dark Mode")
            
            WeightDetailView()
                .preferredColorScheme(.light)
                .previewDisplayName("Light Mode")
        }
    }
}
