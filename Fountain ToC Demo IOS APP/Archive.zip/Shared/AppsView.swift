
import SwiftUI

struct AppsView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Button(action: {
                    // 处理返回按钮操作
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.blue)
                    Text("Profile")
                        .foregroundColor(.blue)
                }
                Spacer()
            }
            .padding()
            
            Text("Apps")
                .font(.title2)
                .bold()
                .frame(maxWidth: .infinity, alignment: .center)
                .padding(.top, -10)
            
            Text("Apps")
                .font(.caption)
                .foregroundColor(.gray)
                .padding(.leading)
            
            TextField("None", text: .constant(""))
                .padding()
                .background(RoundedRectangle(cornerRadius: 10).fill(colorScheme == .dark ? Color.black.opacity(0.2) : Color.white))
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray.opacity(0.5)))
                .padding(.horizontal)
                
            Text("As apps request permission to update your Health data, they will be added to the list.")
                .font(.footnote)
                .foregroundColor(.gray)
                .padding(.horizontal)
            
            Spacer()
        }
        .background(colorScheme == .dark ? Color.black : Color(UIColor.systemGray6))
        .edgesIgnoringSafeArea(.bottom)
    }
}

struct AppsView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            AppsView()
                .preferredColorScheme(.light)
            AppsView()
                .preferredColorScheme(.dark)
        }
    }
}

