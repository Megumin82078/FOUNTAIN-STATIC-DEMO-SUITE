import SwiftUI

struct HealthRecordsView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    // 顶部卡片
                    VStack(spacing: 15) {
                        Image(systemName: "cross.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 60, height: 60)
                            .foregroundColor(.blue)
                        
                        Text("Access Your Records")
                            .font(.title2)
                            .bold()
                            .foregroundColor(.primary)
                        
                        Text("Connect to your provider to see your health records and get updates when there’s a new entry.")
                            .font(.body)
                            .multilineTextAlignment(.center)
                            .foregroundColor(.secondary)
                            .padding(.horizontal)
                        
                        Button(action: {
                            // 按钮操作
                        }) {
                            Text("Get Started")
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .padding(.horizontal)
                        }
                    }
                    .padding()
                    .background(Color(UIColor.systemBackground))
                    .cornerRadius(12)
                    .shadow(radius: colorScheme == .light ? 5 : 0)
                    .padding(.horizontal)
                    
                    // 分割信息
                    Text("APPS")
                        .font(.headline)
                        .foregroundColor(.primary)
                        .padding(.horizontal)
                    
                    Text("None")
                        .foregroundColor(.gray)
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color(UIColor.secondarySystemBackground))
                        .cornerRadius(10)
                        .padding(.horizontal)
                    
                    Text("Apps requesting access to your records appear here.")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                        .padding(.horizontal)
                    
                    // Research Studies
                    Text("RESEARCH STUDIES")
                        .font(.headline)
                        .foregroundColor(.primary)
                        .padding(.horizontal)
                    
                    Text("None")
                        .foregroundColor(.gray)
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color(UIColor.secondarySystemBackground))
                        .cornerRadius(10)
                        .padding(.horizontal)
                    
                    Text("As research studies request permission to read your data, they will be added to the list.")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                        .padding(.horizontal)
                    
                    // 选项
                    NavigationLink(destination: Text("Options Page")) {
                        HStack {
                            Text("Options")
                            Spacer()
                            Image(systemName: "chevron.right")
                        }
                        .padding()
                        .background(Color(UIColor.secondarySystemBackground))
                        .cornerRadius(10)
                        .padding(.horizontal)
                    }
                }
                .padding(.top)
            }
            .navigationTitle("Health Records")
            .navigationBarItems(leading: Button(action: {
                // 返回操作
            }) {
                HStack {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.blue)
                     Button("Profile") {
                        presentationMode.wrappedValue.dismiss()
                    }
                        .foregroundColor(.blue)
                }
            }, trailing: Button("Done") {
                // 完成操作
                presentationMode.wrappedValue.dismiss()
            })
        }
    }
}

struct HealthRecordsView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            HealthRecordsView()
                .preferredColorScheme(.light)
            HealthRecordsView()
                .preferredColorScheme(.dark)
        }
    }
}