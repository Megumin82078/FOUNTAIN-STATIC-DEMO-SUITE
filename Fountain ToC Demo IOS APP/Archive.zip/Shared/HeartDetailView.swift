import SwiftUI

struct HeartDetailView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) private var colorScheme
    
    // 接收的健康分类
    var category: BrowseView.HealthCategory
    
    // 心脏相关数据项
    struct HeartDataItem: Identifiable {
        let id = UUID()
        let title: String
    }
    
    // 心脏数据列表
    let heartDataItems: [HeartDataItem] = [
        HeartDataItem(title: "Average Walking Heart Rate"),
        HeartDataItem(title: "Low Heart Rate Notifications"),
        HeartDataItem(title: "Atrial Fibrillation History"),
        HeartDataItem(title: "High Heart Rate Notifications"),
        HeartDataItem(title: "Resting Heart Rate"),
        HeartDataItem(title: "Perfusion Index"),
        HeartDataItem(title: "ECG"),
        HeartDataItem(title: "Heart Rate"),
        HeartDataItem(title: "Heart Rate Variability"),
        HeartDataItem(title: "Blood Pressure"),
        HeartDataItem(title: "AFib Monitoring"),
        HeartDataItem(title: "Cardio Recovery"),
        HeartDataItem(title: "Cardio Fitness"),
        HeartDataItem(title: "Cardio Fitness Notifications")
    ]
    
    // 关于心脏的文章
    struct HeartArticle: Identifiable {
        let id = UUID()
        let title: String
        let subtitle: String
        let backgroundColor: Color
    }
    
    // 文章数据
    let heartArticles: [HeartArticle] = [
        HeartArticle(
            title: "Understanding Low Cardio Fitness Levels",
            subtitle: "What you can do to improve.",
            backgroundColor: Color.gray.opacity(0.3) // 使用灰色背景代替图片
        )
    ]
    
    // 根据当前主题获取背景色
    var backgroundColor: Color {
        colorScheme == .dark ? Color.black : Color.white
    }
    
    // 根据当前主题获取文本颜色
    var textColor: Color {
        colorScheme == .dark ? Color.white : Color.black
    }
    
    // 根据当前主题获取列表背景色
    var listBackgroundColor: Color {
        colorScheme == .dark ? Color(UIColor.systemGray6).opacity(0.3) : Color(UIColor.systemGray6).opacity(0.5)
    }
    
    // 根据当前主题获取卡片背景色
    var cardBackgroundColor: Color {
        colorScheme == .dark ? .black : Color(UIColor.systemGroupedBackground)
    }
    
    // 根据当前主题获取分割线颜色
    var dividerColor: Color {
        colorScheme == .dark ? Color.gray.opacity(0.3) : Color.gray.opacity(0.2)
    }
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                // 自定义导航栏
                HStack {
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        HStack(spacing: 5) {
                            Image(systemName: "chevron.left")
                                .foregroundColor(Color.blue)
                                .font(.system(size: 16, weight: .semibold))
                            Text("Browse")
                                .foregroundColor(Color.blue)
                                .font(.system(size: 17))
                        }
                    }
                    Spacer()
                }
                .padding(.horizontal)
                .padding(.top, 10)
                .padding(.bottom, 5)
                
                // 标题
                Text("Heart")
                    .font(.system(size: 34, weight: .bold))
                    .foregroundColor(textColor)
                    .padding(.horizontal)
                    .padding(.bottom, 5)
                
                // 没有可用数据提示
                Text("No Data Available")
                    .font(.system(size: 20))
                    .foregroundColor(Color.gray)
                    .padding(.horizontal)
                    .padding(.bottom, 20)
                
                // 心脏数据列表 - 卡片式
                VStack(spacing: 0) {
                    ForEach(heartDataItems) { item in
                       NavigationLink(destination: WalkingHeartRateView(title: item.title)) {
                            HStack {
                                Text(item.title)
                                    .foregroundColor(textColor)
                                    .font(.system(size: 17))
                                
                                Spacer()
                                
                                Image(systemName: "chevron.right")
                                    .foregroundColor(Color(UIColor.systemGray4))
                                    .font(.system(size: 14))
                            }
                            .padding(.vertical, 14)
                            .padding(.horizontal)
                        }
                        .buttonStyle(PlainButtonStyle())
                        
                        if item.id != heartDataItems.last?.id {
                            Divider()
                                .background(dividerColor)
                                .padding(.leading, 16)
                        }
                    }
                }
                .background(cardBackgroundColor)
                .cornerRadius(12)
                .padding(.horizontal)
                .padding(.bottom, 20)
                .shadow(color: Color.black.opacity(0.2), radius: 3, x: 0, y: 2) // 增强阴影效果
                
                // 关于心脏标题
                Text("About Heart Health")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundColor(textColor)
                    .padding(.horizontal)
                    .padding(.bottom, 10)
                
                // 关于心脏的文章 - 卡片式
                VStack(spacing: 15) {
                    ForEach(heartArticles) { article in
                        VStack(alignment: .leading, spacing: 0) {
                            // 文章背景色区域（代替图片）
                            Rectangle()
                                .fill(article.backgroundColor)
                                .frame(height: 200)
                                .cornerRadius(12, corners: [.topLeft, .topRight])
                            
                            // 文章标题和副标题
                            VStack(alignment: .leading, spacing: 5) {
                                Text(article.title)
                                    .font(.system(size: 20, weight: .bold))
                                    .foregroundColor(textColor)
                                
                                Text(article.subtitle)
                                    .font(.system(size: 16))
                                    .foregroundColor(Color.gray)
                            }
                            .padding()
                        }
                        .background(cardBackgroundColor)
                        .cornerRadius(12)
                        .shadow(color: Color.black.opacity(0.2), radius: 3, x: 0, y: 2) // 增强阴影效果
                    }
                }
                .padding(.horizontal)
                .padding(.bottom, 30)
            }
        }
        .background(backgroundColor.edgesIgnoringSafeArea(.all))
        .navigationBarHidden(true)
    }
}

// 扩展View以支持部分圆角
extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}

// 自定义形状以支持部分圆角
struct RoundedCorner: Shape {
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners
    
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}

struct HeartDetailView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            HeartDetailView(category: BrowseView.HealthCategory(icon: "heart.fill", name: "心脏", color: .red, isSystemIcon: true))
                .preferredColorScheme(.dark)
                .previewDisplayName("Dark Mode")
            
            HeartDetailView(category: BrowseView.HealthCategory(icon: "heart.fill", name: "心脏", color: .red, isSystemIcon: true))
                .preferredColorScheme(.light)
                .previewDisplayName("Light Mode")
        }
    }
}
