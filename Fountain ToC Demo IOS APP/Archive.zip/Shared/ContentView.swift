import SwiftUI

struct UserProfile: Codable {
    var name: String
    var fountainID: String
    
    static let defaultProfile = UserProfile(
        name: "Lee Jason",
        fountainID: "LEEJ-6666-8888"
    )
}

struct ContentView: View {
    var body: some View {
        TabView {
            NavigationView {
                SummaryView()
            }
            .tabItem {
                Label("Summary", systemImage: "heart.fill")
            }

            NavigationView {
                SharingView()
            }
            .tabItem {
                Label("Sharing", systemImage: "person.2.fill")
            }

            NavigationView {
                BrowseView()
            }
            .tabItem {
                Label("Browse", systemImage: "square.grid.2x2.fill")
            }
        }
    }
}
struct SummaryView: View {
    @State private var showTitle: Bool = false
    @State private var showProfile: Bool = false
    @Environment(\.colorScheme) var colorScheme
    @State private var favoriteItems: [FavoriteData] = [
        FavoriteData(name: "Workout", isFavorite: false),
        FavoriteData(name: "Floors Climbed", isFavorite: false),
        FavoriteData(name: "Steps", isFavorite: true),
        FavoriteData(name: "Walking+Running Distance", isFavorite: false),
        FavoriteData(name: "Active Energy", isFavorite: false),
        FavoriteData(name: "Resting Energy", isFavorite: false),
        FavoriteData(name: "Headphone Audio", isFavorite: false),
        FavoriteData(name: "Double Support Time", isFavorite: false),
        FavoriteData(name: "Stride Asymmetry", isFavorite: false),
        FavoriteData(name: "Stride Length", isFavorite: false),
        FavoriteData(name: "Walking Speed", isFavorite: false)
    ]
    @State private var totalStepsCount: Int = 0
    @State private var stepEntries: [StepData] = []
    @State private var averageWeight: Double = 102.5 // 默认值
    @State private var weightEntries: [WeightData] = []
    @State private var showEditFavorites = false
     private func loadStepData() {
        if let data = UserDefaults.standard.data(forKey: "savedStepData") {
            if let decoded = try? JSONDecoder().decode([StepData].self, from: data) {
                stepEntries = decoded
                updateStatistics()
            }
        }
    }
    // 加载体重数据
    private func loadWeightData() {
        if let data = UserDefaults.standard.data(forKey: "savedWeightData") {
            if let decoded = try? JSONDecoder().decode([WeightData].self, from: data) {
                weightEntries = decoded
                updateAverageWeight()
            }
        }
    }
     // 更新平均体重
    private func updateAverageWeight() {
        let calendar = Calendar.current
        let now = Date()
        // 查找今天的条目
        let todayEntries = weightEntries.filter {
            calendar.isDate($0.date, inSameDayAs: now)
        }
        // 如果有今天的数据，计算平均值
        if !todayEntries.isEmpty {
            let sum = todayEntries.reduce(0.0) { $0 + $1.weight }
            averageWeight = sum / Double(todayEntries.count)
        }
    }
     // 更新统计数据
    private func updateStatistics() {
        let calendar = Calendar.current
        let now = Date()
        
        // 计算当天的步数总和
        let todaySteps = stepEntries.filter {
            calendar.isDate($0.date, inSameDayAs: now)
        }
        totalStepsCount = todaySteps.reduce(0) { $0 + $1.count }
        print("totalStepsCount:",totalStepsCount)
    }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                GeometryReader { geometry in
                    Color.clear
                        .preference(key: ScrollOffsetPreferenceKey.self, value: geometry.frame(in: .global).minY)
                }
                .frame(height: 0)
                
                HStack {
                    Text("Summary")
                        .font(.largeTitle)
                        .bold()
                    Spacer()
                    Button(action: {
                        showProfile = true
                    }) {
                        Image(systemName: "person.crop.circle.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 35, height: 35)
                            .clipShape(Circle())
                            .foregroundColor(.gray)
                    }
                }
                .padding(.horizontal)
                .padding(.top, 15)

                HStack {
                    Text("Favorites")
                        .font(.headline)
                        .foregroundColor(.secondary)
                    Spacer()
                    Button("Edit") {
                        showEditFavorites = true
                    }
                    .foregroundColor(.blue)
                }
                .padding(.horizontal)

                VStack(spacing: 12) {
                     NavigationLink {
                        StepsDetailView()
                    } label: {
                        HealthDataCard(title: "Steps", value: String(totalStepsCount), unit: "steps", color: .orange, showSubtitle: true)
                    }
                    .buttonStyle(.plain)
                    NavigationLink {
                        WeightDetailView()
                    } label: {
                        HealthDataCard(title: "Weight", value: String(averageWeight), unit: "lbs", color: .blue, showSubtitle: false)
                    }.buttonStyle(.plain)
                    //  NavigationLink {
                    //     MindfulnessDetailView()
                    // } label: {
                    //     HealthDataCard(title: "Mindfulness", value: "1", unit: "min", color: .orange, showSubtitle: true)
                    // }.buttonStyle(.plain)
                }
                .padding(.top, 10)
                // NavigationLink {
                //     AllHealthDataView()
                // } label: {
                //     HealthOptionCard(title: "Show All Health Data", icon: "heart.fill")
                // }.buttonStyle(.plain)
                NavigationLink {
                    HealthRecordView()
                } label: {
                    HealthOptionCard(title: "Health record", icon: "heart.text.square")
                }.buttonStyle(.plain)
                NavigationLink {
                    HealthAnalysisView()
                } label: {
                    HealthOptionCard(title: "AI intelligent analysis", icon: "brain.head.profile")
                }.buttonStyle(.plain)
                 NavigationLink {
                    AccessRecordView()
                } label: {
                    HealthOptionCard(title: "Data access record", icon: "doc.text.magnifyingglass")
                }.buttonStyle(.plain)
                
                // 添加水平边距到 ArticlesView
                ArticlesView()
                    .padding(.top, 20)
            }
            .padding(.bottom, 20)
        }
        .background(colorScheme == .dark ? Color.black : Color(.systemGroupedBackground))
        .onPreferenceChange(ScrollOffsetPreferenceKey.self) { value in
            showTitle = value < -10
        }
        .navigationTitle(showTitle ? "Summary" : " ")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showProfile) {
            ProfileView()
        }
        .sheet(isPresented: $showEditFavorites) {
            EditFavoritesView(favoriteItems: $favoriteItems)
        }
        // page on appear
        .onAppear {
            loadStepData()
            loadWeightData()
        }
    }
}

struct ProfileView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var showHealthDetail = false
    @State private var showMedicalID = false
    @State private var showHealthChecklist = false
    @State private var showHealthRecords = false
    @State private var showNotifications = false
    @State private var showApp = false
    @State private var showResearchStudies = false
    
    // 用户信息状态
    @State private var userProfile = UserProfile.defaultProfile

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Spacer()
                Image(systemName: "person.crop.circle.fill")
                    .resizable()
                    .frame(width: 100, height: 100)
                    .clipShape(Circle())
                    .foregroundColor(.gray)
                
                Text(userProfile.name)
                    .font(.title)
                    .bold()
                Text("Fountain ID: \(userProfile.fountainID)")
                    .font(.title3)
                    .bold()
                List {
                    Section {
                        Button(action: { showHealthDetail = true }) {
                            ProfileRow(title: "Health Details", showArrow: true)
                        }
                        .sheet(isPresented: $showHealthDetail) {
                            HealthDetailsAView(userProfile: $userProfile)
                        }.buttonStyle(.plain)
                        Button(action: { showMedicalID = true }) {
                            ProfileRow(title: "Fountain Card", showArrow: true)
                        }.buttonStyle(.plain)
                        .sheet(isPresented: $showMedicalID) {
                            WalletCardView()
                        }.buttonStyle(.plain)
                    }
                    Section(header: Text("Features")) {
                        Button(action: { showHealthChecklist = true }) {
                            ProfileRow(title: "Health Checklist",showArrow: true)
                        }.buttonStyle(.plain)
                        .sheet(isPresented: $showHealthChecklist) {
                            HealthChecklistView()
                        }.buttonStyle(.plain)
                        NavigationLink() {
                            HealthRecordView()
                        } label: {
                           ProfileRow(title: "Health Records",showArrow: false)
                        }
                        // Button(action: { showHealthRecords = true }) {
                        //     ProfileRow(title: "Health Records")
                        // }.buttonStyle(.plain)
                        // .sheet(isPresented: $showHealthRecords) {
                        //     HealthRecordView()
                        // }.buttonStyle(.plain)
                        Button(action: { showNotifications = true }) {
                            ProfileRow(title: "Notifications",showArrow: true)
                        }.buttonStyle(.plain)
                        .sheet(isPresented: $showNotifications) {
                            NotificationsView()
                        }.buttonStyle(.plain)
                    }
                    Section(header: Text("Privacy")) {
                        Button(action: { showApp = true }) {
                            ProfileRow(title: "Apps",showArrow: true)
                        }.buttonStyle(.plain)
                        .sheet(isPresented: $showApp) {
                            AppsView()
                        }
                        Button(action: { showResearchStudies = true }) {
                            ProfileRow(title: "Research Studies",showArrow: true)
                        }.buttonStyle(.plain)
                        .sheet(isPresented: $showResearchStudies) {
                            ResearchStudiesView()
                        }
                    }
                }
                .listStyle(InsetGroupedListStyle())
                Spacer()
            }
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarItems(trailing: Button("Done") {
                presentationMode.wrappedValue.dismiss()
            })
        }
        .onAppear {
            // 加载保存的用户信息
            loadUserProfile()
        }
    }
    
    // 加载用户信息
    private func loadUserProfile() {
        if let data = UserDefaults.standard.data(forKey: "userProfile") {
            if let decoded = try? JSONDecoder().decode(UserProfile.self, from: data) {
                userProfile = decoded
            }
        }
    }
}

struct HealthDetailsAView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) var colorScheme
    @Binding var userProfile: UserProfile
    
    // 编辑状态
    @State private var isEditing = false
    @State private var editedName: String = ""
    @State private var editedFountainID: String = ""
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Personal Information")) {
                    if isEditing {
                        TextField("Name", text: $editedName)
                        TextField("Fountain ID", text: $editedFountainID)
                    } else {
                        HStack {
                            Text("Name")
                            Spacer()
                            Text(userProfile.name)
                                .foregroundColor(.secondary)
                        }
                        
                        HStack {
                            Text("Fountain ID")
                            Spacer()
                            Text(userProfile.fountainID)
                                .foregroundColor(.secondary)
                        }
                    }
                }
                
                // 可以添加更多健康详情部分
                Section(header: Text("Health Information")) {
                    HStack {
                        Text("Blood Type")
                        Spacer()
                        Text("O+")
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Text("Height")
                        Spacer()
                        Text("5'10\"")
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Text("Weight")
                        Spacer()
                        Text("160 lbs")
                            .foregroundColor(.secondary)
                    }
                }
            }
            .navigationBarTitle("Health Details", displayMode: .inline)
            .navigationBarItems(
                leading: Button("Cancel") {
                    if isEditing {
                        // 取消编辑
                        isEditing = false
                        editedName = userProfile.name
                        editedFountainID = userProfile.fountainID
                    } else {
                        presentationMode.wrappedValue.dismiss()
                    }
                },
                trailing: Button(isEditing ? "Save" : "Edit") {
                    if isEditing {
                        // 保存编辑
                        userProfile.name = editedName
                        userProfile.fountainID = editedFountainID
                        saveUserProfile()
                        isEditing = false
                    } else {
                        // 开始编辑
                        editedName = userProfile.name
                        editedFountainID = userProfile.fountainID
                        isEditing = true
                    }
                }
            )
            .onAppear {
                editedName = userProfile.name
                editedFountainID = userProfile.fountainID
            }
        }
    }
    
    // 保存用户信息到本地
    private func saveUserProfile() {
        if let encoded = try? JSONEncoder().encode(userProfile) {
            UserDefaults.standard.set(encoded, forKey: "userProfile")
        }
    }
}

struct EditFavoritesView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) var colorScheme // 添加颜色方案监听
    @Binding var favoriteItems: [FavoriteData]
    
    let categories = [
        ("Fitness", [
            "Steps", "weight"
            // "Workout", "Floors Climbed", "Steps", "Walking+Running Distance", "Active Energy", "Resting Energy"
        ]),
        // ("Hearing", [
        //     "Headphone Audio"
        // ]),
        // ("Mobility", [
        //     "Double Support Time", "Stride Asymmetry", "Stride Length", "Walking Speed"
        // ])
    ]
    
    // 动态颜色计算属性
    private var backgroundColor: Color {
        colorScheme == .dark ? Color(.systemBackground) : Color(.systemGray6)
    }
    
    private var sectionBackground: Color {
        colorScheme == .dark ? Color(.systemGray5) : Color(.systemGray5)
    }
    
    private var textColor: Color {
        colorScheme == .dark ? .white : .primary
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // 顶部选项卡
                HStack {
                    Text("Current Data")
                        .foregroundColor(textColor) // 动态文本颜色
                        .padding(.vertical, 12)
                        .frame(maxWidth: .infinity)
                        .background(sectionBackground.opacity(0.3)) // 动态背景
                        .cornerRadius(8)
                    
                    // Text("All")
                    //     .foregroundColor(textColor)
                    //     .padding(.vertical, 12)
                    //     .frame(maxWidth: .infinity)
                    //     .background(sectionBackground.opacity(0.3))
                    //     .cornerRadius(8)
                }
                .padding(.horizontal)
                .padding(.top, 8)
                
                // 分类列表
                ScrollView {
                    VStack(spacing: 20) {
                        ForEach(categories, id: \.0) { category in
                            CategorySection(
                                title: category.0,
                                items: category.1,
                                favoriteItems: $favoriteItems
                            )
                        }
                    }
                    .padding(.top, 16)
                }
            }
            .background(backgroundColor.edgesIgnoringSafeArea(.all)) // 动态背景
            .navigationTitle("Edit Favorites")
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarItems(
                trailing: Button("Done") {
                    presentationMode.wrappedValue.dismiss()
                }
                .foregroundColor(.accentColor) // 使用系统强调色
            )
        }
    }
}

struct CategorySection: View {
    let title: String
    let items: [String]
    @Binding var favoriteItems: [FavoriteData]
    @Environment(\.colorScheme) var colorScheme // 添加环境变量监听主题
    var categoryIcon: String {
        switch title {
        case "Fitness":
            return "flame.fill"
        case "Hearing":
            return "ear.fill"
        case "Mobility":
            return "figure.walk"
        default:
            return "star.fill"
        }
    }
    
    var categoryColor: Color {
        switch title {
        case "Fitness":
            return .orange
        case "Hearing":
            return .blue
        case "Mobility":
            return .yellow
        default:
            return .gray
        }
    }
    // 动态文本颜色
    var textColor: Color {
        colorScheme == .dark ? .white : .primary
    }
    
    // 动态背景色
    var itemBackground: Color {
        colorScheme == .dark ? Color(.systemGray5) : Color(.systemBackground)
    }
    
    // 分割线颜色
    var dividerColor: Color {
        colorScheme == .dark ? Color.gray.opacity(0.3) : Color.gray.opacity(0.2)
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // 分类标题
            HStack {
                Image(systemName: categoryIcon)
                    .foregroundColor(categoryColor)
                    .font(.title3)
                
                Text(title)
                    .foregroundColor(categoryColor) // 保持分类颜色
                    .font(.title3)
                    .fontWeight(.bold)
            }
            .padding(.horizontal)
            .padding(.bottom, 8)
            
            // 分类项目
            ForEach(items, id: \.self) { item in
                HStack {
                    Text(item)
                        .foregroundColor(textColor) // 动态文本颜色
                        .padding(.vertical, 12)
                    
                    Spacer()
                    
                    Button(action: { toggleFavorite(item) }) {
                        Image(systemName: isFavorite(item) ? "star.fill" : "star")
                            .foregroundColor(.accentColor) // 使用系统强调色
                            .font(.title3)
                    }
                }
                .padding(.horizontal)
                .background(itemBackground) // 动态背景色
                
                Divider()
                    .background(dividerColor) // 动态分割线颜色
                    .padding(.leading)
            }
            .background(Color(.secondarySystemBackground).opacity(0.2)) // 系统背景色
            .cornerRadius(8)
        }
        .padding(.horizontal)
    }

    func isFavorite(_ item: String) -> Bool {
        return favoriteItems.contains { $0.name == item && $0.isFavorite }
    }
    
    func toggleFavorite(_ item: String) {
        if let index = favoriteItems.firstIndex(where: { $0.name == item }) {
            favoriteItems[index].isFavorite.toggle()
        } else {
            favoriteItems.append(FavoriteData(name: item, isFavorite: true))
        }
    }
}

struct ProfileRow: View {
    let title: String
    let showArrow: Bool
    
    var body: some View {
        HStack {
            Text(title)
            Spacer()
            if showArrow {
                Image(systemName: "chevron.right").foregroundColor(.secondary)
            }
                
        }
    }
}

struct ScrollOffsetPreferenceKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = nextValue()
    }
}

struct HealthDataCard: View {
    let title: String
    let value: String
    let unit: String
    let color: Color
    let showSubtitle: Bool
    
    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text(title)
                    .font(.headline)
                    .foregroundColor(color)
                Text("\(value) \(unit)")
                    .font(.title3)
                    .bold()
            }
            Spacer()
            if showSubtitle {
                Text("Today")
                    .foregroundColor(.secondary)
            }
            Image(systemName: "chevron.right")
                .foregroundColor(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(colorScheme == .dark ? Color(.systemGray6) : Color.white)
        .cornerRadius(12)
        .shadow(color: colorScheme == .dark ? Color.clear : Color(.systemGray4), radius: 2, x: 0, y: 2)
        .padding(.horizontal)
    }
}

struct HealthOptionCard: View {
    let title: String
    let icon: String
    
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .foregroundColor(.red)
            Text(title)
                .font(.headline)
            Spacer()
            Image(systemName: "chevron.right")
                .foregroundColor(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(colorScheme == .dark ? Color(.systemGray6) : Color.white)
        .cornerRadius(12)
        .shadow(color: colorScheme == .dark ? Color.clear : Color(.systemGray4), radius: 2, x: 0, y: 2)
        .padding(.horizontal)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct FavoriteData: Identifiable {
    let id = UUID()
    let name: String
    var isFavorite: Bool
}
