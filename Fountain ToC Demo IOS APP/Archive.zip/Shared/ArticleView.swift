import SwiftUI

struct ArticleItem: Identifiable {
    let id = UUID()
    let title: String
    let description: String
    let imageName: String
}

struct ArticlesView: View {
    @State private var selectedArticle: ArticleItem?
    @State private var showArticleDetail = false
    @Environment(\.colorScheme) var colorScheme
    
    let articles: [ArticleItem] = [
        ArticleItem(
            title: "Learn About Cardio Fitness",
            description: "How it's measured, why it matters, and how to improve yours.",
            imageName: "cardio_fitness"
        ),
        ArticleItem(
            title: "Understanding Walking Steadiness",
            description: "What it is and why you should pay attention to it.",
            imageName: "walking_steadiness"
        ),
        ArticleItem(
            title: "Respiratory Rate",
            description: "Learn about respiratory rate and its impact on health. Respiratory rate is the number of breaths you take per minute.",
            imageName: "breathing_rate"
        ),
        ArticleItem(
            title: "Sleep Quality",
            description: "Learn how to get better sleep and its impact on health. Quality sleep is vital for overall wellness.",
            imageName: "sleep_quality"
        )
    ]
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // Header
                Text("Your AI Recommendation")
                    .font(.system(size: 34, weight: .bold))
                    .foregroundColor(.primary)
                    .padding(.top, 16)
                    .padding(.horizontal, 16)
                
                // Article list
                ForEach(articles) { article in
                    Button(action: {
                        self.selectedArticle = article
                        self.showArticleDetail = true
                    }) {
                        ArticleCardView(article: article)
                    }
                    .buttonStyle(PlainButtonStyle())
                }
                .padding(.horizontal, 16)
            }
            .padding(.bottom, 20)
        }
        .background(Color(colorScheme == .dark ? .black : UIColor.systemGray6).edgesIgnoringSafeArea(.all))
        .navigationTitle("")
        .navigationBarHidden(true)
        .sheet(isPresented: $showArticleDetail) {
             MobilityArticleView()
            // if let article = selectedArticle {
            //     // MobilityArticleView()
            // }
        }
    }
}

struct ArticleCardView: View {
    let article: ArticleItem
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        // 整个卡片容器
        VStack(alignment: .leading, spacing: 0) {
            // 图片部分
            imageForArticle(article)
                .frame(maxWidth: .infinity) // 限制最大宽度为父视图宽度
                .frame(height: 200)
                // 使用普通圆角而不是自定义圆角扩展
                .cornerRadius(12)
                .clipped()
            
            // 文本部分
            VStack(alignment: .leading, spacing: 4) {
                Text(article.title)
                    .font(.system(size: 22, weight: .bold))
                    .foregroundColor(.primary)
                    .padding(.top, 12)
                
                Text(article.description)
                    .font(.system(size: 17))
                    .foregroundColor(.secondary)
                    .padding(.top, 4)
                    .padding(.bottom, 12)
                    .lineLimit(3)
            }
            .padding(.horizontal, 16)
            .frame(maxWidth: .infinity) // 确保文本部分也不会超出父视图
            .background(colorScheme == .dark ? Color(UIColor.systemGray6) : Color.white)
        }
        .background(colorScheme == .dark ? Color(UIColor.systemGray6) : Color.white)
        .cornerRadius(12)
        .shadow(color: Color.primary.opacity(0.1), radius: 5, x: 0, y: 2)
        .padding(.bottom, 8)
    }
    
    // 提取图片生成逻辑到单独的方法
    @ViewBuilder
    private func imageForArticle(_ article: ArticleItem) -> some View {
        if article.title.contains("Cardio Fitness") {
            AsyncImage(url: URL(string: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80")) { image in
                image
                    .resizable()
                    .aspectRatio(contentMode: .fill)
            } placeholder: {
                ZStack {
                    Color.blue
                    ProgressView()
                }
            }
        } else if article.title.contains("Walking Steadiness") {
            AsyncImage(url: URL(string: "https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80")) { image in
                image
                    .resizable()
                    .aspectRatio(contentMode: .fill)
            } placeholder: {
                ZStack {
                    Color.blue
                    ProgressView()
                }
            }
        } else if article.title.contains("Respiratory") {
            AsyncImage(url: URL(string: "https://images.unsplash.com/photo-1559757175-5700dde675bc?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80")) { image in
                image
                    .resizable()
                    .aspectRatio(contentMode: .fill)
            } placeholder: {
                ZStack {
                    Color.blue.opacity(colorScheme == .dark ? 0.5 : 0.7)
                    ProgressView()
                }
            }
        } else {
            AsyncImage(url: URL(string: "https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80")) { image in
                image
                    .resizable()
                    .aspectRatio(contentMode: .fill)
            } placeholder: {
                ZStack {
                    Color.blue.opacity(colorScheme == .dark ? 0.5 : 0.7)
                    ProgressView()
                }
            }
        }
    }
}

// 删除自定义圆角扩展和RoundedCorner结构体
// 删除以下代码:
// extension View {
//     func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
//         clipShape(RoundedCorner(radius: radius, corners: corners))
//     }
// }
// 
// struct RoundedCorner: Shape {
//     var radius: CGFloat = .infinity
//     var corners: UIRectCorner = .allCorners
// 
//     func path(in rect: CGRect) -> Path {
//         let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
//         return Path(path.cgPath)
//     }
// }

struct ArticlesView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ArticlesView()
                .previewDisplayName("Light Mode")
            
            ArticlesView()
                .preferredColorScheme(.dark)
                .previewDisplayName("Dark Mode")
        }
    }
}
