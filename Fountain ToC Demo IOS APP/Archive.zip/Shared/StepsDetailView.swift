import SwiftUI

// 步数数据模型
struct StepData: Identifiable, Codable {
    let id = UUID()
    let date: Date
    let count: Int
    let hour: Int
    
    init(date: Date, count: Int) {
        self.date = date
        self.count = count
        self.hour = Calendar.current.component(.hour, from: date)
    }
}

struct StepsDetailView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var selectedTimeRange: TimeRange = .day
    @State private var chartData: [ChartBar] = []
    @State private var showAddDataSheet = false
    @State private var newStepsCount: String = ""
    @State private var selectedDate = Date()
    @State private var selectedTime = Date()
    @Environment(\.colorScheme) var colorScheme
    
    // 数据管理
    @State private var stepEntries: [StepData] = []
    @State private var totalStepsCount: Int = 0
    @State private var averageSteps: Int = 0
    
    enum TimeRange: String, CaseIterable {
        case day = "D"
        case week = "W"
        case month = "M"
        case sixMonths = "6M"
        case year = "Y"
    }
    
    struct ChartBar: Identifiable {
        let id = UUID()
        let value: Double
        let hour: Int
    }
    
    // Dynamic color properties
    var backgroundColor: Color {
        colorScheme == .dark ? Color(.systemBackground) : Color(.systemBackground)
    }
    
    var cardBackground: Color {
        colorScheme == .dark ? Color(UIColor.systemGray6) : Color(UIColor.systemGray5)
    }
    
    var textColor: Color {
        colorScheme == .dark ? .white : .primary
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                // Time Range Picker
                timeRangePicker
                
                // Steps Statistics
                stepsStatistics
                
                // Chart
                chartSection
                
                // Trend Button
                trendButton
                
                // Feed Section
                feedSection
                
                // Steps Feed Card
                stepsFeedCard
            }
        }
        .background(backgroundColor.edgesIgnoringSafeArea(.all))
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarItems(
            leading: backButton,
            trailing: addDataButton
        )
        .toolbar {
            ToolbarItem(placement: .principal) {
                Text("Steps")
                    .foregroundColor(textColor)
                    .font(.system(size: 17, weight: .semibold))
            }
        }
        .sheet(isPresented: $showAddDataSheet) {
            AddStepsDataView(
                isPresented: $showAddDataSheet,
                date: $selectedDate,
                time: $selectedTime,
                stepsCount: $newStepsCount,
                onSave: saveNewStepData
            )
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .onAppear {
            loadStepData()
            generateChartData(for: .day)
        }
    }
    
    // MARK: - 数据管理方法
    
    // 加载步数数据
    private func loadStepData() {
        if let data = UserDefaults.standard.data(forKey: "savedStepData") {
            if let decoded = try? JSONDecoder().decode([StepData].self, from: data) {
                stepEntries = decoded
                updateStatistics()
            }
        }
    }
    
    // 保存步数数据
    private func saveStepData() {
        if let encoded = try? JSONEncoder().encode(stepEntries) {
            UserDefaults.standard.set(encoded, forKey: "savedStepData")
        }
    }
    
    // 添加新的步数记录
    private func saveNewStepData() {
        guard let stepsCount = Int(newStepsCount), stepsCount > 0 else { return }
        
        // 创建日期时间
        var dateComponents = Calendar.current.dateComponents([.year, .month, .day], from: selectedDate)
        let timeComponents = Calendar.current.dateComponents([.hour, .minute], from: selectedTime)
        dateComponents.hour = timeComponents.hour
        dateComponents.minute = timeComponents.minute
        
        if let combinedDate = Calendar.current.date(from: dateComponents) {
            let newEntry = StepData(date: combinedDate, count: stepsCount)
            stepEntries.append(newEntry)
            saveStepData()
            updateStatistics()
            generateChartData(for: selectedTimeRange)
        }
        
        // 重置表单
        newStepsCount = ""
    }
    
    // 更新统计数据
    private func updateStatistics() {
        let calendar = Calendar.current
        let now = Date()
        
        // 计算当天的步数总和
        let todaySteps = stepEntries.filter {
            calendar.isDate($0.date, inSameDayAs: now)
        }
        totalStepsCount = todaySteps.reduce(0) { $0 + $1.count }
        
        // 计算7天平均值
        let oneWeekAgo = calendar.date(byAdding: .day, value: -7, to: now)!
        let weekSteps = stepEntries.filter {
            $0.date >= oneWeekAgo && $0.date <= now
        }
        
        let dayCount = min(7, Set(weekSteps.map { calendar.startOfDay(for: $0.date) }).count)
        averageSteps = dayCount > 0 ? weekSteps.reduce(0) { $0 + $1.count } / dayCount : 0
    }
    
    // MARK: - 图表数据生成
    
    func generateChartData(for timeRange: TimeRange) {
        var newData: [ChartBar] = []
        let calendar = Calendar.current
        let now = Date()
        
        switch timeRange {
        case .day:
            // 使用今天的实际数据
            let todayStart = calendar.startOfDay(for: now)
            
            for hour in 0..<24 {
                if let hourDate = calendar.date(byAdding: .hour, value: hour, to: todayStart) {
                    let hourlySteps = stepEntries.filter {
                        calendar.component(.hour, from: $0.date) == hour &&
                        calendar.isDate($0.date, inSameDayAs: now)
                    }
                    
                    let value = hourlySteps.reduce(0.0) { $0 + Double($1.count) }
                    newData.append(ChartBar(value: value, hour: hour))
                }
            }
            
            // 如果没有今天的数据，填充一些模拟数据
            if newData.allSatisfy({ $0.value == 0 }) {
                for hour in 0..<24 {
                    let value = generateHourlyValue(for: hour)
                    newData[hour] = ChartBar(value: value, hour: hour)
                }
            }
            
        case .week:
            // 过去7天数据
            for day in 0..<7 {
                if let date = calendar.date(byAdding: .day, value: -day, to: now) {
                    let daySteps = stepEntries.filter {
                        calendar.isDate($0.date, inSameDayAs: date)
                    }
                    let value = daySteps.reduce(0.0) { $0 + Double($1.count) }
                    newData.append(ChartBar(value: value, hour: day))
                }
            }
            
        case .month:
            // 过去30天数据
            for day in 0..<30 {
                if let date = calendar.date(byAdding: .day, value: -day, to: now) {
                    let daySteps = stepEntries.filter {
                        calendar.isDate($0.date, inSameDayAs: date)
                    }
                    let value = daySteps.reduce(0.0) { $0 + Double($1.count) }
                    newData.append(ChartBar(value: value, hour: day))
                }
            }
            
        case .sixMonths:
            // 过去6个月数据
            for month in 0..<6 {
                if let date = calendar.date(byAdding: .month, value: -month, to: now) {
                    let monthSteps = stepEntries.filter {
                        let components1 = calendar.dateComponents([.year, .month], from: $0.date)
                        let components2 = calendar.dateComponents([.year, .month], from: date)
                        return components1.year == components2.year && components1.month == components2.month
                    }
                    let value = monthSteps.reduce(0.0) { $0 + Double($1.count) }
                    newData.append(ChartBar(value: value, hour: month))
                }
            }
            
        case .year:
            // 过去12个月数据
            for month in 0..<12 {
                if let date = calendar.date(byAdding: .month, value: -month, to: now) {
                    let monthSteps = stepEntries.filter {
                        let components1 = calendar.dateComponents([.year, .month], from: $0.date)
                        let components2 = calendar.dateComponents([.year, .month], from: date)
                        return components1.year == components2.year && components1.month == components2.month
                    }
                    let value = monthSteps.reduce(0.0) { $0 + Double($1.count) }
                    newData.append(ChartBar(value: value, hour: month))
                }
            }
        }
        
        chartData = newData
    }
    
    private func generateHourlyValue(for hour: Int) -> Double {
        switch hour {
        case 0..<6: return Double.random(in: 0...50)
        case 6..<9: return Double.random(in: 300...600)
        case 9..<12: return Double.random(in: 300...450)
        case 12..<14: return Double.random(in: 800...1100)
        case 14..<18: return Double.random(in: 400...600)
        case 18..<20: return Double.random(in: 600...800)
        default: return Double.random(in: 0...200)
        }
    }
    
    // MARK: - Subviews
    
    private var timeRangePicker: some View {
        HStack(spacing: 0) {
            ForEach(TimeRange.allCases, id: \.self) { range in
                Button {
                    selectedTimeRange = range
                    generateChartData(for: range)
                } label: {
                    Text(range.rawValue)
                        .font(.system(size: 17))
                        .foregroundColor(selectedTimeRange == range ? 
                                         (colorScheme == .dark ? .white : .black) : 
                                         .gray)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                        .background(selectedTimeRange == range ? 
                                    cardBackground : Color.clear)
                }
               .background(colorScheme == .dark ? Color(UIColor.systemGray6).opacity(0.5) : Color(UIColor.systemGray6))
               .cornerRadius(8)
                
                // if range != .year {
                //     Divider()
                //         .background(Color.gray.opacity(0.5))
                //         .frame(height: 20)
                // }
            }
        }
        .background(cardBackground)
        .cornerRadius(8)
        .padding(.horizontal)
        .padding(.top, 5)
    }
    
    private var stepsStatistics: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text("Total")
                .foregroundColor(.secondary)
                .font(.system(size: 17))
            
            HStack(alignment: .firstTextBaseline) {
                Text("\(totalStepsCount)")
                    .foregroundColor(textColor)
                    .font(.system(size: 70, weight: .semibold))
                
                Text("steps")
                    .foregroundColor(.secondary)
                    .font(.system(size: 20))
                    .padding(.leading, 5)
            }
            
            Text("Yesterday")
                .foregroundColor(.secondary)
                .font(.system(size: 17))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal)
        .padding(.top, 10)
    }
    
    private var chartSection: some View {
        ZStack(alignment: .topLeading) {
            // Grid lines
            VStack(spacing: 0) {
                ForEach(0..<4) { i in
                    Divider()
                        .background(Color.gray.opacity(0.3))
                        .padding(.top, i == 0 ? 0 : 83)
                }
            }
            .frame(maxWidth: .infinity)
            
            // Y-axis labels
            VStack(alignment: .trailing, spacing: 0) {
                Text("1,500")
                    .foregroundColor(.secondary)
                    .font(.system(size: 12))
                Spacer()
                Text("1,000")
                    .foregroundColor(.secondary)
                    .font(.system(size: 12))
                Spacer()
                Text("500")
                    .foregroundColor(.secondary)
                    .font(.system(size: 12))
                Spacer()
                Text("0")
                    .foregroundColor(.secondary)
                    .font(.system(size: 12))
            }
            .frame(height: 250)
            .padding(.top, 10)
            .padding(.leading, 5)
            
            // Chart bars
            HStack(alignment: .bottom, spacing: 2) {
                ForEach(chartData) { bar in
                    Rectangle()
                        .fill(Color.orange)
                        .frame(width: 8, height: CGFloat(min(bar.value, 1500) / 6))
                }
            }
            .frame(maxWidth: .infinity)
            .frame(height: 250)
            .padding(.leading, 40)
            .padding(.trailing, 20)
            
            // X-axis labels
            HStack(spacing: 0) {
                Text("0h")
                    .foregroundColor(.secondary)
                    .font(.system(size: 12))
                Spacer()
                Text("6h")
                    .foregroundColor(.secondary)
                    .font(.system(size: 12))
                Spacer()
                Text("12h")
                    .foregroundColor(.secondary)
                    .font(.system(size: 12))
                Spacer()
                Text("18h")
                    .foregroundColor(.secondary)
                    .font(.system(size: 12))
                Spacer()
                Text("24h")
                    .foregroundColor(.secondary)
                    .font(.system(size: 12))
            }
            .padding(.horizontal, 30)
            .padding(.top, 260)
        }
        .frame(height: 280)
        .padding(.top, 20)
    }
    
    private var trendButton: some View {
        Button {
            // Handle trend button action
        } label: {
            HStack {
                Text("Trends")
                    .foregroundColor(textColor)
                Spacer()
                Text("Unavailable")
                    .foregroundColor(.secondary)
            }
            .padding()
            .background(cardBackground)
            .cornerRadius(10)
            .padding(.horizontal)
            .padding(.top, 20)
        }
        .buttonStyle(PlainButtonStyle())
    }
    
    private var feedSection: some View {
        HStack {
            Text("Feed")
                .foregroundColor(textColor)
                .font(.system(size: 20, weight: .bold))
            Spacer()
            Button("Show All") {
                // Handle show all action
            }
            .foregroundColor(.accentColor)
        }
        .padding(.horizontal)
        .padding(.top, 20)
    }
    
    private var stepsFeedCard: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Image(systemName: "flame.fill")
                    .foregroundColor(.orange)
                Text("Steps")
                    .foregroundColor(.orange)
                    .font(.system(size: 17, weight: .semibold))
            }
            .padding(.vertical, 10)
            
            Text("Your 7-day average is \(averageSteps) steps per day.")
                .foregroundColor(textColor)
                .font(.system(size: 17))
                .padding(.bottom, 15)
        }
        .padding(.horizontal)
        .background(cardBackground)
        .cornerRadius(12)
        .padding(.horizontal)
        .padding(.top, 10)
        .padding(.bottom, 20)
    }
    
    private var backButton: some View {
        Button {
            presentationMode.wrappedValue.dismiss()
        } label: {
            HStack(spacing: 5) {
                // Image(systemName: "chevron.left")
                //     .foregroundColor(.accentColor)
//                Text("Summary")
//                    .foregroundColor(.accentColor)
            }
        }
    }
    
    private var addDataButton: some View {
        Button("Add Data") {
            showAddDataSheet = true
        }
        .foregroundColor(.accentColor)
    }
}

struct AddStepsDataView: View {
    @Binding var isPresented: Bool
    @Binding var date: Date
    @Binding var time: Date
    @Binding var stepsCount: String
    @Environment(\.colorScheme) var colorScheme
    var onSave: () -> Void
    
    var body: some View {
        NavigationView {
            ZStack {
                Color(.systemBackground).edgesIgnoringSafeArea(.all)
                
                VStack(spacing: 0) {
                    FormView()
                    Spacer()
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarItems(
                leading: Button("Cancel") {
                    isPresented = false
                }.foregroundColor(.accentColor),
                trailing: Button("Add") {
                    onSave()
                    isPresented = false
                }.foregroundColor(.accentColor)
                .disabled(stepsCount.isEmpty || Int(stepsCount) == nil)
            )
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("Steps")
                        .foregroundColor(colorScheme == .dark ? .white : .primary)
                        .font(.system(size: 17, weight: .semibold))
                }
            }
        }
    }
    
    @ViewBuilder
    private func FormView() -> some View {
        VStack(spacing: 0) {
            DatePickerRow(title: "Date", selection: $date, components: .date)
            DividerRow()
            DatePickerRow(title: "Time", selection: $time, components: .hourAndMinute)
            DividerRow()
            InputRow(title: "Steps", text: $stepsCount)
        }
        .padding(.horizontal)
        .padding(.top, 20)
    }
    
    private func DatePickerRow(title: String, selection: Binding<Date>, components: DatePickerComponents) -> some View {
        HStack {
            Text(title)
                .foregroundColor(.secondary)
                .font(.system(size: 17))
            Spacer()
            DatePicker("", selection: selection, displayedComponents: components)
                .labelsHidden()
                .datePickerStyle(.compact)
        }
        .padding(.vertical, 12)
    }
    
    private func DividerRow() -> some View {
        Divider()
            .background(Color.gray.opacity(0.5))
    }
    
    private func InputRow(title: String, text: Binding<String>) -> some View {
        HStack {
            Text(title)
                .foregroundColor(.secondary)
                .font(.system(size: 17))
            Spacer()
            TextField("", text: text)
                .keyboardType(.numberPad)
                .multilineTextAlignment(.trailing)
                .foregroundColor(.primary)
        }
        .padding(.vertical, 12)
    }
}

struct StepsDetailView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            StepsDetailView()
                .preferredColorScheme(.dark)
            
            StepsDetailView()
                .preferredColorScheme(.light)
        }
    }
}
