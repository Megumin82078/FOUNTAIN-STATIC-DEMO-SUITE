import SwiftUI

struct SharingView: View {
    @Environment(\.colorScheme) var colorScheme
    @State private var showSharingIntro = true  // 默认显示Health Sharing介绍弹窗

    var body: some View {
        ZStack {
            // 主内容
            VStack(alignment: .leading, spacing: 0) {
                // 标题
                Text("Sharing")
                    .font(.system(size: 34, weight: .bold))
                    .foregroundColor(.primary)
                    .padding(.top, 16)
                    .padding(.horizontal, 16)
                    .padding(.bottom, 16)
                
                // 直接嵌入HealthSharingSheet组件
                HealthSharingSheet()
                    .padding(.horizontal, 16)
                    .padding(.bottom, 24)
            }
            .blur(radius: showSharingIntro ? 5 : 0)
            .disabled(showSharingIntro)
            
            // Health Sharing介绍弹窗
            if showSharingIntro {
                Color.black.opacity(0.4)
                    .edgesIgnoringSafeArea(.all)
                
                VStack(alignment: .center, spacing: 24) {
                    // 关闭按钮
                    HStack {
                        Spacer()
                        Button(action: {
                            withAnimation {
                                showSharingIntro = false
                            }
                        }) {
                            Image(systemName: "xmark.circle.fill")
                                .font(.system(size: 24))
                                .foregroundColor(.secondary)
                        }
                        .padding(.trailing, 16)
                        .padding(.top, 16)
                    }
                    
                    VStack(spacing: 16) {
                        ZStack {
                            Circle()
                                .fill(
                                    LinearGradient(
                                        gradient: Gradient(colors: [
                                            Color.purple, 
                                            Color.blue
                                        ]),
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .frame(width: 80, height: 80)
                            
                            Image(systemName: "person.2.fill")
                                .font(.system(size: 36))
                                .foregroundColor(.white)
                        }
                        
                        Text("Health Sharing")
                            .font(.system(size: 28, weight: .bold))
                            .foregroundColor(.primary)
                    }
                    .padding(.top, 24)
                    
                    FeatureItem(icon: "checkmark.circle.fill", title: "You're in Control", description: "Share your health data and records securely and in real time to keep healthcare professionals informed of your health status.", iconColor: .blue)
                    
                    FeatureItem(icon: "bell.fill", title: "Trends & Notifications", description: "Your shared data and access history will be displayed in the Fountain App. Any changes will be notified in real time - to keep you informed.", iconColor: .blue)
                    
                    FeatureItem(icon: "lock.fill", title: "Private & Secure", description: "Your data will be encrypted, accessible only to authorized medical personnel, and all access will be recorded; You can terminate sharing at any time.", iconColor: .blue)
                    
                    VStack(spacing: 16) {
                        Button(action: {
                            withAnimation {
                                showSharingIntro = false
                            }
                        }) {
                            Text("Start to sharing")
                                .font(.system(size: 17, weight: .semibold))
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 16)
                                .background(Color.blue)
                                .cornerRadius(12)
                        }
                    }
                    .padding(.top, 8)
                    .padding(.bottom, 24)
                    
                    Spacer()
                }
                .padding(.horizontal, 24)
                .background(Color(.systemBackground))
                .cornerRadius(20)
                .shadow(radius: 10)
                .padding(.horizontal, 16)
                .padding(.vertical, 40)
                .transition(.move(edge: .bottom))
            }
        }
        .navigationTitle("")
        .navigationBarHidden(true)
    }
}

struct FeatureItem: View {
    let icon: String
    let title: String
    let description: String
    let iconColor: Color
    
    var body: some View {
        HStack(alignment: .top, spacing: 16) {
            Image(systemName: icon)
                .font(.system(size: 22))
                .foregroundColor(iconColor)
                .frame(width: 24)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundColor(.primary)
                
                Text(description)
                    .font(.system(size: 15))
                    .foregroundColor(.secondary)
                    .lineSpacing(2)
            }
        }
        .padding(.horizontal, 16)
    }
}
