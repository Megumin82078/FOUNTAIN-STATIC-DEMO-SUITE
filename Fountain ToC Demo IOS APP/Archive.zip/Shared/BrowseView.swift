import SwiftUI

// MARK: - Main Tab View
struct MainTabView: View {
    @State private var selectedTab = 2
    
    var body: some View {
        TabView(selection: $selectedTab) {
            NavigationView {
                Text("Summary View")
                    .navigationTitle("Summary")
            }
            .tabItem {
                Label("Summary", systemImage: "heart.fill")
            }
            .tag(0)
            
            NavigationView {
                Text("Sharing View")
                    .navigationTitle("Sharing")
            }
            .tabItem {
                Label("Sharing", systemImage: "person.2.fill")
            }
            .tag(1)
            
            NavigationView {
                BrowseView()
            }
            .tabItem {
                Label("Browse", systemImage: "square.grid.2x2.fill")
            }
            .tag(2)
            .edgesIgnoringSafeArea(.all)
            
            NavigationView {
                Text("Documents View")
                    .navigationTitle("Documents")
            }
            .tabItem {
                Label("Documents", systemImage: "doc.text")
            }
            .tag(3)
        }
        .accentColor(.blue)
        .onAppear {
            configureTabBarAppearance()
        }
    }
    
    private func configureTabBarAppearance() {
        if #available(iOS 15.0, *) {
            let appearance = UITabBarAppearance()
            appearance.configureWithOpaqueBackground()
            appearance.backgroundColor = UIColor.systemBackground
            UITabBar.appearance().scrollEdgeAppearance = appearance
            UITabBar.appearance().standardAppearance = appearance
        }
    }
}

// MARK: - Browse View
    struct BrowseView: View {
        @State private var searchText = ""
        @Environment(\.colorScheme) private var colorScheme
        
        struct HealthCategory: Identifiable {
            let id = UUID()
            let icon: String
            let name: String
            let color: Color
            let isSystemIcon: Bool
        }
        
        private let categories: [HealthCategory] = [
            HealthCategory(icon: "figure.walk", name: "Steps", color: .orange, isSystemIcon: true),
            HealthCategory(icon: "figure.stand", name: "Body Measurement", color: .purple, isSystemIcon: true),
            HealthCategory(icon: "bed.double.fill", name: "Sleep", color: .blue, isSystemIcon: true),
            HealthCategory(icon: "waveform.path.ecg", name: "Symptoms", color: .red, isSystemIcon: true),
            HealthCategory(icon: "heart.fill", name: "Vitals", color: .pink, isSystemIcon: true),
            HealthCategory(icon: "brain.head.profile", name: "Mental Wellbeing", color: .green, isSystemIcon: true),
            HealthCategory(icon: "figure.walk", name: "Mobility", color: .orange, isSystemIcon: true),
            HealthCategory(icon: "heart.text.square", name: "Medical Record", color: .red, isSystemIcon: true),
            HealthCategory(icon: "cross.case.fill", name: "Lab Results", color: .blue, isSystemIcon: true),
            HealthCategory(icon: "doc.text.fill", name: "Doctor's Note", color: .orange, isSystemIcon: true),
            HealthCategory(icon: "pills.fill", name: "Medication", color: .green, isSystemIcon: true),
            HealthCategory(icon: "exclamationmark.shield.fill", name: "Allergy Information", color: .purple, isSystemIcon: true),
            HealthCategory(icon: "brain", name: "AI Recommendation", color: .indigo, isSystemIcon: true)
        ]
        
        var body: some View {
            VStack(spacing: 0) {
                customNavigationBar
                searchBar
                contentView
            }
            .background(Color(.systemBackground))
            .navigationBarHidden(true)
        }
        
        // 自定义导航栏
        private var customNavigationBar: some View {
            HStack {
                Text("Browse")
                    .font(.system(size: 34, weight: .bold))
                    .foregroundColor(.primary)
                
                Spacer()
                
                // ZStack {
                //     Circle()
                //         .fill(Color(.secondarySystemBackground))
                //         .frame(width: 36, height: 36)
                
                //     Text("LJ")
                //         .font(.system(size: 16, weight: .medium))
                //         .foregroundColor(.secondary)
                // }
            }
            .padding(.horizontal)
            .padding(.top, 4)
            .padding(.bottom, 12)
            .background(Color(.systemBackground))
        }
        
        // 搜索栏
        private var searchBar: some View {
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.secondary)
                TextField("Search", text: $searchText)
                    .foregroundColor(.primary)
            }
            .padding(10)
            .background(Color(.secondarySystemBackground))
            .cornerRadius(10)
            .padding(.horizontal)
            .padding(.bottom, 12)
        }
        
        // 内容视图
        private var contentView: some View {
            ScrollView {
                VStack(alignment: .leading) {
                    sectionHeader
                    categoryList
                }
            }
            .background(Color(.systemBackground))
        }
        
        // 分类标题
        private var sectionHeader: some View {
            Text("Health Categories")
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(.primary)
                .padding(.horizontal)
                .padding(.bottom, 12)
        }
        
        // 分类列表
        private var categoryList: some View {
            LazyVStack(spacing: 0) {
                ForEach(categories) { category in
                    NavigationLink(destination: destinationView(for: category)) {
                        categoryRow(category)
                    }
                    .buttonStyle(PlainButtonStyle())
                    
                    if category.id != categories.last?.id {
                        Divider()
                            .background(Color(.separator))
                            .padding(.leading, 60)
                    }
                }
            }
            .background(Color(.tertiarySystemBackground))
            .cornerRadius(12)
            .padding(.horizontal)
        }
        
        // 分类行视图
        private func categoryRow(_ category: HealthCategory) -> some View {
            HStack {
                categoryIconView(category)
                Text(category.name)
                    .foregroundColor(.primary)
                    .font(.system(size: 17))
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundColor(.secondary)
                    .font(.system(size: 14))
            }
            .padding(.vertical, 14)
            .padding(.horizontal)
        }
        
        // 分类图标
        @ViewBuilder
        private func categoryIconView(_ category: HealthCategory) -> some View {
            if category.isSystemIcon {
                Image(systemName: category.icon)
                    .foregroundColor(category.color)
                    .font(.system(size: 24))
                    .frame(width: 36, height: 36)
            } else if category.name == "Cycle Tracking" {
                ZStack {
                    Circle()
                        .stroke(Color(red: 0.9, green: 0.4, blue: 0.7), lineWidth: 2)
                        .frame(width: 30, height: 30)
                    
                    ForEach(0..<8) { i in
                        Rectangle()
                            .fill(Color(red: 0.9, green: 0.4, blue: 0.7))
                            .frame(width: 2, height: 8)
                            .offset(x: 0, y: -19)
                            .rotationEffect(.degrees(Double(i) * 45))
                    }
                }
                .frame(width: 36, height: 36)
            }
        }
        
        // 目标视图
        @ViewBuilder
        private func destinationView(for category: HealthCategory) -> some View {
            switch category.name {
            case "Steps": StepsDetailView()
            case "Body Measurement": BodyMeasurementsView()
            // case "Mobility": ActivityCapabilityView()
            // case "Heart": HeartDetailView(category: category)
            // case "Mindfulness": MindfulnessDetailView()
            // case "Sleep": SleepDetailView()
            // case "Medications": MedicationView()
            // case "Symptoms": SymptomsView()
            // case "Respiratory": RespiratoryView()
            default: NoDataView(
                title: "No Data", 
                message: "No such data is available", 
                iconName: "scalemass"
            )
            }
        }
    }

// MARK: - Preview
struct BrowseView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            MainTabView()
                .preferredColorScheme(.dark)
                .previewDisplayName("Dark Mode")
            
            MainTabView()
                .preferredColorScheme(.light)
                .previewDisplayName("Light Mode")
        }
    }
}

// MARK: - Subviews
struct ComingSoonView: View {
    var body: some View {
        Text("Coming Soon")
            .foregroundColor(.secondary)
            .navigationTitle("")
    }
}

// MARK: - Body Measurement View
struct BodyMeasurementView: View {
    struct MeasurementItem: Identifiable {
        let id = UUID()
        let icon: String
        let name: String
        let color: Color
        let destination: AnyView
    }
    
    private let measurements: [MeasurementItem] = [
        MeasurementItem(icon: "scalemass", name: "Weight", color: .purple, destination: AnyView(WeightDetailView())),
        MeasurementItem(icon: "percent", name: "Body Fat Percentage", color: .orange, destination: AnyView(ComingSoonView())),
        MeasurementItem(icon: "figure.stand", name: "BMI", color: .blue, destination: AnyView(ComingSoonView())),
        MeasurementItem(icon: "figure.arms.open", name: "Lean Body Mass", color: .green, destination: AnyView(ComingSoonView()))
    ]
    
    var body: some View {
        List {
            ForEach(measurements) { item in
                NavigationLink(destination: item.destination) {
                    HStack {
                        Image(systemName: item.icon)
                            .foregroundColor(item.color)
                            .font(.system(size: 24))
                            .frame(width: 36, height: 36)
                        
                        Text(item.name)
                            .font(.system(size: 17))
                    }
                    .padding(.vertical, 8)
                }
            }
        }
        .listStyle(InsetGroupedListStyle())
        .navigationTitle("Body Measurement")
    }
}

// 为其他新增类别添加视图结构体
struct VitalsDetailView: View {
    var body: some View {
        Text("Vitals Detail View")
            .navigationTitle("Vitals")
    }
}

struct MentalWellbeingView: View {
    var body: some View {
        Text("Mental Wellbeing View")
            .navigationTitle("Mental Wellbeing")
    }
}

struct MedicalRecordView: View {
    var body: some View {
        Text("Medical Record View")
            .navigationTitle("Medical Record")
    }
}

struct LabResultsView: View {
    var body: some View {
        Text("Lab Results View")
            .navigationTitle("Lab Results")
    }
}

struct DoctorsNoteView: View {
    var body: some View {
        Text("Doctor's Note View")
            .navigationTitle("Doctor's Note")
    }
}

struct AllergyInformationView: View {
    var body: some View {
        Text("Allergy Information View")
            .navigationTitle("Allergy Information")
    }
}

struct AIRecommendationView: View {
    var body: some View {
        Text("AI Recommendation View")
            .navigationTitle("AI Recommendation")
    }
}
