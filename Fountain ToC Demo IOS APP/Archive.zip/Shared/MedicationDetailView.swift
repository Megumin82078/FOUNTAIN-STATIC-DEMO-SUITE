import SwiftUI

struct MedicationDetailView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) private var colorScheme
    
    let medicationName: String
    let specification: String
    let medicationType: String
    
    @State private var displayName: String = ""
    @State private var notes: String = ""
    @State private var frequency: String = "every day"
    @State private var scheduledTime: String = "16:40"
    @State private var dosage: Int = 1

    // 根据当前主题获取背景色
    var backgroundColor: Color {
        colorScheme == .dark ? Color.black : Color.white
    }
    
    // 根据当前主题获取文本颜色
    var textColor: Color {
        colorScheme == .dark ? Color.white : Color.black
    }
    
    // 根据当前主题获取卡片背景色
    var cardBackgroundColor: Color {
        colorScheme == .dark ? Color(UIColor.systemGray6).opacity(0.3) : Color(UIColor.systemGray6)
    }
    
    // 根据当前主题获取输入框背景色
    var textFieldBackgroundColor: Color {
        colorScheme == .dark ? Color(UIColor.systemGray5).opacity(0.5) : Color(UIColor.systemGray6)
    }
    
    var body: some View {
        ZStack {
            // 背景色
            backgroundColor.edgesIgnoringSafeArea(.all)
            
            ScrollView {
                VStack(spacing: 0) {
                    // 导航栏
                    HStack {
                        Button(action: {
                            presentationMode.wrappedValue.dismiss()
                        }) {
                            HStack(spacing: 2) {
                                Image(systemName: "chevron.left")
                                Text("back")
                            }
                            .foregroundColor(.blue)
                            .font(.system(size: 17))
                        }
                        
                        Spacer()
                        
                        Text("Check Details")
                            .font(.system(size: 17, weight: .semibold))
                            .foregroundColor(textColor)
                        
                        Spacer()
                        
                        Button("cancel") {
                            presentationMode.wrappedValue.dismiss()
                        }
                        .foregroundColor(.blue)
                        .font(.system(size: 17))
                    }
                    .padding(.horizontal)
                    .padding(.top, 16)
                    .padding(.bottom, 20)
                    
                    // 药品图标
                    ZStack {
                        Circle()
                            .fill(Color.blue)
                            .frame(width: 120, height: 120)
                        
                        if medicationType == "capsule" {
                            Capsule()
                                .fill(Color.white)
                                .frame(width: 60, height: 30)
                        } else {
                            RoundedRectangle(cornerRadius: 5)
                                .fill(Color.white)
                                .frame(width: 50, height: 30)
                        }
                    }
                    .padding(.bottom, 20)
                    
                    // 药品名称
                    Text(medicationName)
                        .font(.system(size: 32, weight: .bold))
                        .foregroundColor(textColor)
                    
                    // 药品规格
                    Text("\(medicationType), \(specification)")
                        .font(.system(size: 17))
                        .foregroundColor(.gray)
                        .padding(.bottom, 30)
                    
                    // 定时部分
                    VStack(alignment: .leading, spacing: 15) {
                        Text("timing")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(textColor)
                            .padding(.leading, 5)
                            .padding(.bottom, 5)
                        
                        // 频率卡片
                        HStack {
                            Text(frequency)
                                .font(.system(size: 17))
                                .foregroundColor(textColor)
                            
                            Spacer()
                        }
                        .padding()
                        .background(cardBackgroundColor)
                        .cornerRadius(10)
                        
                        // 时间卡片
                        HStack {
                            Text(scheduledTime)
                                .font(.system(size: 17))
                                .foregroundColor(textColor)
                            
                            Spacer()
                            
                            Text("\(dosage)grain\(medicationType)")
                                .font(.system(size: 17))
                                .foregroundColor(.blue)
                        }
                        .padding()
                        .background(cardBackgroundColor)
                        .cornerRadius(10)
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 30)
                    
                    // 详细信息部分
                    VStack(alignment: .leading, spacing: 15) {
                        Text("Details (optional)")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(textColor)
                            .padding(.leading, 5)
                            .padding(.bottom, 5)
                        
                        // 显示名称输入框
                        TextField("Display name", text: $displayName)
                            .font(.system(size: 17))
                            .foregroundColor(textColor)
                            .padding()
                            .background(textFieldBackgroundColor)
                            .cornerRadius(10)
                        
                        // 备注输入框
                        ZStack(alignment: .topLeading) {
                            if notes.isEmpty {
                                Text("remark")
                                    .font(.system(size: 17))
                                    .foregroundColor(.gray)
                                    .padding(.horizontal, 5)
                                    .padding(.top, 8)
                            }
                            
                            TextEditor(text: $notes)
                                .font(.system(size: 17))
                                .foregroundColor(textColor)
                                .frame(minHeight: 150)
                                .padding(5)
                                .background(textFieldBackgroundColor)
                        }
                        .background(textFieldBackgroundColor)
                        .cornerRadius(10)
                    }
                    .padding(.horizontal)
                    
                    // 添加额外的空间，确保内容可以滚动到底部按钮上方
                    Spacer(minLength: 100)
                }
            }
            
            // 完成按钮 - 固定在底部
            VStack {
                Spacer()
                
                Button(action: {
                    // 保存操作
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Text("done")
                        .font(.system(size: 17, weight: .medium))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                .padding(.horizontal)
                .padding(.bottom, 30)
            }
        }
        .navigationBarHidden(true)
    }
}

struct MedicationDetailView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            MedicationDetailView(
                medicationName: "Ggg",
                specification: "5 milligram",
                medicationType: "capsule"
            )
            .preferredColorScheme(.dark)
            .previewDisplayName("Dark Mode")
            
            MedicationDetailView(
                medicationName: "Ggg",
                specification: "5 milligram",
                medicationType: "capsule"
            )
            .preferredColorScheme(.light)
            .previewDisplayName("Light Mode")
        }
    }
}
