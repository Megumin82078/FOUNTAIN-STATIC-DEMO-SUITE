import SwiftUI

struct AccessRecordView: View {
    @State private var selectedRecord: AccessRecord?

    let accessRecords: [AccessRecord] = [
        AccessRecord(name: "Maple Clinic",
                    authDate: "2025/03/01",
                    expiryDate: "2025/05/01",
                    status: .valid(daysRemaining: 60),
                    lastAccess: "2025/03/08 14:20",
                    accessBlocked: false,
                    accessDetails: [
                        AccessDetail(timestamp: "2025/03/08 14:20",
                                     accessedBy: "Dr. Li",
                                     accessedContent: "Viewed Laboratory Report")
                    ]),
        
        AccessRecord(name: "City Hospital",
                    authDate: "2025/02/10",
                    expiryDate: "2025/03/10",
                    status: .expired,
                    lastAccess: "2025/03/08 09:30",
                    accessBlocked: true,
                    accessDetails: [
                        AccessDetail(timestamp: "2025/03/08 09:30",
                                     accessedBy: "Dr. Wang",
                                     accessedContent: "Access denied")
                    ])
    ]
    
    var body: some View {
        NavigationView {
            List {
                ForEach(accessRecords) { record in
                    Button(action: {
                        selectedRecord = record
                    }) {
                        AccessRecordCard(record: record)
                    }
                }
            }
            .listStyle(PlainListStyle())
            .navigationTitle("Access Records")
            .sheet(item: $selectedRecord) { record in
                AccessDetailView(record: record)
            }
        }
    }
}

struct AccessRecordCard: View {
    let record: AccessRecord
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(record.name)
                .font(.headline)
                .foregroundColor(.primary)
            
            AccessInfoRow(title: "Authorization Date:", value: record.authDate)
            StatusRow(status: record.status)
            
            if record.accessBlocked {
                AccessInfoRow(title: "Last Access:", value: "\(record.lastAccess) (Access Denied)", color: .red)
            } else {
                AccessInfoRow(title: "Last Access:", value: record.lastAccess)
            }
        }
        .padding()
        .background(RoundedRectangle(cornerRadius: 12)
            .fill(Color(UIColor.secondarySystemBackground))
            .shadow(radius: 3))
        .padding(.horizontal)
    }
}

struct AccessDetailView: View {
    @Environment(\.dismiss) private var dismiss
    let record: AccessRecord
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    AccessSectionHeader(title: "Authorization Details")
                    
                    AccessDetailRow(title: "Authorized Institution:", value: record.name)
                    AccessDetailRow(title: "Authorization Date & Validity:", value: "\(record.authDate) → \(record.expiryDate)")
                    AccessDetailRow(title: "Authorization Scope:", value: "Medical Records, Laboratory Reports")
                    
                    AccessSectionHeader(title: "Recent Access Logs")
                    
                    ForEach(record.accessDetails) { detail in
                        VStack(alignment: .leading, spacing: 4) {
                            AccessDetailRow(title: "Time:", value: detail.timestamp)
                            AccessDetailRow(title: "Accessed By:", value: detail.accessedBy)
                            AccessDetailRow(title: "Content Accessed:", value: detail.accessedContent)
                        }
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 10).fill(Color(UIColor.tertiarySystemBackground)))
                    }
                    
                    AccessSectionHeader(title: "Status Information")
                    Text(record.statusMessage)
                        .font(.subheadline)
                        .foregroundColor(record.statusColor)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(RoundedRectangle(cornerRadius: 10).fill(record.statusColor.opacity(0.2)))
                }
                .padding()
            }
            .navigationTitle("Access Details")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Close") {
                        dismiss()
                    }
                }
            }
        }
    }
}

struct AccessInfoRow: View {
    let title: String
    let value: String
    var color: Color = .primary

    var body: some View {
        HStack {
            Text(title)
                .font(.subheadline)
                .foregroundColor(.secondary)
            Spacer()
            Text(value)
                .font(.subheadline)
                .foregroundColor(color)
        }
    }
}

struct StatusRow: View {
    let status: AuthorizationStatus
    
    var body: some View {
        HStack {
            Text("Status:")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            Spacer()
            
            switch status {
            case .valid(let daysRemaining):
                Text("Active (\(daysRemaining) days left)")
                    .font(.subheadline)
                    .foregroundColor(.green)
            case .expired:
                Text("Expired")
                    .font(.subheadline)
                    .foregroundColor(.red)
            }
        }
    }
}

struct AccessSectionHeader: View {
    let title: String
    
    var body: some View {
        Text(title)
            .font(.headline)
            .foregroundColor(.primary)
            .padding(.top)
    }
}

struct AccessDetailRow: View {
    let title: String
    let value: String
    
    var body: some View {
        HStack {
            Text(title)
                .font(.subheadline)
                .foregroundColor(.secondary)
            Spacer()
            Text(value)
                .font(.subheadline)
                .foregroundColor(.primary)
        }
    }
}

// 数据模型
struct AccessRecord: Identifiable {
    let id = UUID()
    let name: String
    let authDate: String
    let expiryDate: String
    let status: AuthorizationStatus
    let lastAccess: String
    let accessBlocked: Bool
    let accessDetails: [AccessDetail]
    
    var statusMessage: String {
        switch status {
        case .valid:
            return "Current authorization is active."
        case .expired:
            return "Authorization has expired."
        }
    }
    
    var statusColor: Color {
        switch status {
        case .valid:
            return .green
        case .expired:
            return .red
        }
    }
}

struct AccessDetail: Identifiable {
    let id = UUID()
    let timestamp: String
    let accessedBy: String
    let accessedContent: String
}

enum AuthorizationStatus {
    case valid(daysRemaining: Int)
    case expired
}

// 预览
struct AccessRecordView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            AccessRecordView()
                .preferredColorScheme(.light)
            
            AccessRecordView()
                .preferredColorScheme(.dark)
        }
    }
}
