import SwiftUI

struct SleepDetailView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) private var colorScheme
    
    // Time Range Selection
    enum TimeRange: String, CaseIterable, Identifiable {
        case day = "Day"
        case week = "Week"
        case month = "Month"
        case sixMonths = "6 Months"
        
        var id: String { self.rawValue }
    }
    
    @State private var selectedTimeRange: TimeRange = .day
    @State private var currentDate = Date()
    @State private var formattedDate = ""
    
    // Sleep Duration
    let sleepHours = 3
    let sleepMinutes = 33
    
    // Theme-adaptive Colors
    var backgroundColor: Color { Color(.systemBackground) }
    var textColor: Color { Color.primary }
    var segmentedControlBackgroundColor: Color { Color(.secondarySystemBackground) }
    var segmentedControlSelectedBackgroundColor: Color { Color(.tertiarySystemBackground) }
    var cardBackgroundColor: Color { Color(.quaternarySystemFill) }
    var gridLineColor: Color { Color(.separator) }
    
    var body: some View {
        ZStack(alignment: .top) {
            backgroundColor.edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 0) {
                // Custom Navigation
                HStack {
                    Button(action: { presentationMode.wrappedValue.dismiss() }) {
                        HStack(spacing: 5) {
                            Image(systemName: "chevron.left")
                                .foregroundColor(.accentColor)
                                .font(.system(size: 16, weight: .semibold))
                            Text("Browse")
                                .foregroundColor(.accentColor)
                                .font(.system(size: 17))
                        }
                    }
                    
                    Spacer()
                    
                    Text("Sleep Analysis")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundColor(textColor)
                    
                    Spacer()
                    
                    Button("Add Data") {
                        // Add data action
                    }
                    .foregroundColor(.accentColor)
                }
                .padding(.horizontal)
                .padding(.vertical, 10)
                
                // Time Picker
                HStack(spacing: 0) {
                    ForEach(TimeRange.allCases) { range in
                        Button(action: { selectedTimeRange = range }) {
                            Text(range.rawValue)
                                .font(.subheadline)
                                .foregroundColor(selectedTimeRange == range ? textColor : .secondary)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 8)
                                .background(
                                    selectedTimeRange == range ?
                                    segmentedControlSelectedBackgroundColor :
                                    Color.clear
                                )
                        }
                    }
                }
                .background(segmentedControlBackgroundColor)
                .cornerRadius(8)
                .padding(.horizontal)
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        // Sleep Duration Section
                        VStack(alignment: .leading) {
                            HStack {
                                Circle()
                                    .fill(Color.teal)
                                    .frame(width: 8)
                                Text("Time in Bed")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                Spacer()
                            }
                            
                            HStack(alignment: .firstTextBaseline) {
                                Text("\(sleepHours)")
                                    .font(.system(size: 48, weight: .regular)) + 
                                Text("h")
                                    .font(.title2) +
                                Text("\(sleepMinutes)")
                                    .font(.system(size: 48, weight: .regular)) +
                                Text("min")
                                    .font(.title2)
                                
                                Spacer()
                                
                                Button { /* Info action */ } label: {
                                    Image(systemName: "info.circle")
                                        .font(.title2)
                                }
                            }
                            
                            Text(formattedDate)
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }
                        .padding()
                        
                        // Sleep Chart
                        SleepChartView(gridLineColor: gridLineColor)
                        
                        // Sleep Schedule
                        SleepScheduleView(cardBackgroundColor: cardBackgroundColor)
                        
                        // About Sleep Section
                        VStack(alignment: .leading) {
                            Text("About Sleep")
                                .font(.title2.bold())
                            
                            Text("""
                            Sleep helps you gain insights into your sleep patterns. Track both time in bed and actual sleep time. Our devices estimate these using movement analysis during the night. You can also manually log your sleep data.
                            
                            "Time in Bed" reflects when you're preparing to sleep, while "Sleep Time" shows actual sleep duration.
                            """)
                            .font(.body)
                            .lineSpacing(4)
                        }
                        .padding()
                        .background(cardBackgroundColor)
                        .cornerRadius(12)
                    }
                }
            }
        }
        .navigationBarHidden(true)
        .onAppear {
            let formatter = DateFormatter()
            formatter.dateFormat = "MMM d, yyyy"
            formattedDate = formatter.string(from: currentDate)
        }
    }
}

// MARK: - Subviews
struct SleepChartView: View {
    let gridLineColor: Color
    
    var body: some View {
        ZStack {
            // Grid System
            VStack(spacing: 0) {
                Divider().background(gridLineColor)
                Spacer()
                Divider().background(gridLineColor)
            }
            
            HStack(spacing: 0) {
                ForEach(0..<4, id: \.self) { _ in
                    Divider().background(gridLineColor)
                    Spacer()
                }
            }
            
            // Visual Sleep Bars
            HStack {
                SleepBar(height: 60)
                SleepBar(height: 60)
                Spacer()
                SleepBar(height: 60, width: 200)
            }
            .padding(.horizontal, 30)
            
            // Timeline Labels
            VStack {
                Spacer()
                HStack {
                    Text("12 AM")
                    Spacer()
                    Text("6 AM")
                    Spacer()
                    Text("12 PM")
                }
                .font(.caption)
                .foregroundColor(.secondary)
            }
            .padding(.horizontal)
        }
        .frame(height: 200)
    }
}

struct SleepBar: View {
    var height: CGFloat = 80
    var width: CGFloat = 8
    
    var body: some View {
        RoundedRectangle(cornerRadius: width/2)
            .fill(Color.teal)
            .frame(width: width, height: height)
    }
}

struct SleepScheduleView: View {
    let cardBackgroundColor: Color
    
    var body: some View {
        VStack(spacing: 0) {
            // Next Schedule
            VStack(spacing: 12) {
                HStack {
                    VStack(alignment: .leading) {
                        Label("Bedtime", systemImage: "bed.double")
                            .font(.caption)
                        Text("10:30 PM")
                            .font(.largeTitle.bold())
                        Text("Tonight")
                            .font(.caption)
                    }
                    
                    Spacer()
                    
                    VStack(alignment: .leading) {
                        Label("Wake Up", systemImage: "alarm")
                            .font(.caption)
                        Text("7:00 AM")
                            .font(.largeTitle.bold())
                        Text("Tomorrow")
                            .font(.caption)
                    }
                }
                
                Divider()
                
                Button("Edit Schedule") { /* Edit action */ }
            }
            .padding()
            .background(cardBackgroundColor)
            .cornerRadius(12)
        }
        .padding(.horizontal)
    }
}

// MARK: - Previews
struct SleepDetailView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            SleepDetailView()
                .preferredColorScheme(.dark)
            
            SleepDetailView()
                .preferredColorScheme(.light)
        }
    }
}