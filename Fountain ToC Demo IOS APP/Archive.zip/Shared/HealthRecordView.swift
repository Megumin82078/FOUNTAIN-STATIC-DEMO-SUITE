import SwiftUI

// Health Record Model
struct HealthRecord: Identifiable {
    let id = UUID()
    let date: String // 确保 date 是 String
    let department: String
    let clinic: String
    let doctor: String
    let diagnosis: String
    let prescription: String
    let advice: String
    let followUp: String
}

// Sample Data
let sampleRecords: [HealthRecord] = [
    HealthRecord(date: "2025/01/10", department: "General Outpatient", clinic: "ABC Clinic", doctor: "Dr. John Doe", diagnosis: "Cold", prescription: "Paracetamol, 2 times/day", advice: "Drink more water, rest well", followUp: "Revisit after one week"),
    HealthRecord(date: "2024/12/05", department: "Specialist Outpatient", clinic: "XYZ Clinic", doctor: "Dr. Jane Smith", diagnosis: "Skin Allergy", prescription: "Antihistamines, 1 time/day", advice: "Keep skin clean, avoid allergens", followUp: "Check-up after two weeks"),
    HealthRecord(date: "2024/11/20", department: "Hospital Admission", clinic: "DEF Hospital", doctor: "Dr. Michael Brown", diagnosis: "Gastroscopy Examination", prescription: "N/A", advice: "Fasting before procedure", followUp: "Scheduled next month"),
    HealthRecord(date: "2024/10/02", department: "Hospital Admission", clinic: "DEF Hospital", doctor: "Dr. Michael Brown", diagnosis: "Gastroscopy Examination", prescription: "N/A", advice: "Fasting before procedure", followUp: "Scheduled next month"),
    HealthRecord(date: "2024/08/03", department: "Hospital Admission", clinic: "DEF Hospital", doctor: "Dr. Michael Brown", diagnosis: "Gastroscopy Examination", prescription: "N/A", advice: "Fasting before procedure", followUp: "Scheduled next month"),
    HealthRecord(date: "2024/06/12", department: "Hospital Admission", clinic: "DEF Hospital", doctor: "Dr. Michael Brown", diagnosis: "Gastroscopy Examination", prescription: "N/A", advice: "Fasting before procedure", followUp: "Scheduled next month")

]

// Health Record List View
struct HealthRecordView: View {
    @State private var selectedRecord: HealthRecord?
    
    var body: some View {
        NavigationView {
            List(sampleRecords) { record in
                Button(action: {
                    selectedRecord = record
                }) {
                    VStack(alignment: .leading) {
                        Text(record.date)
                            .font(.headline)
                            .foregroundStyle(.primary)
                        Text("\(record.department) - \(record.clinic)")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle("Health Records")
        }
        .sheet(item: $selectedRecord) { record in
            HealthRecordDetailView(record: record)
        }
    }
}

// Health Record Detail View (Sheet)
struct HealthRecordDetailView: View {
    let record: HealthRecord
    
    var body: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 15) {
                Text("Date: \(record.date)")
                    .font(.headline)
                Text("Department: \(record.department)")
                    .font(.subheadline)
                Text("Clinic: \(record.clinic)")
                    .font(.subheadline)
                Text("Doctor: \(record.doctor)")
                    .font(.subheadline)
                Divider()
                Text("Diagnosis: \(record.diagnosis)")
                    .font(.title3)
                    .bold()
                Text("Prescription: \(record.prescription)")
                    .font(.body)
                Text("Advice & Notes: \(record.advice)")
                    .font(.body)
                Text("Follow-up: \(record.followUp)")
                    .font(.body)
                    .foregroundStyle(.blue)
                
                Spacer()
            }
            .padding()
            .navigationTitle("Record Details")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Close") {
                        dismiss()
                    }
                }
            }
        }
    }
    
    @Environment(\.dismiss) private var dismiss
}

// Preview
struct HealthRecordView_Previews: PreviewProvider {
    static var previews: some View {
        HealthRecordsView()
            .preferredColorScheme(.dark) // 测试深色模式
    }
}
