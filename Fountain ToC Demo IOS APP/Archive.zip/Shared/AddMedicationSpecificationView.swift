import SwiftUI

struct AddMedicationSpecificationView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) private var colorScheme
    
    let medicationName: String
    let medicationType: String
    @State private var specification: String = ""
    @State private var selectedUnit: String?
    @State private var navigateToNextStep = false
    @State private var showMedicationScheduleView = false
    
    // 可选单位
    let units = ["Milligram", "microgram", "gram", "milliliter", "%"]
    
    // 根据当前主题获取背景色
    var backgroundColor: Color {
        colorScheme == .dark ? Color.black : Color.white
    }
    
    // 根据当前主题获取文本颜色
    var textColor: Color {
        colorScheme == .dark ? Color.white : Color.black
    }
    
    // 根据当前主题获取输入框背景色
    var textFieldBackgroundColor: Color {
        colorScheme == .dark ? Color(red: 0.17, green: 0.17, blue: 0.18) : Color(UIColor.systemGray6)
    }
    
    // 根据当前主题获取卡片背景色
    var cardBackgroundColor: Color {
        colorScheme == .dark ? Color(red: 0.17, green: 0.17, blue: 0.18) : Color(UIColor.systemGray6)
    }
    
    // 根据当前主题获取分割线颜色
    var dividerColor: Color {
        colorScheme == .dark ? Color.gray.opacity(0.3) : Color.gray.opacity(0.2)
    }
    
    var body: some View {
        ZStack {
            // 背景色
            backgroundColor.edgesIgnoringSafeArea(.all)
            
            ScrollView {
                VStack(spacing: 0) {
                    // 导航栏
                    HStack {
                        Button(action: {
                            presentationMode.wrappedValue.dismiss()
                        }) {
                            Text("cancel")
                                .foregroundColor(Color.blue)
                                .font(.system(size: 17))
                        }
                        
                        Spacer()
                        
                        Text("Additive Drug Specification")
                            .font(.system(size: 17, weight: .semibold))
                            .foregroundColor(textColor)
                        
                        Spacer()
                        
                        Button(action: {
                            // 完成操作
                            // 这里可以添加保存逻辑
                        }) {
                            Text("Done")
                                .foregroundColor(Color.blue)
                                .font(.system(size: 17))
                        }
                    }
                    .padding(.horizontal)
                    .padding(.top, 20)
                    .padding(.bottom, 20)
                    
                    // 药品名称和类型
                    VStack(spacing: 4) {
                        Text(medicationName)
                            .font(.system(size: 28, weight: .bold))
                            .foregroundColor(textColor)
                        
                        Text(medicationType)
                            .font(.system(size: 17))
                            .foregroundColor(textColor.opacity(0.7))
                    }
                    .padding(.bottom, 30)
                    
                    // 药品规格图标
                    specificationIcon
                        .padding(.bottom, 30)
                    
                    // 添加药品规格标题
                    Text("Additive Drug Specification")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundColor(textColor)
                        .padding(.bottom, 30)
                    
                    // 规格部分
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Specification")
                            .font(.system(size: 17, weight: .medium))
                            .foregroundColor(textColor)
                            .padding(.leading)
                        
                        TextField("", text: $specification)
                            .font(.system(size: 17))
                            .foregroundColor(textColor)
                            .keyboardType(.numberPad)
                            .padding()
                            .background(textFieldBackgroundColor)
                            .cornerRadius(10)
                            .padding(.horizontal)
                    }
                    .padding(.bottom, 20)
                    
                    // 选择单位部分
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Select Unit")
                            .font(.system(size: 17, weight: .medium))
                            .foregroundColor(textColor)
                            .padding(.leading)
                        
                        VStack(spacing: 0) {
                            ForEach(units, id: \.self) { unit in
                                Button(action: {
                                    selectedUnit = unit
                                }) {
                                    HStack {
                                        Text(unit)
                                            .font(.system(size: 17))
                                            .foregroundColor(textColor)
                                        
                                        Spacer()
                                        
                                        if selectedUnit == unit {
                                            Image(systemName: "checkmark")
                                                .foregroundColor(.blue)
                                                .font(.system(size: 17))
                                        }
                                    }
                                    .padding()
                                    .background(cardBackgroundColor)
                                }
                                .buttonStyle(PlainButtonStyle())
                                
                                if unit != units.last {
                                    Divider()
                                        .background(dividerColor)
                                        .padding(.leading)
                                }
                            }
                        }
                        .background(cardBackgroundColor)
                        .cornerRadius(10)
                        .padding(.horizontal)
                    }
                    
                    Spacer()
                    
                    // 底部按钮
                    VStack(spacing: 10) {
                        // 下一步按钮
                        Button(action: {
                            showMedicationScheduleView = true
                        }) {
                            Text("Next Step")
                                .font(.system(size: 17, weight: .medium))
                                .foregroundColor(specification.isEmpty || selectedUnit == nil ? Color.gray : Color.white)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 16)
                                .background(
                                    RoundedRectangle(cornerRadius: 10)
                                        .fill(specification.isEmpty || selectedUnit == nil ? cardBackgroundColor : Color.blue)
                                )
                        }
                        .disabled(specification.isEmpty || selectedUnit == nil)
                        .sheet(isPresented: $showMedicationScheduleView) {
                            MedicationScheduleView(
                                medicationName: "Ggg", 
                                medicationType: "capsule", 
                                specification: "5 milligram"
                            )
                        }
                        // 跳过按钮
                        Button("skip") {
                            // 跳过操作
                            presentationMode.wrappedValue.dismiss()
                        }
                        .foregroundColor(Color.blue)
                        .font(.system(size: 17))
                        .padding(.vertical, 10)
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 30)
                }
            }
        }
        .navigationBarHidden(true)
    }
    
    // 药品规格图标
    var specificationIcon: some View {
        ZStack {
            // 黄色圆形
            Circle()
                .stroke(Color.yellow, lineWidth: 2)
                .frame(width: 40, height: 40)
                .offset(x: -40, y: 0)
            
            // 黄色圆形内部虚线
            Rectangle()
                .stroke(Color.yellow, style: StrokeStyle(lineWidth: 1, dash: [3]))
                .frame(width: 30, height: 1)
                .offset(x: -40, y: 0)
            
            // 浅蓝色胶囊
            Capsule()
                .stroke(Color.cyan, lineWidth: 2)
                .frame(width: 60, height: 30)
                .offset(x: 0, y: 0)
            
            // 浅蓝色胶囊内部虚线
            Rectangle()
                .stroke(Color.cyan, style: StrokeStyle(lineWidth: 1, dash: [3]))
                .frame(width: 40, height: 1)
                .offset(x: 0, y: 0)
            
            // 深蓝色胶囊
            Capsule()
                .stroke(Color.blue, lineWidth: 2)
                .frame(width: 60, height: 30)
                .offset(x: 40, y: 0)
            
            // 深蓝色胶囊内部虚线
            Rectangle()
                .stroke(Color.blue, style: StrokeStyle(lineWidth: 1, dash: [3]))
                .frame(width: 40, height: 1)
                .offset(x: 40, y: 0)
        }
        .frame(width: 150, height: 50)
    }
}

struct AddMedicationSpecificationView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            AddMedicationSpecificationView(medicationName: "Ggg", medicationType: "capsule")
                .preferredColorScheme(.dark)
                .previewDisplayName("Dark Mode")
            
            AddMedicationSpecificationView(medicationName: "Ggg", medicationType: "capsule")
                .preferredColorScheme(.light)
                .previewDisplayName("Light Mode")
        }
    }
}