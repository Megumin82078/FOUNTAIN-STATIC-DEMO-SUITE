import SwiftUI

struct MedicationView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) private var colorScheme
    
    // 当前日期
    @State private var currentDate = Date()
    @State private var formattedDate = ""
    @State private var weekdaySymbol = ""
    @State private var dayNumber = ""
    
    // 周几数组
    let weekdays = ["Mon", "Tus", "Wed", "Thu", "Fri", "Sat", "Sun", "Mon", "Tus", "Wed"]
    
    // 当前选中的日期索引
    @State private var selectedDayIndex = 5 // 默认选中"六"
    
    // Additive drug按钮
    @State private var showAddMedicationView = false
    @State private var showAddSpecificationView = false
    @State private var showMedicationScheduleView = false
    @State private var showSelectShapeView = false
    @State private var showSelectColorView = false
    @State private var medicationShape = "capsule" // 可以从前一个视图传递过来
    @State private var showMedicationDetailView = false
    
    // 根据当前主题获取背景色
    var backgroundColor: Color {
        colorScheme == .dark ? Color.black : Color.white
    }
    
    // 根据当前主题获取文本颜色
    var textColor: Color {
        colorScheme == .dark ? Color.white : Color.black
    }
    
    // 根据当前主题获取卡片背景色
    var cardBackgroundColor: Color {
        colorScheme == .dark ? Color(red: 0.17, green: 0.22, blue: 0.28) : Color(UIColor.systemGray6)
    }
    
    // 根据当前主题获取药品卡片背景色
    var medicationCardBackgroundColor: Color {
        colorScheme == .dark ? Color(red: 0.17, green: 0.22, blue: 0.28) : Color(UIColor.systemGray5)
    }
    
    // 根据当前主题获取分割线颜色
    var dividerColor: Color {
        colorScheme == .dark ? Color.gray.opacity(0.3) : Color.gray.opacity(0.2)
    }
    
    // 根据当前主题获取日期选择器背景色
    var datePickerBackgroundColor: Color {
        colorScheme == .dark ? Color.black : Color.white
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                navigationBar
                dateHeader
                dateSelector
                recordsSection
                medicationsSection
                aboutMedicationSection
            }
        }
        .background(backgroundColor.edgesIgnoringSafeArea(.all))
        .navigationBarHidden(true)
        .onAppear(perform: setupDate)
    }
    
    // MARK: - UI Components
    
    // 导航栏
    var navigationBar: some View {
        HStack {
            Button(action: {
                presentationMode.wrappedValue.dismiss()
            }) {
                HStack(spacing: 5) {
                    Image(systemName: "chevron.left")
                        .foregroundColor(Color.blue)
                        .font(.system(size: 16, weight: .semibold))
                    Text("Browse")
                        .foregroundColor(Color.blue)
                        .font(.system(size: 17))
                }
            }
            
            Spacer()
            
            Text("medicate")
                .font(.system(size: 17, weight: .semibold))
                .foregroundColor(textColor)
            
            Spacer()
            
            // 占位，保持标题居中
            HStack(spacing: 5) {
                Text("Browse")
                    .foregroundColor(.clear)
                    .font(.system(size: 17))
            }
        }
        .padding(.horizontal)
        .padding(.top, 10)
        .padding(.bottom, 10)
    }
    
    // 日期头部
    var dateHeader: some View {
        Text("Toady, \(formattedDate)")
            .font(.system(size: 22, weight: .bold))
            .foregroundColor(textColor)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 15)
    }
    
    // 日期选择器
    var dateSelector: some View {
        ZStack {
            // 背景和选中指示器
            VStack {
                Rectangle()
                    .fill(Color.clear)
                    .frame(height: 30)
                
                // 选中指示器
                Circle()
                    .fill(Color.white)
                    .frame(width: 36, height: 36)
                
                Rectangle()
                    .fill(Color.clear)
                    .frame(height: 30)
            }
            
            // 日期滚动视图
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 20) {
                    ForEach(0..<10, id: \.self) { index in
                        dateSelectorItem(index: index)
                    }
                }
                .padding(.horizontal, 50)
            }
        }
        .frame(height: 100)
        .background(datePickerBackgroundColor)
    }
    
    // 日期选择器项
    func dateSelectorItem(index: Int) -> some View {
        VStack(spacing: 8) {
            Text(weekdays[index])
                .font(.system(size: 15))
                .foregroundColor(selectedDayIndex == index ? Color.black : Color.gray)
            
            ZStack {
                Circle()
                    .fill(selectedDayIndex == index ? Color.blue : Color.clear)
                    .frame(width: 36, height: 36)
                
                Text("\(index + 3)") // 假设从3号开始
                    .font(.system(size: 17, weight: .medium))
                    .foregroundColor(selectedDayIndex == index ? Color.white : Color.gray)
            }
        }
        .onTapGesture {
            withAnimation {
                selectedDayIndex = index
            }
        }
    }
    
    // 记录部分
    var recordsSection: some View {
        VStack(alignment: .leading, spacing: 0) {
            // 记录标题
            HStack {
                Text("Records")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundColor(textColor)
                
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top, 25)
            .padding(.bottom, 10)
            
            // 23:05 记录卡片
            recordCard(time: "23:05")
            
            // 按需服药卡片
            recordCard(time: "Medication on demand")
        }
    }
    
    // 记录卡片
    func recordCard(time: String) -> some View {
        Button(action: {
            // 点击操作
        }) {
            HStack {
                Text(time)
                    .font(.system(size: 17))
                    .foregroundColor(textColor)
                
                Spacer()
                
                // 药丸图标
                if time == "23:05" {
                    ZStack {
                        Circle()
                            .fill(Color(red: 0.2, green: 0.4, blue: 0.6))
                            .frame(width: 36, height: 36)
                        
                        Text("Aa")
                            .font(.system(size: 17, weight: .bold))
                            .foregroundColor(.white)
                    }
                }
                
                Image(systemName: "plus")
                    .font(.system(size: 20, weight: .medium))
                    .foregroundColor(Color.blue)
            }
            .padding()
            .background(cardBackgroundColor)
            .cornerRadius(12)
            .padding(.horizontal)
            .padding(.bottom, 10)
        }
        .buttonStyle(PlainButtonStyle())
    }
    
    // 药品部分
    var medicationsSection: some View {
        VStack(alignment: .leading, spacing: 0) {
            // 你的药品标题
            HStack {
                Text("Your medicine")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundColor(textColor)
                
                Spacer()
                
                NavigationLink(destination: EditMedicationListView()) {
                    Text("Edit")
                        .font(.system(size: 17))
                        .foregroundColor(Color.blue)
                }
            }
            .padding(.horizontal)
            .padding(.top, 30)
            .padding(.bottom, 10)
            
            // 药品卡片
            medicationCard
            
            // Additive drug按钮
            addMedicationButton1
        }
    }
    
    // 药品卡片
    var medicationCard: some View {
        Button(action: {
            // 点击操作
        }) {
            HStack(spacing: 15) {
                // 药品图片
                ZStack {
                    Rectangle()
                        .fill(Color(red: 0.2, green: 0.4, blue: 0.6))
                        .frame(width: 80, height: 80)
                        .cornerRadius(8)
                    
                    Text("💊")
                        .font(.system(size: 40))
                }
                
                // 药品信息
                VStack(alignment: .leading, spacing: 5) {
                    Text("Aa")
                        .font(.system(size: 22, weight: .medium))
                        .foregroundColor(textColor)
                    
                    Text("External use")
                        .font(.system(size: 17))
                        .foregroundColor(Color.gray)
                    
                    Text("1 milligram")
                        .font(.system(size: 17))
                        .foregroundColor(Color.gray)
                    
                    HStack(spacing: 5) {
                        Image(systemName: "calendar")
                            .font(.system(size: 15))
                            .foregroundColor(Color.gray)
                        
                        Text("everyday")
                            .font(.system(size: 15))
                            .foregroundColor(Color.gray)
                    }
                }
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .foregroundColor(Color(UIColor.systemGray4))
                    .font(.system(size: 14))
            }
            .padding()
            .background(medicationCardBackgroundColor)
            .cornerRadius(12)
            .padding(.horizontal)
        }
        .buttonStyle(PlainButtonStyle())
    }
    
    // Additive drug按钮
    var addMedicationButton1: some View {
        Button(action: {
            showAddMedicationView = true
        }) {
            HStack {
                Text("Additive drug")
                    .font(.system(size: 17))
                    .foregroundColor(Color.blue)
                
                Spacer()
            }
            .padding()
            .background(cardBackgroundColor)
            .cornerRadius(12)
            .padding(.horizontal)
            .padding(.top, 10)
        }
        .buttonStyle(PlainButtonStyle())
        // Additive drug
        .sheet(isPresented: $showAddMedicationView) {
            AddMedicationView()
        }
    }
    // Additive drug规格
    var addMedicationButton2: some View {
        Button(action: {
            showAddSpecificationView = true
        }) {
            HStack {
                Text("Additive drug")
                    .font(.system(size: 17))
                    .foregroundColor(Color.blue)
                
                Spacer()
            }
            .padding()
            .background(cardBackgroundColor)
            .cornerRadius(12)
            .padding(.horizontal)
            .padding(.top, 10)
        }
        .buttonStyle(PlainButtonStyle())
        // Additive drug规格
        .sheet(isPresented: $showAddSpecificationView) {
            AddMedicationSpecificationView(medicationName: "Ggg", medicationType: "胶囊")
        }
    }
    // 添加何时食用该药
    var addMedicationButton3: some View {
        Button(action: {
             showMedicationScheduleView = true
        }) {
            HStack {
                Text("Additive drug")
                    .font(.system(size: 17))
                    .foregroundColor(Color.blue)
                
                Spacer()
            }
            .padding()
            .background(cardBackgroundColor)
            .cornerRadius(12)
            .padding(.horizontal)
            .padding(.top, 10)
        }
        .buttonStyle(PlainButtonStyle())
        .sheet(isPresented: $showMedicationScheduleView) {
            MedicationScheduleView(
                medicationName: "Ggg", 
                medicationType: "capsule", 
                specification: "5 milligram"
            )
        }
    }
    // Additive drug形状
    var addMedicationButton4: some View {
        Button(action: {
            showSelectShapeView = true
        }) {
            HStack {
                Text("Additive drug")
                    .font(.system(size: 17))
                    .foregroundColor(Color.blue)
                
                Spacer()
            }
            .padding()
            .background(cardBackgroundColor)
            .cornerRadius(12)
            .padding(.horizontal)
            .padding(.top, 10)
        }
        .buttonStyle(PlainButtonStyle())
        .sheet(isPresented: $showSelectShapeView) {
            SelectMedicationShapeView(medicationName: "Ggg", specification: "5 毫克")
        }
    }
     // Additive drug颜色
    var addMedicationButton5: some View {
        Button(action: {
            showSelectColorView = true
        }) {
            HStack {
                Text("Additive drug")
                    .font(.system(size: 17))
                    .foregroundColor(Color.blue)
                
                Spacer()
            }
            .padding()
            .background(cardBackgroundColor)
            .cornerRadius(12)
            .padding(.horizontal)
            .padding(.top, 10)
        }
        .buttonStyle(PlainButtonStyle())
        .sheet(isPresented: $showSelectColorView) {
            SelectMedicationColorView(
                medicationName: "Ggg", 
                specification: "5 milligram",
                medicationShape: medicationShape
            )
        }
    }
     // 完成药品信息编辑
    var addMedicationButton6: some View {
        Button(action: {
            showMedicationDetailView = true
        }) {
            HStack {
                Text("Additive drug")
                    .font(.system(size: 17))
                    .foregroundColor(Color.blue)
                
                Spacer()
            }
            .padding()
            .background(cardBackgroundColor)
            .cornerRadius(12)
            .padding(.horizontal)
            .padding(.top, 10)
        }
        .buttonStyle(PlainButtonStyle())
        .sheet(isPresented: $showMedicationDetailView) {
            MedicationDetailView(
                medicationName: "Ggg",
                specification: "5 milligram",
                medicationType: "capsule"
            )
        }
    }
    
    // 关于用药部分
    var aboutMedicationSection: some View {
        VStack(alignment: .leading, spacing: 0) {
            // 关于用药标题
            HStack {
                Text("About medication")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundColor(textColor)
                
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top, 30)
            .padding(.bottom, 10)
            
            // 关于用药图片
            aboutMedicationCard
        }
    }
    
    // 关于用药卡片
    var aboutMedicationCard: some View {
        ZStack {
            Rectangle()
                .fill(Color(red: 0.17, green: 0.22, blue: 0.28))
                .frame(height: 120)
                .cornerRadius(12)
                .padding(.horizontal)
            
            HStack(spacing: 30) {
                // 太阳图标
                Image(systemName: "sun.max.fill")
                    .font(.system(size: 40))
                    .foregroundColor(Color.white.opacity(0.8))
                
                // 月亮图标
                Image(systemName: "moon.fill")
                    .font(.system(size: 40))
                    .foregroundColor(Color.white.opacity(0.8))
                
                // 水杯图标
                Image(systemName: "cup.and.saucer.fill")
                    .font(.system(size: 40))
                    .foregroundColor(Color.white.opacity(0.8))
            }
        }
        .padding(.bottom, 50)
    }
    
    // MARK: - Helper Methods
    
    // 设置日期
    func setupDate() {
        // 格式化当前日期
        let formatter = DateFormatter()
        formatter.dateFormat = "M月d日"
        formattedDate = formatter.string(from: currentDate)
        
        // 获取星期几
        let weekdayFormatter = DateFormatter()
        weekdayFormatter.dateFormat = "e" // 1-7 表示周一到周日
        let weekdayNumber = Int(weekdayFormatter.string(from: currentDate)) ?? 0
        weekdaySymbol = weekdays[weekdayNumber - 1]
        
        // 获取日期
        let dayFormatter = DateFormatter()
        dayFormatter.dateFormat = "d"
        dayNumber = dayFormatter.string(from: currentDate)
        
        // 设置选中的日期索引
        selectedDayIndex = weekdayNumber - 1
    }
}

struct MedicationView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            MedicationView()
                .preferredColorScheme(.dark)
                .previewDisplayName("Dark Mode")
            
            MedicationView()
                .preferredColorScheme(.light)
                .previewDisplayName("Light Mode")
        }
    }
}
