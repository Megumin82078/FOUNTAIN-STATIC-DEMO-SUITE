import SwiftUI

struct WalkingHeartRateView: View {
     // 动态标题属性（新增）
    let title: String
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) private var colorScheme
    
    enum TimeRange: String, CaseIterable, Identifiable {
        case day = "Day"
        case week = "Week"
        case month = "Month"
        case sixMonths = "6 Months"
        case year = "Year"
        
        var id: String { self.rawValue }
    }
    
    @State private var selectedTimeRange: TimeRange = .day
    
    struct HeartRatePoint: Identifiable {
        let id = UUID()
        let time: String
        let value: Double?
    }
    
    var heartRateData: [HeartRatePoint] {
        switch selectedTimeRange {
        case .day:
            return (0...23).map { hour in
                let hasData = (hour >= 6 && hour <= 22) ? Bool.random() : false
                return HeartRatePoint(
                    time: "\(hour)h",
                    value: hasData ? Double.random(in: 60...120) : nil
                )
            }
        case .week:
            let days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
            return days.map { day in
                HeartRatePoint(
                    time: day,
                    value: Bool.random() ? Double.random(in: 65...115) : nil
                )
            }
        case .month:
            return (1...30).map { day in
                HeartRatePoint(
                    time: "Day \(day)",
                    value: Bool.random() ? Double.random(in: 70...110) : nil
                )
            }
        case .sixMonths:
            let months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"]
            return months.map { month in
                HeartRatePoint(
                    time: month,
                    value: Bool.random() ? Double.random(in: 75...105) : nil
                )
            }
        case .year:
            let months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", 
                         "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
            return months.map { month in
                HeartRatePoint(
                    time: month,
                    value: Bool.random() ? Double.random(in: 80...100) : nil
                )
            }
        }
    }
    
    // Theme-adaptive colors
    private var backgroundColor: Color { Color(.systemBackground) }
    private var textColor: Color { Color.primary }
    private var chartBackgroundColor: Color { Color(.secondarySystemBackground) }
    private var gridLineColor: Color { Color(.separator) }
    private var cardBackgroundColor: Color { Color(.tertiarySystemBackground) }
    
    private var currentTimeDescription: String {
        switch selectedTimeRange {
        case .day: return "Today"
        case .week: return "This Week"
        case .month: return "This Month"
        case .sixMonths: return "Last 6 Months"
        case .year: return "This Year"
        }
    }
    
    private var timeLabels: [String] {
        switch selectedTimeRange {
        case .day: return ["0h", "6h", "12h", "18h"]
        case .week: return ["Mon", "Wed", "Fri", "Sun"]
        case .month: return ["1st", "10th", "20th", "30th"]
        case .sixMonths: return ["Jan", "Feb", "Apr", "Jun"]
        case .year: return ["Jan", "Apr", "Aug", "Dec"]
        }
    }
    
    var body: some View {
        ZStack {
            backgroundColor.edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 0) {
                // Header Section
                VStack(spacing: 0) {
                    // Navigation Bar
                    HStack {
                        Button(action: { presentationMode.wrappedValue.dismiss() }) {
                            HStack(spacing: 5) {
                                Image(systemName: "chevron.left")
                                    .foregroundColor(.accentColor)
                                Text("Heart")
                                    .foregroundColor(.accentColor)
                            }
                        }
                        
                        Spacer()
                        
                        Text(title)
                            .font(.headline)
                        
                        Spacer()
                        
                        // Spacer for layout
                        HStack(spacing: 5) {
                            Text("      ").hidden()
                        }
                    }
                    .padding()
                    
                    // Time Range Picker
                    HStack(spacing: 0) {
                        ForEach(TimeRange.allCases) { range in
                            Button(action: { selectedTimeRange = range }) {
                                Text(range.rawValue)
                                    .font(.subheadline)
                                    .foregroundColor(textColor)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 8)
                                    .background(
                                        selectedTimeRange == range ? 
                                        Color(.quaternarySystemFill) : 
                                        Color.clear
                                    )
                                    .cornerRadius(8)
                            }
                            
                            if range != TimeRange.allCases.last {
                                Divider()
                                    .background(gridLineColor)
                                    .frame(height: 20)
                            }
                        }
                    }
                    .background(chartBackgroundColor)
                    .cornerRadius(8)
                    .padding(.horizontal)
                }
                .background(backgroundColor)
                .zIndex(1)
                
                // Scrollable Content
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        // Data Visualization Section
                        VStack(alignment: .leading, spacing: 10) {
                            Text("No Data")
                                .font(.largeTitle.bold())
                            
                            Text(currentTimeDescription)
                                .foregroundColor(.secondary)
                            
                            // Chart Area
                            ZStack {
                                // Grid Lines
                                GridView(lineColor: gridLineColor)
                                
                                // Time Labels
                                VStack {
                                    Spacer()
                                    HStack {
                                        ForEach(timeLabels, id: \.self) { label in
                                            Text(label)
                                                .font(.caption)
                                                .foregroundColor(.secondary)
                                                .frame(maxWidth: .infinity, 
                                                       alignment: label == timeLabels.first ? .leading : 
                                                                label == timeLabels.last ? .trailing : .center)
                                        }
                                    }
                                }
                            }
                            .frame(height: 300)
                        }
                        .padding()
                        
                        // Educational Content
                        VStack(alignment: .leading, spacing: 15) {
                            Text("About  " + title)
                                .font(.title2.bold())
                            
                            VStack(alignment: .leading, spacing: 15) {
                                Text("This is a description of the article, mainly tells the role of this, how to deal with it, and the final conclusion")
                            }
                            .padding()
                            .background(cardBackgroundColor)
                            .cornerRadius(12)
                        }
                        .padding(.horizontal)
                        
                        .padding(.vertical)
                    }
                }
            }
        }
        .navigationBarHidden(true)
    }
    
    // MARK: - Components
    private func GridView(lineColor: Color) -> some View {
        ZStack {
            VStack(spacing: 0) {
                ForEach(0..<5, id: \.self) { _ in
                    Spacer()
                    Divider().background(lineColor)
                }
            }
            
            HStack(spacing: 0) {
                ForEach(0..<5, id: \.self) { _ in
                    Divider().background(lineColor)
                    Spacer()
                }
            }
        }
    }
    
    private func NavButton(icon: String, label: String, isActive: Bool = false) -> some View {
        VStack(spacing: 5) {
            Image(systemName: icon)
                .font(.system(size: 22))
                .foregroundColor(isActive ? .accentColor : .secondary)
            
            Text(label)
                .font(.caption)
                .foregroundColor(isActive ? .accentColor : .secondary)
        }
        .frame(maxWidth: .infinity)
    }
}

struct WalkingHeartRateView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            WalkingHeartRateView(title: "")
                .preferredColorScheme(.dark)
            
            WalkingHeartRateView(title: "")
                .preferredColorScheme(.light)
        }
    }
}