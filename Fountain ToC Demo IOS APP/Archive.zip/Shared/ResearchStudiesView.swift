import SwiftUI

struct ResearchStudiesView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Button(action: {
                    // 处理返回按钮操作
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.blue)
                    Text("Profile")
                        .foregroundColor(.blue)
                }
                Spacer()
            }
            .padding()
            
            Text("Research Studies")
                .font(.title2)
                .bold()
                .frame(maxWidth: .infinity, alignment: .center)
                .padding(.top, -10)
            
            Text("RESEARCH STUDIES")
                .font(.caption)
                .foregroundColor(.gray)
                .padding(.leading)
            
            TextField("None", text: .constant(""))
                .padding()
                .background(RoundedRectangle(cornerRadius: 10).fill(colorScheme == .dark ? Color.black.opacity(0.2) : Color.white))
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray.opacity(0.5)))
                .padding(.horizontal)
                
            Text("As research studies request permission to read your data, they will be added to the list. You can review and manage all of the studies you are enrolled in by going to the Research app.")
                .font(.footnote)
                .foregroundColor(.gray)
                .padding(.horizontal)
            
            Spacer()
        }
        .background(colorScheme == .dark ? Color.black : Color(UIColor.systemGray6))
        .edgesIgnoringSafeArea(.bottom)
    }
}

struct ResearchStudiesView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ResearchStudiesView()
                .preferredColorScheme(.light)
            ResearchStudiesView()
                .preferredColorScheme(.dark)
        }
    }
}
