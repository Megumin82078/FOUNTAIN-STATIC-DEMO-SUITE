import SwiftUI

struct NoDataView: View {
    var title: String = "No Data"
    var message: String = "No records available at this time"
    var iconName: String = "doc.text.magnifyingglass"
    
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        VStack(spacing: 20) {
            Spacer()
            
            // Icon
            Image(systemName: iconName)
                .font(.system(size: 70))
                .foregroundColor(colorScheme == .dark ? Color.gray.opacity(0.7) : Color.gray.opacity(0.6))
                .padding(.bottom, 10)
            
            // Title
            Text(title)
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(.primary)
            
            // Description
            Text(message)
                .font(.body)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
            
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(colorScheme == .dark ? Color(UIColor.systemBackground) : Color(.systemGroupedBackground))
    }
}

// Extended version for health data
struct HealthNoDataView: View {
    var category: String
    var actionText: String = "Add Data"
    var action: (() -> Void)? = nil
    
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        VStack(spacing: 25) {
            NoDataView(
                title: "No \(category) Data",
                message: "You don't have any \(category) records. Add data or connect a device to sync.",
                iconName: "waveform.path"
            )
            
            if let action = action {
                Button(action: action) {
                    Text(actionText)
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding(.vertical, 12)
                        .padding(.horizontal, 30)
                        .background(Color.accentColor)
                        .cornerRadius(10)
                }
                .padding(.bottom, 30)
                .shadow(color: colorScheme == .dark ? Color.black.opacity(0.3) : Color.black.opacity(0.1), 
                        radius: 3, x: 0, y: 1)
            }
        }
    }
}

struct NoDataView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            NoDataView()
                .previewDisplayName("Basic No Data View")
            
            HealthNoDataView(category: "Steps", action: {})
                .previewDisplayName("Health No Data View")
            
            NoDataView(
                title: "No Search Results",
                message: "No matching health data found. Try different search terms.",
                iconName: "magnifyingglass"
            )
            .previewDisplayName("No Search Results")
            
            NoDataView()
                .preferredColorScheme(.dark)
                .previewDisplayName("Dark Mode")
        }
    }
}
