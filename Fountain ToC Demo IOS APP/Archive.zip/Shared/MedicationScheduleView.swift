import SwiftUI

struct MedicationScheduleView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) private var colorScheme
    
    let medicationName: String
    let medicationType: String
    let specification: String
    
    @State private var frequency: String = "Every Day"
    @State private var scheduledTimes: [(String, Int)] = [("16:40", 1)]
    @State private var showTimePicker = false
    @State private var selectedTimeIndex: Int?
    @State private var tempTime: Date = Date()
    @State private var tempDosage: Int = 1
    @State private var showSelectShapeView = false
    
    // 根据当前主题获取背景色
    var backgroundColor: Color {
        colorScheme == .dark ? Color.black : Color.white
    }
    
    // 根据当前主题获取文本颜色
    var textColor: Color {
        colorScheme == .dark ? Color.white : Color.black
    }
    
    // 根据当前主题获取卡片背景色
    var cardBackgroundColor: Color {
        colorScheme == .dark ? Color(red: 0.17, green: 0.17, blue: 0.18) : Color(UIColor.systemGray6)
    }
    
    // 根据当前主题获取分割线颜色
    var dividerColor: Color {
        colorScheme == .dark ? Color.gray.opacity(0.3) : Color.gray.opacity(0.2)
    }
    
    var body: some View {
        ZStack {
            backgroundView
            
            ScrollView {
                contentView
            }
            
            if showTimePicker {
                timePickerView
            }
        }
        .navigationBarHidden(true)
    }
    
    // 背景视图
    private var backgroundView: some View {
        Color(colorScheme == .dark ? .black : .white)
            .edgesIgnoringSafeArea(.all)
    }
    
    // 主内容视图
    private var contentView: some View {
        VStack(spacing: 0) {
            navigationBar
            medicationInfo
            medicationIcon
                .padding(.bottom, 30)
            titleText
            frequencySection
            reminderText
            scheduledTimesSection
            Spacer(minLength: 50)
            nextButton
        }
    }
    
    // 导航栏
    private var navigationBar: some View {
        HStack {
            Button(action: {
                presentationMode.wrappedValue.dismiss()
            }) {
                Text("cancel")
                    .foregroundColor(Color.blue)
                    .font(.system(size: 17))
            }
            
            Spacer()
            
            Text("When do you take this medicine?")
                .font(.system(size: 17, weight: .semibold))
                .foregroundColor(colorScheme == .dark ? .white : .black)
            
            Spacer()
            
            Button("back") {
                presentationMode.wrappedValue.dismiss()
            }
            .foregroundColor(Color.blue)
            .font(.system(size: 17))
        }
        .padding(.horizontal)
        .padding(.top, 20)
        .padding(.bottom, 20)
    }
    
    // 药品信息
    private var medicationInfo: some View {
        VStack(spacing: 4) {
            Text(medicationName)
                .font(.system(size: 28, weight: .bold))
                .foregroundColor(textColor)
            
            Text("\(medicationType), \(specification)")
                .font(.system(size: 17))
                .foregroundColor(textColor.opacity(0.7))
        }
        .padding(.bottom, 30)
    }
    
    // 药品图标
    private var medicationIcon: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color.gray, lineWidth: 2)
                .frame(width: 80, height: 80)
            
            // 药品图标内部的点阵
            VStack(spacing: 8) {
                ForEach(0..<3) { _ in
                    HStack(spacing: 8) {
                        ForEach(0..<4) { _ in
                            Rectangle()
                                .fill(Color.cyan)
                                .frame(width: 8, height: 8)
                        }
                    }
                }
            }
        }
    }
    
    // 标题文本
    private var titleText: some View {
        Text("When do you take this medicine?")
            .font(.system(size: 28, weight: .bold))
            .foregroundColor(textColor)
            .padding(.bottom, 30)
    }
    
    // 频率部分
    private var frequencySection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("frequency")
                .font(.system(size: 17, weight: .medium))
                .foregroundColor(textColor)
                .padding(.leading)
            
            Button(action: {
                // 这里可以添加选择频率的逻辑
            }) {
                HStack {
                    Text("every day")
                        .font(.system(size: 17))
                        .foregroundColor(textColor)
                    
                    Spacer()
                    
                    Text(frequency)
                        .font(.system(size: 17))
                        .foregroundColor(.blue)
                }
                .padding()
                .background(cardBackgroundColor)
                .cornerRadius(10)
            }
            .buttonStyle(PlainButtonStyle())
            .padding(.horizontal)
        }
        .padding(.bottom, 10)
    }
    
    // 提示文本
    private var reminderText: some View {
        Text("If timed, Health will send a notification reminding you to take your medication。")
            .font(.system(size: 15))
            .foregroundColor(textColor.opacity(0.6))
            .padding(.horizontal)
            .padding(.bottom, 20)
    }
    
    // 特定时间部分
    private var scheduledTimesSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Specific time")
                .font(.system(size: 17, weight: .medium))
                .foregroundColor(textColor)
                .padding(.leading)
                .padding(.bottom, 5)
            
            ForEach(0..<scheduledTimes.count, id: \.self) { index in
                scheduledTimeRow(index: index)
            }
            
            // 添加时间按钮
            Button(action: {
                // 添加新时间
                tempTime = Date()
                tempDosage = 1
                selectedTimeIndex = nil
                showTimePicker = true
            }) {
                HStack {
                    Circle()
                        .fill(Color.green)
                        .frame(width: 30, height: 30)
                        .overlay(
                            Image(systemName: "plus")
                                .font(.system(size: 15, weight: .bold))
                                .foregroundColor(.white)
                        )
                    
                    Text("Add time")
                        .font(.system(size: 17))
                        .foregroundColor(.blue)
                    
                    Spacer()
                }
                .padding()
                .background(cardBackgroundColor)
            }
            .buttonStyle(PlainButtonStyle())
        }
        .padding(.horizontal)
    }
    
    // 特定时间行
    private func scheduledTimeRow(index: Int) -> some View {
        HStack {
            Button(action: {
                // 删除时间
                scheduledTimes.remove(at: index)
            }) {
                Circle()
                    .fill(Color.red)
                    .frame(width: 30, height: 30)
                    .overlay(
                        Image(systemName: "minus")
                            .font(.system(size: 15, weight: .bold))
                            .foregroundColor(.white)
                    )
            }
            
            Button(action: {
                // 编辑时间
                selectedTimeIndex = index
                let timeComponents = scheduledTimes[index].0.split(separator: ":")
                let hour = Int(timeComponents[0]) ?? 0
                let minute = Int(timeComponents[1]) ?? 0
                tempTime = Calendar.current.date(bySettingHour: hour, minute: minute, second: 0, of: Date()) ?? Date()
                tempDosage = scheduledTimes[index].1
                showTimePicker = true
            }) {
                Text(scheduledTimes[index].0)
                    .font(.system(size: 17))
                    .foregroundColor(textColor)
                    .padding(.vertical, 10)
                    .padding(.horizontal, 20)
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(8)
            }
            
            Spacer()
            
            Text("\(scheduledTimes[index].1) grain\(medicationType)")
                .font(.system(size: 17))
                .foregroundColor(.blue)
        }
        .padding()
        .background(cardBackgroundColor)
    }
    
    // 下一步按钮
    private var nextButton: some View {
        Button(action: {
            // 下一步操作
            showSelectShapeView = true
        }) {
            Text("Next Step")
                .font(.system(size: 17, weight: .medium))
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 16)
                .background(
                    RoundedRectangle(cornerRadius: 10)
                        .fill(Color.blue)
                )
        }
        .padding(.horizontal)
        .padding(.bottom, 30)
        .sheet(isPresented: $showSelectShapeView) {
            SelectMedicationShapeView(medicationName: "Ggg", specification: "5 milligram")
        }
    }
    
    // 时间选择器弹窗
    private var timePickerView: some View {
        ZStack {
            Color.black.opacity(0.4)
                .edgesIgnoringSafeArea(.all)
                .onTapGesture {
                    showTimePicker = false
                }
            
            VStack(spacing: 0) {
                // 标题栏
                HStack {
                    Button("cance") {
                        showTimePicker = false
                    }
                    .foregroundColor(.blue)
                    
                    Spacer()
                    
                    Text("Select time")
                        .font(.system(size: 17, weight: .semibold))
                    
                    Spacer()
                    
                    Button("done") {
                        let formatter = DateFormatter()
                        formatter.dateFormat = "HH:mm"
                        let timeString = formatter.string(from: tempTime)
                        
                        if let index = selectedTimeIndex {
                            // 更新现有时间
                            scheduledTimes[index] = (timeString, tempDosage)
                        } else {
                            // 添加新时间
                            scheduledTimes.append((timeString, tempDosage))
                        }
                        
                        showTimePicker = false
                    }
                    .foregroundColor(.blue)
                }
                .padding()
                .background(colorScheme == .dark ? Color(red: 0.1, green: 0.1, blue: 0.1) : Color.white)
                
                Divider()
                
                // 时间选择器
                DatePicker("", selection: $tempTime, displayedComponents: .hourAndMinute)
                    .datePickerStyle(WheelDatePickerStyle())
                    .labelsHidden()
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(colorScheme == .dark ? Color(red: 0.1, green: 0.1, blue: 0.1) : Color.white)
                
                Divider()
                
                // 剂量选择
                HStack {
                    Text("dose")
                        .font(.system(size: 17))
                        .foregroundColor(textColor)
                    
                    Spacer()
                    
                    Stepper("\(tempDosage) grain\(medicationType)", value: $tempDosage, in: 1...10)
                        .foregroundColor(textColor)
                }
                .padding()
                .background(colorScheme == .dark ? Color(red: 0.1, green: 0.1, blue: 0.1) : Color.white)
            }
            .cornerRadius(12)
            .padding()
        }
    }
}

struct MedicationScheduleView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            MedicationScheduleView(medicationName: "Ggg", medicationType: "capsule", specification: "5 milligram")
                .preferredColorScheme(.dark)
                .previewDisplayName("Dark Mode")
            
            MedicationScheduleView(medicationName: "Ggg", medicationType: "capsule", specification: "5 milligram")
                .preferredColorScheme(.light)
                .previewDisplayName("Light Mode")
        }
    }
}
