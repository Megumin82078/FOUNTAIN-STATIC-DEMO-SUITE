import SwiftUI

struct WalletCardView: View {
    @Environment(\.colorScheme) var colorScheme
    @Environment(\.dismiss) private var dismiss
    @State private var userProfile = UserProfile.defaultProfile
    @State private var showToast = false
    
    // 卡片颜色
    var cardBackgroundColor: Color {
        Color.black
    }
    
    var textColor: Color {
        .white
    }
    
    var secondaryBackgroundColor: Color {
        colorScheme == .dark ? Color(UIColor.systemGray6) : Color(UIColor.systemBackground)
    }
    
    var body: some View {
        VStack(spacing: 20) {
            // 标题和关闭按钮
            HStack {
                Spacer()
                Text("Fountain Card")
                    .font(.title)
                    .fontWeight(.bold)
                Spacer()
            }
            .padding(.top, 20)
            
            Spacer()
            
            // 卡片视图 - 更紧凑的设计
            VStack(spacing: 0) {
                // 卡片顶部 - 黑色部分
                ZStack {
                    cardBackgroundColor
                    
                    VStack(spacing: 12) {
                        // 放大用户名称
                        Text(userProfile.name.uppercased())
                            .font(.system(size: 24, weight: .bold))
                            .foregroundColor(textColor)
                            .padding(.top, 16)
                        
                        // Fountain ID 替代 points
                        Text(userProfile.fountainID)
                            .font(.system(size: 18))
                            .foregroundColor(textColor.opacity(0.8))
                            .padding(.bottom, 16)
                    }
                    .padding(.horizontal, 20)
                }
                .frame(height: 100) // 减小高度
                
                // 卡片底部（条形码部分）- 白色背景
                ZStack {
                    Color.white
                    
                    VStack(spacing: 8) {
                        // 条形码图像
                        Image(systemName: "barcode")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 50)
                            .foregroundColor(.black)
                        
                        // Fountain ID - 格式化为图片中的样式
                        Text(formatFountainID(userProfile.fountainID))
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.black)
                            .padding(.bottom, 8)
                    }
                    .padding(.vertical, 12)
                }
                .frame(height: 90) // 减小高度
            }
            .cornerRadius(16)
            .shadow(radius: 5)
            .frame(width: 350)
            
            Spacer()
            
            // Add to Apple Wallet 按钮
            Button(action: {
                // 显示成功提示
                withAnimation {
                    showToast = true
                }
                
                // 2秒后隐藏提示并关闭视图
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    withAnimation {
                        showToast = false
                    }
                    // 关闭视图
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        dismiss()
                    }
                }
            }) {
                HStack {
                    Image(systemName: "wallet.pass")
                        .font(.system(size: 18))
                    
                    Text("Add to Apple Wallet")
                        .font(.system(size: 18, weight: .medium))
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 16)
                .background(Color.black)
                .cornerRadius(8)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color.gray.opacity(0.5), lineWidth: 1)
                )
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 30)
        }
        .overlay(
            // 成功提示
            ZStack {
                if showToast {
                    VStack {
                        Text("Successfully added to Apple Wallet")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.white)
                            .padding(.vertical, 12)
                            .padding(.horizontal, 20)
                            .background(Color.black.opacity(0.8))
                            .cornerRadius(8)
                            .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                    .padding(.bottom, 100)
                }
            }
        )
        .background(secondaryBackgroundColor.edgesIgnoringSafeArea(.all))
        .onAppear {
            loadUserProfile()
        }
    }
    
    // 格式化 Fountain ID 为图片中的格式 (1234 2222 3333 4444)
    private func formatFountainID(_ id: String) -> String {
        // 移除所有非字母数字字符
        let cleanID = id.replacingOccurrences(of: "[^A-Za-z0-9]", with: "", options: .regularExpression)
        
        // 如果ID太短，使用默认格式
        if cleanID.count < 12 {
            return "1234 2222 3333 4444"
        }
        
        // 将ID分成4组，每组4个字符
        var formattedID = ""
        var index = cleanID.startIndex
        
        for i in 0..<4 {
            if index < cleanID.endIndex {
                let endIndex = cleanID.index(index, offsetBy: 4, limitedBy: cleanID.endIndex) ?? cleanID.endIndex
                let chunk = cleanID[index..<endIndex]
                formattedID += String(chunk)
                
                if i < 3 && endIndex < cleanID.endIndex {
                    formattedID += " "
                }
                
                index = endIndex
            }
        }
        
        return formattedID
    }
    
    // 加载用户信息
    private func loadUserProfile() {
        if let data = UserDefaults.standard.data(forKey: "userProfile") {
            if let decoded = try? JSONDecoder().decode(UserProfile.self, from: data) {
                userProfile = decoded
            }
        }
    }
}

struct WalletCardView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            WalletCardView()
                .preferredColorScheme(.light)
                .previewDisplayName("Light Mode")
            
            WalletCardView()
                .preferredColorScheme(.dark)
                .previewDisplayName("Dark Mode")
        }
    }
}
