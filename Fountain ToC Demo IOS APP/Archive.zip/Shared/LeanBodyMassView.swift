import SwiftUI

// 瘦体重数据模型
struct LeanBodyMassData: Identifiable, Codable {
    let id = UUID()
    let date: Date
    let leanBodyMass: Double // 单位: lbs

    init(date: Date, leanBodyMass: Double) {
        self.date = date
        self.leanBodyMass = leanBodyMass
    }
}

struct LeanBodyMassView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) var colorScheme

    private let timeRanges = ["D", "W", "M", "6M", "Y"]
    @State private var selectedTimeRangeIndex = 0

    @State private var leanBodyMassEntries: [LeanBodyMassData] = []
    @State private var chartData: [LeanBodyMassData] = []
    @State private var averageLeanBodyMass: Double = 140.0
    @State private var minLeanBodyMass: Double = 120.0
    @State private var maxLeanBodyMass: Double = 160.0

    @State private var showAddDataSheet = false
    @State private var newLeanBodyMass: String = ""
    @State private var selectedDate = Date()
    @State private var selectedTime = Date()

    var body: some View {
        VStack(spacing: 0) {
            navigationBar

            ScrollView {
                VStack(spacing: 0) {
                    timeRangePicker
                        .padding(.horizontal, 16)
                        .padding(.top, 16)

                    leanBodyMassInfoView
                        .padding(.horizontal, 16)
                        .padding(.top, 20)

                    customLeanBodyMassChartView
                        .frame(height: 300)
                        .padding(.top, 16)
                        .padding(.horizontal, 16)
                }
            }
        }
        .background(Color(UIColor.systemBackground).edgesIgnoringSafeArea(.all))
        .navigationBarHidden(true)
        .sheet(isPresented: $showAddDataSheet) {
            AddLeanBodyMassDataView(
                isPresented: $showAddDataSheet,
                date: $selectedDate,
                time: $selectedTime,
                leanBodyMass: $newLeanBodyMass,
                onSave: saveNewLeanBodyMassData
            )
        }
        .onAppear {
            loadLeanBodyMassData()
            updateChartData()
        }
    }

    // MARK: - 组件视图
    private var navigationBar: some View {
        HStack {
            Button(action: { dismiss() }) {
                HStack(spacing: 4) {
                    Image(systemName: "chevron.left")
//                    Text("Summary")
                }
                .foregroundColor(.blue)
                .font(.system(size: 17))
            }

            Spacer()

            Text("Lean Body Mass")
                .font(.system(size: 17, weight: .semibold))
                .foregroundColor(.primary)

            Spacer()

            Button("Add Data") {
                showAddDataSheet = true
            }
            .font(.system(size: 17))
            .foregroundColor(.blue)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color(UIColor.systemBackground))
    }

    private var timeRangePicker: some View {
        HStack(spacing: 0) {
            ForEach(0..<timeRanges.count, id: \.self) { index in
                Button(action: {
                    selectedTimeRangeIndex = index
                    updateChartData()
                }) {
                    Text(timeRanges[index])
                        .font(.system(size: 17))
                        .foregroundColor(selectedTimeRangeIndex == index ? .primary : .gray)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                        .background(selectedTimeRangeIndex == index ? Color(UIColor.systemGray5) : Color.clear)
                }
            }
        }
        .background(Color(UIColor.systemGray6))
        .cornerRadius(8)
    }

    private var leanBodyMassInfoView: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("AVERAGE")
                .font(.system(size: 13))
                .foregroundColor(.gray)

            HStack(alignment: .firstTextBaseline, spacing: 4) {
                Text("\(String(format: "%.1f", averageLeanBodyMass))")
                    .font(.system(size: 48, weight: .regular))
                    .foregroundColor(.primary)

                Text("lbs")
                    .font(.system(size: 22))
                    .foregroundColor(.gray)
                    .padding(.leading, 2)
            }

            Text("Today")
                .font(.system(size: 17))
                .foregroundColor(.gray)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var customLeanBodyMassChartView: some View {
        VStack(spacing: 0) {
            // 图表区域
            GeometryReader { geometry in
                ZStack {
                    // 背景网格
                    VStack(spacing: 0) {
                        ForEach(0..<4) { _ in
                            Divider().background(Color.gray.opacity(0.2))
                            Spacer()
                        }
                        Divider().background(Color.gray.opacity(0.2))
                    }
                    
                    HStack(spacing: 0) {
                        ForEach(0..<5) { _ in
                            Divider().background(Color.gray.opacity(0.2))
                            Spacer()
                        }
                        Divider().background(Color.gray.opacity(0.2))
                    }
                    
                    // 折线图
                    if chartData.count > 1 {
                        Path { path in
                            guard let firstPoint = chartData.first else { return }
                            
                            let xPosition = getXPosition(for: firstPoint.date, width: geometry.size.width)
                            let yPosition = getYPosition(for: firstPoint.leanBodyMass, height: geometry.size.height)
                            
                            path.move(to: CGPoint(x: xPosition, y: yPosition))
                            
                            for item in chartData.dropFirst() {
                                let xPos = getXPosition(for: item.date, width: geometry.size.width)
                                let yPos = getYPosition(for: item.leanBodyMass, height: geometry.size.height)
                                path.addLine(to: CGPoint(x: xPos, y: yPos))
                            }
                        }
                        .stroke(Color.purple, style: StrokeStyle(lineWidth: 2.5, lineCap: .round, lineJoin: .round))
                        .shadow(color: Color.purple.opacity(0.3), radius: 3, x: 0, y: 2)
                        
                        // 渐变填充区域
                        Path { path in
                            guard let firstPoint = chartData.first else { return }
                            
                            let xPosition = getXPosition(for: firstPoint.date, width: geometry.size.width)
                            let yPosition = getYPosition(for: firstPoint.leanBodyMass, height: geometry.size.height)
                            
                            path.move(to: CGPoint(x: xPosition, y: geometry.size.height))
                            path.addLine(to: CGPoint(x: xPosition, y: yPosition))
                            
                            for item in chartData.dropFirst() {
                                let xPos = getXPosition(for: item.date, width: geometry.size.width)
                                let yPos = getYPosition(for: item.leanBodyMass, height: geometry.size.height)
                                path.addLine(to: CGPoint(x: xPos, y: yPos))
                            }
                            
                            if let lastPoint = chartData.last {
                                let xPos = getXPosition(for: lastPoint.date, width: geometry.size.width)
                                path.addLine(to: CGPoint(x: xPos, y: geometry.size.height))
                            }
                            
                            path.closeSubpath()
                        }
                        .fill(LinearGradient(
                            gradient: Gradient(colors: [Color.purple.opacity(0.3), Color.purple.opacity(0.05)]),
                            startPoint: .top,
                            endPoint: .bottom
                        ))
                    }
                    
                    // 数据点
                    ForEach(chartData) { item in
                        let xPosition = getXPosition(for: item.date, width: geometry.size.width)
                        let yPosition = getYPosition(for: item.leanBodyMass, height: geometry.size.height)
                        
                        ZStack {
                            // 外环
                            Circle()
                                .stroke(Color.purple, lineWidth: 2)
                                .frame(width: 12, height: 12)
                            
                            // 内圆点
                            Circle()
                                .fill(Color(UIColor.systemBackground))
                                .frame(width: 6, height: 6)
                        }
                        .shadow(color: Color.purple.opacity(0.3), radius: 2, x: 0, y: 1)
                        .position(x: xPosition, y: yPosition)
                    }
                }
            }
            
            // X轴标签
            HStack {
                Text("12 AM")
                Spacer()
                Text("6")
                Spacer()
                Text("12 PM")
                Spacer()
                Text("6")
                Spacer()
                Text("")
            }
            .font(.system(size: 12))
            .foregroundColor(.gray)
            .padding(.top, 4)
            
            // Y轴标签
            HStack(alignment: .top) {
                VStack(alignment: .trailing, spacing: 0) {
                    Text("\(Int(maxLeanBodyMass)) lbs")
                    Spacer()
                    Text("\(Int(maxLeanBodyMass - (maxLeanBodyMass - minLeanBodyMass) / 3)) lbs")
                    Spacer()
                    Text("\(Int(maxLeanBodyMass - 2 * (maxLeanBodyMass - minLeanBodyMass) / 3)) lbs")
                    Spacer()
                    Text("\(Int(minLeanBodyMass)) lbs")
                }
                .font(.system(size: 12))
                .foregroundColor(.gray)
                
                Spacer()
            }
            .padding(.leading, -8)
            .padding(.top, -290)
        }
    }
    
    // MARK: - 辅助方法
    
    // 获取X坐标位置
    private func getXPosition(for date: Date, width: CGFloat) -> CGFloat {
        let dateRange = getDateRange()
        let totalSeconds = dateRange.upperBound.timeIntervalSince(dateRange.lowerBound)
        let seconds = date.timeIntervalSince(dateRange.lowerBound)
        
        let proportion = totalSeconds > 0 ? seconds / totalSeconds : 0
        return proportion * width
    }
    
    // 获取Y坐标位置
    private func getYPosition(for leanBodyMass: Double, height: CGFloat) -> CGFloat {
        let range = maxLeanBodyMass - minLeanBodyMass
        let proportion = range > 0 ? (maxLeanBodyMass - leanBodyMass) / range : 0
        return proportion * height
    }
    
    // 获取日期范围
    private func getDateRange() -> ClosedRange<Date> {
        let calendar = Calendar.current
        let now = Date()
        let endDate = calendar.startOfDay(for: now)
        var startDate: Date
        
        switch selectedTimeRangeIndex {
        case 0: startDate = calendar.date(byAdding: .day, value: -1, to: endDate)!
        case 1: startDate = calendar.date(byAdding: .day, value: -7, to: endDate)!
        case 2: startDate = calendar.date(byAdding: .month, value: -1, to: endDate)!
        case 3: startDate = calendar.date(byAdding: .month, value: -6, to: endDate)!
        case 4: startDate = calendar.date(byAdding: .year, value: -1, to: endDate)!
        default: startDate = calendar.date(byAdding: .day, value: -1, to: endDate)!
        }
        
        return startDate...calendar.date(byAdding: .day, value: 1, to: endDate)!
    }

    // MARK: - 数据操作
    private func loadLeanBodyMassData() {
        if let data = UserDefaults.standard.data(forKey: "savedLeanBodyMassData"),
           let decoded = try? JSONDecoder().decode([LeanBodyMassData].self, from: data) {
            leanBodyMassEntries = decoded
            updateAverageLeanBodyMass()
        } else {
            addSampleData()
        }
    }

    private func addSampleData() {
        let calendar = Calendar.current
        let now = Date()

        if let twoDaysAgo = calendar.date(byAdding: .day, value: -2, to: now) {
            leanBodyMassEntries.append(LeanBodyMassData(date: twoDaysAgo, leanBodyMass: 142.5))
        }

        if let oneDayAgo = calendar.date(byAdding: .day, value: -1, to: now) {
            leanBodyMassEntries.append(LeanBodyMassData(date: oneDayAgo, leanBodyMass: 141.0))
        }

        leanBodyMassEntries.append(LeanBodyMassData(date: now, leanBodyMass: 140.0))

        saveLeanBodyMassData()
    }

    private func saveLeanBodyMassData() {
        if let encoded = try? JSONEncoder().encode(leanBodyMassEntries) {
            UserDefaults.standard.set(encoded, forKey: "savedLeanBodyMassData")
        }
    }

    private func saveNewLeanBodyMassData() {
        guard let leanBodyMassValue = Double(newLeanBodyMass), leanBodyMassValue > 0 else { return }

        let newEntry = LeanBodyMassData(date: selectedDate, leanBodyMass: leanBodyMassValue)
        leanBodyMassEntries.append(newEntry)
        saveLeanBodyMassData()
        updateAverageLeanBodyMass()
        updateChartData()

        newLeanBodyMass = ""
    }

    private func updateAverageLeanBodyMass() {
        if !leanBodyMassEntries.isEmpty {
            let sum = leanBodyMassEntries.reduce(0.0) { $0 + $1.leanBodyMass }
            averageLeanBodyMass = sum / Double(leanBodyMassEntries.count)
        }
    }

    private func updateChartData() {
        let dateRange = getDateRange()
        chartData = leanBodyMassEntries.filter { dateRange.contains($0.date) }
        
        // 根据时间范围排序
        chartData.sort { $0.date < $1.date }
        
        // 更新图表的最大最小值
        if let minValue = chartData.map({ $0.leanBodyMass }).min(),
           let maxValue = chartData.map({ $0.leanBodyMass }).max() {
            // 添加一些边距使图表更美观
            minLeanBodyMass = max(0, minValue - 5)
            maxLeanBodyMass = maxValue + 5
        }
    }
}

// MARK: - 添加 Lean Body Mass 数据视图
struct AddLeanBodyMassDataView: View {
    @Binding var isPresented: Bool
    @Binding var date: Date
    @Binding var time: Date
    @Binding var leanBodyMass: String
    var onSave: () -> Void

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Date & Time")) {
                    DatePicker("Date", selection: $date, displayedComponents: .date)
                    DatePicker("Time", selection: $time, displayedComponents: .hourAndMinute)
                }

                Section(header: Text("Lean Body Mass")) {
                    HStack {
                        TextField("lbs", text: $leanBodyMass)
                            .keyboardType(.decimalPad)
                        Text("lbs")
                            .foregroundColor(.gray)
                    }
                }
            }
            .navigationBarItems(
                leading: Button("Cancel") { isPresented = false },
                trailing: Button("Save") {
                    onSave()
                    isPresented = false
                }
                .disabled(leanBodyMass.isEmpty || Double(leanBodyMass) == nil)
            )
        }
    }
}
