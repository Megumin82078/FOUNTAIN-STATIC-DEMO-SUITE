import SwiftUI

// BMI 数据模型
struct BMIData: Identifiable, Codable {
    let id = UUID()
    let date: Date
    let bmi: Double // 单位: BMI

    init(date: Date, bmi: Double) {
        self.date = date
        self.bmi = bmi
    }
}

struct BMIView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) var colorScheme

    private let timeRanges = ["D", "W", "M", "6M", "Y"]
    @State private var selectedTimeRangeIndex = 0

    @State private var bmiEntries: [BMIData] = []
    @State private var chartData: [BMIData] = []
    @State private var averageBMI: Double = 22.0
    @State private var minBMI: Double = 18.0
    @State private var maxBMI: Double = 30.0

    @State private var showAddDataSheet = false
    @State private var newBMI: String = ""
    @State private var selectedDate = Date()
    @State private var selectedTime = Date()

    var body: some View {
        VStack(spacing: 0) {
            navigationBar

            ScrollView {
                VStack(spacing: 0) {
                    timeRangePicker
                        .padding(.horizontal, 16)
                        .padding(.top, 16)

                    bmiInfoView
                        .padding(.horizontal, 16)
                        .padding(.top, 20)

                    customBMIChartView
                        .frame(height: 300)
                        .padding(.top, 16)
                        .padding(.horizontal, 16)
                }
            }
        }
        .background(Color(UIColor.systemBackground).edgesIgnoringSafeArea(.all))
        .navigationBarHidden(true)
        .sheet(isPresented: $showAddDataSheet) {
            AddBMIDataView(
                isPresented: $showAddDataSheet,
                date: $selectedDate,
                time: $selectedTime,
                bmi: $newBMI,
                onSave: saveNewBMIData
            )
        }
        .onAppear {
            loadBMIData()
            updateChartData()
        }
    }

    // MARK: - 组件视图
    private var navigationBar: some View {
        HStack {
            Button(action: { dismiss() }) {
                HStack(spacing: 4) {
                    Image(systemName: "chevron.left")
//                    Text("Summary")
                }
                .foregroundColor(.blue)
                .font(.system(size: 17))
            }

            Spacer()

            Text("BMI")
                .font(.system(size: 17, weight: .semibold))
                .foregroundColor(.primary)

            Spacer()

            Button("Add Data") {
                showAddDataSheet = true
            }
            .font(.system(size: 17))
            .foregroundColor(.blue)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color(UIColor.systemBackground))
    }

    private var timeRangePicker: some View {
        HStack(spacing: 0) {
            ForEach(0..<timeRanges.count, id: \.self) { index in
                Button(action: {
                    selectedTimeRangeIndex = index
                    updateChartData()
                }) {
                    Text(timeRanges[index])
                        .font(.system(size: 17))
                        .foregroundColor(selectedTimeRangeIndex == index ? .primary : .gray)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                        .background(selectedTimeRangeIndex == index ? Color(UIColor.systemGray5) : Color.clear)
                }
            }
        }
        .background(Color(UIColor.systemGray6))
        .cornerRadius(8)
    }

    private var bmiInfoView: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("AVERAGE")
                .font(.system(size: 13))
                .foregroundColor(.gray)

            HStack(alignment: .firstTextBaseline, spacing: 4) {
                Text("\(String(format: "%.1f", averageBMI))")
                    .font(.system(size: 48, weight: .regular))
                    .foregroundColor(.primary)

                Text("BMI")
                    .font(.system(size: 22))
                    .foregroundColor(.gray)
                    .padding(.leading, 2)
            }

            Text("Today")
                .font(.system(size: 17))
                .foregroundColor(.gray)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var customBMIChartView: some View {
        VStack(spacing: 0) {
            // 图表区域
            GeometryReader { geometry in
                ZStack {
                    // 背景网格
                    VStack(spacing: 0) {
                        ForEach(0..<4) { _ in
                            Divider().background(Color.gray.opacity(0.2))
                            Spacer()
                        }
                        Divider().background(Color.gray.opacity(0.2))
                    }
                    
                    HStack(spacing: 0) {
                        ForEach(0..<5) { _ in
                            Divider().background(Color.gray.opacity(0.2))
                            Spacer()
                        }
                        Divider().background(Color.gray.opacity(0.2))
                    }
                    
                    // 折线图
                    if chartData.count > 1 {
                        Path { path in
                            guard let firstPoint = chartData.first else { return }
                            
                            let xPosition = getXPosition(for: firstPoint.date, width: geometry.size.width)
                            let yPosition = getYPosition(for: firstPoint.bmi, height: geometry.size.height)
                            
                            path.move(to: CGPoint(x: xPosition, y: yPosition))
                            
                            for item in chartData.dropFirst() {
                                let xPos = getXPosition(for: item.date, width: geometry.size.width)
                                let yPos = getYPosition(for: item.bmi, height: geometry.size.height)
                                path.addLine(to: CGPoint(x: xPos, y: yPos))
                            }
                        }
                        .stroke(Color.green, style: StrokeStyle(lineWidth: 2.5, lineCap: .round, lineJoin: .round))
                        .shadow(color: Color.green.opacity(0.3), radius: 3, x: 0, y: 2)
                        
                        // 渐变填充区域
                        Path { path in
                            guard let firstPoint = chartData.first else { return }
                            
                            let xPosition = getXPosition(for: firstPoint.date, width: geometry.size.width)
                            let yPosition = getYPosition(for: firstPoint.bmi, height: geometry.size.height)
                            
                            path.move(to: CGPoint(x: xPosition, y: geometry.size.height))
                            path.addLine(to: CGPoint(x: xPosition, y: yPosition))
                            
                            for item in chartData.dropFirst() {
                                let xPos = getXPosition(for: item.date, width: geometry.size.width)
                                let yPos = getYPosition(for: item.bmi, height: geometry.size.height)
                                path.addLine(to: CGPoint(x: xPos, y: yPos))
                            }
                            
                            if let lastPoint = chartData.last {
                                let xPos = getXPosition(for: lastPoint.date, width: geometry.size.width)
                                path.addLine(to: CGPoint(x: xPos, y: geometry.size.height))
                            }
                            
                            path.closeSubpath()
                        }
                        .fill(LinearGradient(
                            gradient: Gradient(colors: [Color.green.opacity(0.3), Color.green.opacity(0.05)]),
                            startPoint: .top,
                            endPoint: .bottom
                        ))
                    }
                    
                    // 数据点
                    ForEach(chartData) { item in
                        let xPosition = getXPosition(for: item.date, width: geometry.size.width)
                        let yPosition = getYPosition(for: item.bmi, height: geometry.size.height)
                        
                        ZStack {
                            // 外环
                            Circle()
                                .stroke(Color.green, lineWidth: 2)
                                .frame(width: 12, height: 12)
                            
                            // 内圆点
                            Circle()
                                .fill(Color(UIColor.systemBackground))
                                .frame(width: 6, height: 6)
                        }
                        .shadow(color: Color.green.opacity(0.3), radius: 2, x: 0, y: 1)
                        .position(x: xPosition, y: yPosition)
                    }
                }
            }
            
            // X轴标签
            HStack {
                Text("12 AM")
                Spacer()
                Text("6")
                Spacer()
                Text("12 PM")
                Spacer()
                Text("6")
                Spacer()
                Text("")
            }
            .font(.system(size: 12))
            .foregroundColor(.gray)
            .padding(.top, 4)
            
            // Y轴标签
            HStack(alignment: .top) {
                VStack(alignment: .trailing, spacing: 0) {
                    Text("\(Int(maxBMI))")
                    Spacer()
                    Text("\(Int(maxBMI - (maxBMI - minBMI) / 3))")
                    Spacer()
                    Text("\(Int(maxBMI - 2 * (maxBMI - minBMI) / 3))")
                    Spacer()
                    Text("\(Int(minBMI))")
                }
                .font(.system(size: 12))
                .foregroundColor(.gray)
                
                Spacer()
            }
            .padding(.leading, -8)
            .padding(.top, -290)
        }
    }
    
    // MARK: - 辅助方法
    
    // 获取X坐标位置
    private func getXPosition(for date: Date, width: CGFloat) -> CGFloat {
        let dateRange = getDateRange()
        let totalSeconds = dateRange.upperBound.timeIntervalSince(dateRange.lowerBound)
        let seconds = date.timeIntervalSince(dateRange.lowerBound)
        
        let proportion = totalSeconds > 0 ? seconds / totalSeconds : 0
        return proportion * width
    }
    
    // 获取Y坐标位置
    private func getYPosition(for bmi: Double, height: CGFloat) -> CGFloat {
        let range = maxBMI - minBMI
        let proportion = range > 0 ? (maxBMI - bmi) / range : 0
        return proportion * height
    }
    
    // 获取日期范围
    private func getDateRange() -> ClosedRange<Date> {
        let calendar = Calendar.current
        let now = Date()
        let endDate = calendar.startOfDay(for: now)
        var startDate: Date
        
        switch selectedTimeRangeIndex {
        case 0: startDate = calendar.date(byAdding: .day, value: -1, to: endDate)!
        case 1: startDate = calendar.date(byAdding: .day, value: -7, to: endDate)!
        case 2: startDate = calendar.date(byAdding: .month, value: -1, to: endDate)!
        case 3: startDate = calendar.date(byAdding: .month, value: -6, to: endDate)!
        case 4: startDate = calendar.date(byAdding: .year, value: -1, to: endDate)!
        default: startDate = calendar.date(byAdding: .day, value: -1, to: endDate)!
        }
        
        return startDate...calendar.date(byAdding: .day, value: 1, to: endDate)!
    }

    // MARK: - 数据操作
    private func loadBMIData() {
        if let data = UserDefaults.standard.data(forKey: "savedBMIData"),
           let decoded = try? JSONDecoder().decode([BMIData].self, from: data) {
            bmiEntries = decoded
            updateAverageBMI()
        } else {
            addSampleData()
        }
    }

    private func addSampleData() {
        let calendar = Calendar.current
        let now = Date()

        if let twoDaysAgo = calendar.date(byAdding: .day, value: -2, to: now) {
            bmiEntries.append(BMIData(date: twoDaysAgo, bmi: 23.1))
        }

        if let oneDayAgo = calendar.date(byAdding: .day, value: -1, to: now) {
            bmiEntries.append(BMIData(date: oneDayAgo, bmi: 22.8))
        }

        bmiEntries.append(BMIData(date: now, bmi: 22.0))

        saveBMIData()
    }

    private func saveBMIData() {
        if let encoded = try? JSONEncoder().encode(bmiEntries) {
            UserDefaults.standard.set(encoded, forKey: "savedBMIData")
        }
    }

    private func saveNewBMIData() {
        guard let bmiValue = Double(newBMI), bmiValue > 0 else { return }

        let newEntry = BMIData(date: selectedDate, bmi: bmiValue)
        bmiEntries.append(newEntry)
        saveBMIData()
        updateAverageBMI()
        updateChartData()

        newBMI = ""
    }

    private func updateAverageBMI() {
        if !bmiEntries.isEmpty {
            let sum = bmiEntries.reduce(0.0) { $0 + $1.bmi }
            averageBMI = sum / Double(bmiEntries.count)
        }
    }

    private func updateChartData() {
        let dateRange = getDateRange()
        chartData = bmiEntries.filter { dateRange.contains($0.date) }
        
        // 根据时间范围排序
        chartData.sort { $0.date < $1.date }
        
        // 更新图表的最大最小值
        if let minValue = chartData.map({ $0.bmi }).min(),
           let maxValue = chartData.map({ $0.bmi }).max() {
            // 添加一些边距使图表更美观
            minBMI = max(0, minValue - 2)
            maxBMI = maxValue + 2
        }
    }
}

// MARK: - 添加 BMI 数据视图
struct AddBMIDataView: View {
    @Binding var isPresented: Bool
    @Binding var date: Date
    @Binding var time: Date
    @Binding var bmi: String
    var onSave: () -> Void

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Date & Time")) {
                    DatePicker("Date", selection: $date, displayedComponents: .date)
                    DatePicker("Time", selection: $time, displayedComponents: .hourAndMinute)
                }

                Section(header: Text("BMI")) {
                    HStack {
                        TextField("BMI", text: $bmi)
                            .keyboardType(.decimalPad)
                        Text("BMI")
                            .foregroundColor(.gray)
                    }
                }
            }
            .navigationBarItems(
                leading: Button("Cancel") { isPresented = false },
                trailing: Button("Save") {
                    onSave()
                    isPresented = false
                }
                .disabled(bmi.isEmpty || Double(bmi) == nil)
            )
        }
    }
}
