import SwiftUI

struct MobilityArticleView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    // 背景图片 + 渐变
                    ZStack {
                        Image("image")
                            .resizable()
                            .scaledToFit()

                        LinearGradient(
                            gradient: Gradient(colors: [
                                Color.purple.opacity(0.3),
                                Color.blue.opacity(0.3)
                            ]),
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    }
                    .frame(height: 250)
                    .clipShape(RoundedRectangle(cornerRadius: 20)) // 可选，增加圆角更美观
                    .padding(.top) // 确保不会影响 NavigationBar

                    // 文章标题
                    Text("Exercises That May Improve Walking Steadiness")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                        .padding(.horizontal)

                    // 副标题
                    Text("Why Walking Steadiness Goes Down")
                        .font(.headline)
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                        .padding(.horizontal)

                    // 文章内容
                    Text("""
                    When walking steadiness drops quickly, it's usually for a specific reason, like an injury. But when it declines over months or years, there could be many reasons and the exact cause may be more difficult to uncover.

                    Sometimes it may simply be due to the effects of aging on our strength and ability to move. Age can also have an impact on the system in your inner ears that control balance. It may even be due to an underlying condition, medication, vision loss, or other factors. A doctor may be able to help if you can’t identify an obvious cause.
                    """)
                    .foregroundColor(.secondary)
                    .padding(.horizontal)
                }
            }
            .background(colorScheme == .dark ? Color.black : Color.white) // 适配深色和浅色模式
            .navigationBarItems(trailing:
                Button("Done") {
                    presentationMode.wrappedValue.dismiss()
                }
                .foregroundColor(.blue)
            )
        }
    }
}

struct MobilityArticleView_Previews: PreviewProvider {
    static var previews: some View {
        MobilityArticleView()
            .preferredColorScheme(.light)
        
        MobilityArticleView()
            .preferredColorScheme(.dark)
    }
}
