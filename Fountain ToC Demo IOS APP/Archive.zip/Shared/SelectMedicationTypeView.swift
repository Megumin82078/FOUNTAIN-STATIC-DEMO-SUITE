import SwiftUI

struct SelectMedicationTypeView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) private var colorScheme
    
    let medicationName: String
    
    // 常见形式
    let commonTypes = ["胶囊", "药片", "液体", "外用"]
    
    // 更多形式
    let moreTypes = ["乳液", "乳霜", "粉剂", "喷雾", "贴片", "注射剂", "滴眼液", "吸入剂"]
    
    @State private var selectedType: String?
    
    // 根据当前主题获取背景色
    var backgroundColor: Color {
        colorScheme == .dark ? Color.black : Color.white
    }
    
    // 根据当前主题获取文本颜色
    var textColor: Color {
        colorScheme == .dark ? Color.white : Color.black
    }
    
    // 根据当前主题获取卡片背景色
    var cardBackgroundColor: Color {
        colorScheme == .dark ? Color(red: 0.17, green: 0.17, blue: 0.18) : Color(UIColor.systemGray6)
    }
    
    // 根据当前主题获取分割线颜色
    var dividerColor: Color {
        colorScheme == .dark ? Color.gray.opacity(0.3) : Color.gray.opacity(0.2)
    }
    
    var body: some View {
        ZStack {
            // 背景色
            backgroundColor.edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 0) {
                // 导航栏
                HStack {
                    Button("返回") {
                        presentationMode.wrappedValue.dismiss()
                    }
                    .foregroundColor(Color.blue)
                    .font(.system(size: 17))
                    
                    Spacer()
                    
                    Text("选择药品类型")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundColor(textColor)
                    
                    Spacer()
                    
                    // 占位，保持标题居中
                    Text("返回")
                        .foregroundColor(.clear)
                        .font(.system(size: 17))
                }
                .padding(.horizontal)
                .padding(.top, 20)
                .padding(.bottom, 20)
                
                ScrollView {
                    VStack(spacing: 30) {
                        // 药品图标
                        medicationTypeIcon
                            .padding(.bottom, 10)
                        
                        // 选择药品类型标题
                        Text("选取药品类型")
                            .font(.system(size: 28, weight: .bold))
                            .foregroundColor(textColor)
                            .padding(.bottom, 30)
                        
                        // 常见形式
                        VStack(alignment: .leading, spacing: 15) {
                            Text("常见形式")
                                .font(.system(size: 17, weight: .semibold))
                                .foregroundColor(textColor)
                                .padding(.leading)
                            
                            VStack(spacing: 0) {
                                ForEach(commonTypes, id: \.self) { type in
                                    Button(action: {
                                        selectedType = type
                                    }) {
                                        HStack {
                                            Text(type)
                                                .font(.system(size: 17))
                                                .foregroundColor(textColor)
                                            
                                            Spacer()
                                            
                                            if selectedType == type {
                                                Image(systemName: "checkmark")
                                                    .foregroundColor(.blue)
                                                    .font(.system(size: 17))
                                            }
                                        }
                                        .padding()
                                        .background(cardBackgroundColor)
                                    }
                                    
                                    if type != commonTypes.last {
                                        Divider()
                                            .background(dividerColor)
                                            .padding(.leading)
                                    }
                                }
                            }
                            .background(cardBackgroundColor)
                            .cornerRadius(12)
                            .padding(.horizontal)
                        }
                        
                        // 更多形式
                        VStack(alignment: .leading, spacing: 15) {
                            Text("更多形式")
                                .font(.system(size: 17, weight: .semibold))
                                .foregroundColor(textColor)
                                .padding(.leading)
                            
                            VStack(spacing: 0) {
                                ForEach(moreTypes, id: \.self) { type in
                                    Button(action: {
                                        selectedType = type
                                    }) {
                                        HStack {
                                            Text(type)
                                                .font(.system(size: 17))
                                                .foregroundColor(textColor)
                                            
                                            Spacer()
                                            
                                            if selectedType == type {
                                                Image(systemName: "checkmark")
                                                    .foregroundColor(.blue)
                                                    .font(.system(size: 17))
                                            }
                                        }
                                        .padding()
                                        .background(cardBackgroundColor)
                                    }
                                    
                                    if type != moreTypes.last {
                                        Divider()
                                            .background(dividerColor)
                                            .padding(.leading)
                                    }
                                }
                            }
                            .background(cardBackgroundColor)
                            .cornerRadius(12)
                            .padding(.horizontal)
                        }
                        
                        Spacer(minLength: 50)
                    }
                    .padding(.bottom, 30)
                }
                
                // 下一步按钮
                Button(action: {
                    // 下一步操作
                }) {
                    Text("下一步")
                        .font(.system(size: 17, weight: .medium))
                        .foregroundColor(selectedType == nil ? Color.gray : Color.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(
                            RoundedRectangle(cornerRadius: 10)
                                .fill(selectedType == nil ? (colorScheme == .dark ? Color(red: 0.17, green: 0.17, blue: 0.18) : Color(UIColor.systemGray5)) : Color.blue)
                        )
                        .padding(.horizontal)
                }
                .disabled(selectedType == nil)
                .padding(.bottom, 40)
            }
        }
        .navigationBarHidden(true)
    }
    
    // 药品类型图标
    var medicationTypeIcon: some View {
        ZStack {
            // 蓝色胶囊轮廓
            Capsule()
                .stroke(Color.blue, lineWidth: 2)
                .frame(width: 60, height: 30)
                .rotationEffect(.degrees(-30))
                .offset(x: -30, y: 0)
            
            // 虚线
            Group {
                Rectangle()
                    .stroke(Color.blue, style: StrokeStyle(lineWidth: 1, dash: [3]))
                    .frame(width: 20, height: 1)
                    .offset(x: -60, y: 0)
                
                Rectangle()
                    .stroke(Color.blue, style: StrokeStyle(lineWidth: 1, dash: [3]))
                    .frame(width: 20, height: 1)
                    .offset(x: 0, y: 0)
            }
            
            // 蓝色六边形轮廓
            ZStack {
                Circle()
                    .stroke(Color.blue, lineWidth: 2)
                    .frame(width: 40, height: 40)
                
                // 六边形内部线条
                ForEach(0..<3) { i in
                    Rectangle()
                        .stroke(Color.blue, lineWidth: 1)
                        .frame(width: 30, height: 1)
                        .rotationEffect(.degrees(Double(i) * 60))
                }
            }
            .offset(x: 20, y: -10)
            
            // 粉色圆形轮廓
            Circle()
                .stroke(Color.pink, lineWidth: 2)
                .frame(width: 50, height: 50)
                .offset(x: 10, y: 30)
            
            // 粉色圆形内部十字线
            Group {
                Rectangle()
                    .fill(Color.pink)
                    .frame(width: 20, height: 1)
                    .offset(x: 10, y: 30)
                
                Rectangle()
                    .fill(Color.pink)
                    .frame(width: 1, height: 20)
                    .offset(x: 10, y: 30)
            }
            
            // 小黄色圆形
            Circle()
                .fill(Color.yellow)
                .frame(width: 15, height: 15)
                .offset(x: 0, y: -40)
            
            // 虚线尺寸标记
            Group {
                Rectangle()
                    .stroke(Color.blue, style: StrokeStyle(lineWidth: 1, dash: [3]))
                    .frame(width: 1, height: 20)
                    .offset(x: -30, y: 20)
                
                Rectangle()
                    .stroke(Color.blue, style: StrokeStyle(lineWidth: 1, dash: [3]))
                    .frame(width: 1, height: 20)
                    .offset(x: -30, y: -20)
                
                Rectangle()
                    .stroke(Color.pink, style: StrokeStyle(lineWidth: 1, dash: [3]))
                    .frame(width: 1, height: 20)
                    .offset(x: 40, y: 30)
                
                Rectangle()
                    .stroke(Color.pink, style: StrokeStyle(lineWidth: 1, dash: [3]))
                    .frame(width: 1, height: 20)
                    .offset(x: -20, y: 30)
            }
        }
        .frame(width: 120, height: 120)
    }
}

struct SelectMedicationTypeView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            SelectMedicationTypeView(medicationName: "阿司匹林")
                .preferredColorScheme(.dark)
                .previewDisplayName("Dark Mode")
            
            SelectMedicationTypeView(medicationName: "阿司匹林")
                .preferredColorScheme(.light)
                .previewDisplayName("Light Mode")
        }
    }
}