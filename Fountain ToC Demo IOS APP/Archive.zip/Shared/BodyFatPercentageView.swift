import SwiftUI

// 体脂数据模型
struct BodyFatData: Identifiable, Codable {
    let id = UUID()
    let date: Date
    let bodyFatPercentage: Double // 单位: %

    init(date: Date, bodyFatPercentage: Double) {
        self.date = date
        self.bodyFatPercentage = bodyFatPercentage
    }
}

struct BodyFatPercentageView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) var colorScheme

    private let timeRanges = ["D", "W", "M", "6M", "Y"]
    @State private var selectedTimeRangeIndex = 0

    @State private var bodyFatEntries: [BodyFatData] = []
    @State private var chartData: [BodyFatData] = []
    @State private var averageBodyFat: Double = 22.5
    @State private var minBodyFat: Double = 15.0
    @State private var maxBodyFat: Double = 30.0

    @State private var showAddDataSheet = false
    @State private var newBodyFat: String = ""
    @State private var selectedDate = Date()
    @State private var selectedTime = Date()

    var body: some View {
        VStack(spacing: 0) {
            navigationBar

            ScrollView {
                VStack(spacing: 0) {
                    timeRangePicker
                        .padding(.horizontal, 16)
                        .padding(.top, 16)

                    bodyFatInfoView
                        .padding(.horizontal, 16)
                        .padding(.top, 20)

                    customBodyFatChartView
                        .frame(height: 300)
                        .padding(.top, 16)
                        .padding(.horizontal, 16)
                }
            }
        }
        .background(Color(UIColor.systemBackground).edgesIgnoringSafeArea(.all))
        .navigationBarHidden(true)
        .sheet(isPresented: $showAddDataSheet) {
            AddBodyFatDataView(
                isPresented: $showAddDataSheet,
                date: $selectedDate,
                time: $selectedTime,
                bodyFatPercentage: $newBodyFat,
                onSave: saveNewBodyFatData
            )
        }
        .onAppear {
            loadBodyFatData()
            updateChartData()
        }
    }

    // MARK: - 组件视图
    private var navigationBar: some View {
        HStack {
            Button(action: { dismiss() }) {
                HStack(spacing: 4) {
                    Image(systemName: "chevron.left")
//                    Text("Summary")
                }
                .foregroundColor(.blue)
                .font(.system(size: 17))
            }

            Spacer()

            Text("Body Fat Percentage")
                .font(.system(size: 17, weight: .semibold))
                .foregroundColor(.primary)

            Spacer()

            Button("Add Data") {
                showAddDataSheet = true
            }
            .font(.system(size: 17))
            .foregroundColor(.blue)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color(UIColor.systemBackground))
    }

    private var timeRangePicker: some View {
        HStack(spacing: 0) {
            ForEach(0..<timeRanges.count, id: \.self) { index in
                Button(action: {
                    selectedTimeRangeIndex = index
                    updateChartData()
                }) {
                    Text(timeRanges[index])
                        .font(.system(size: 17))
                        .foregroundColor(selectedTimeRangeIndex == index ? .primary : .gray)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                        .background(selectedTimeRangeIndex == index ? Color(UIColor.systemGray5) : Color.clear)
                }
            }
        }
        .background(Color(UIColor.systemGray6))
        .cornerRadius(8)
    }

    private var bodyFatInfoView: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("AVERAGE")
                .font(.system(size: 13))
                .foregroundColor(.gray)

            HStack(alignment: .firstTextBaseline, spacing: 4) {
                Text("\(String(format: "%.1f", averageBodyFat))")
                    .font(.system(size: 48, weight: .regular))
                    .foregroundColor(.primary)

                Text("%")
                    .font(.system(size: 22))
                    .foregroundColor(.gray)
                    .padding(.leading, 2)
            }

            Text("Today")
                .font(.system(size: 17))
                .foregroundColor(.gray)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var customBodyFatChartView: some View {
        VStack(spacing: 0) {
            // 图表区域
            GeometryReader { geometry in
                ZStack {
                    // 背景网格
                    VStack(spacing: 0) {
                        ForEach(0..<4) { _ in
                            Divider().background(Color.gray.opacity(0.2))
                            Spacer()
                        }
                        Divider().background(Color.gray.opacity(0.2))
                    }
                    
                    HStack(spacing: 0) {
                        ForEach(0..<5) { _ in
                            Divider().background(Color.gray.opacity(0.2))
                            Spacer()
                        }
                        Divider().background(Color.gray.opacity(0.2))
                    }
                    
                    // 折线图
                    if chartData.count > 1 {
                        Path { path in
                            guard let firstPoint = chartData.first else { return }
                            
                            let xPosition = getXPosition(for: firstPoint.date, width: geometry.size.width)
                            let yPosition = getYPosition(for: firstPoint.bodyFatPercentage, height: geometry.size.height)
                            
                            path.move(to: CGPoint(x: xPosition, y: yPosition))
                            
                            for item in chartData.dropFirst() {
                                let xPos = getXPosition(for: item.date, width: geometry.size.width)
                                let yPos = getYPosition(for: item.bodyFatPercentage, height: geometry.size.height)
                                path.addLine(to: CGPoint(x: xPos, y: yPos))
                            }
                        }
                        .stroke(Color.orange, style: StrokeStyle(lineWidth: 2.5, lineCap: .round, lineJoin: .round))
                        .shadow(color: Color.orange.opacity(0.3), radius: 3, x: 0, y: 2)
                        
                        // 渐变填充区域
                        Path { path in
                            guard let firstPoint = chartData.first else { return }
                            
                            let xPosition = getXPosition(for: firstPoint.date, width: geometry.size.width)
                            let yPosition = getYPosition(for: firstPoint.bodyFatPercentage, height: geometry.size.height)
                            
                            path.move(to: CGPoint(x: xPosition, y: geometry.size.height))
                            path.addLine(to: CGPoint(x: xPosition, y: yPosition))
                            
                            for item in chartData.dropFirst() {
                                let xPos = getXPosition(for: item.date, width: geometry.size.width)
                                let yPos = getYPosition(for: item.bodyFatPercentage, height: geometry.size.height)
                                path.addLine(to: CGPoint(x: xPos, y: yPos))
                            }
                            
                            if let lastPoint = chartData.last {
                                let xPos = getXPosition(for: lastPoint.date, width: geometry.size.width)
                                path.addLine(to: CGPoint(x: xPos, y: geometry.size.height))
                            }
                            
                            path.closeSubpath()
                        }
                        .fill(LinearGradient(
                            gradient: Gradient(colors: [Color.orange.opacity(0.3), Color.orange.opacity(0.05)]),
                            startPoint: .top,
                            endPoint: .bottom
                        ))
                    }
                    
                    // 数据点
                    ForEach(chartData) { item in
                        let xPosition = getXPosition(for: item.date, width: geometry.size.width)
                        let yPosition = getYPosition(for: item.bodyFatPercentage, height: geometry.size.height)
                        
                        ZStack {
                            // 外环
                            Circle()
                                .stroke(Color.orange, lineWidth: 2)
                                .frame(width: 12, height: 12)
                            
                            // 内圆点
                            Circle()
                                .fill(Color(UIColor.systemBackground))
                                .frame(width: 6, height: 6)
                        }
                        .shadow(color: Color.orange.opacity(0.3), radius: 2, x: 0, y: 1)
                        .position(x: xPosition, y: yPosition)
                    }
                }
            }
            
            // X轴标签
            HStack {
                Text("12 AM")
                Spacer()
                Text("6")
                Spacer()
                Text("12 PM")
                Spacer()
                Text("6")
                Spacer()
                Text("")
            }
            .font(.system(size: 12))
            .foregroundColor(.gray)
            .padding(.top, 4)
            
            // Y轴标签
            HStack(alignment: .top) {
                VStack(alignment: .trailing, spacing: 0) {
                    Text("\(Int(maxBodyFat))%")
                    Spacer()
                    Text("\(Int(maxBodyFat - (maxBodyFat - minBodyFat) / 3))%")
                    Spacer()
                    Text("\(Int(maxBodyFat - 2 * (maxBodyFat - minBodyFat) / 3))%")
                    Spacer()
                    Text("\(Int(minBodyFat))%")
                }
                .font(.system(size: 12))
                .foregroundColor(.gray)
                
                Spacer()
            }
            .padding(.leading, -8)
            .padding(.top, -290)
        }
    }
    
    // 获取X坐标位置
    private func getXPosition(for date: Date, width: CGFloat) -> CGFloat {
        let dateRange = getDateRange()
        let totalSeconds = dateRange.upperBound.timeIntervalSince(dateRange.lowerBound)
        let seconds = date.timeIntervalSince(dateRange.lowerBound)
        
        let proportion = totalSeconds > 0 ? seconds / totalSeconds : 0
        return proportion * width
    }
    
    // 获取Y坐标位置
    private func getYPosition(for percentage: Double, height: CGFloat) -> CGFloat {
        let range = maxBodyFat - minBodyFat
        let proportion = range > 0 ? (maxBodyFat - percentage) / range : 0
        return proportion * height
    }
    
    // 获取日期范围
    private func getDateRange() -> ClosedRange<Date> {
        let calendar = Calendar.current
        let now = Date()
        let endDate = calendar.startOfDay(for: now)
        var startDate: Date
        
        switch selectedTimeRangeIndex {
        case 0: startDate = calendar.date(byAdding: .day, value: -1, to: endDate)!
        case 1: startDate = calendar.date(byAdding: .day, value: -7, to: endDate)!
        case 2: startDate = calendar.date(byAdding: .month, value: -1, to: endDate)!
        case 3: startDate = calendar.date(byAdding: .month, value: -6, to: endDate)!
        case 4: startDate = calendar.date(byAdding: .year, value: -1, to: endDate)!
        default: startDate = calendar.date(byAdding: .day, value: -1, to: endDate)!
        }
        
        return startDate...calendar.date(byAdding: .day, value: 1, to: endDate)!
    }

    // MARK: - 数据操作
    private func loadBodyFatData() {
        if let data = UserDefaults.standard.data(forKey: "savedBodyFatData"),
           let decoded = try? JSONDecoder().decode([BodyFatData].self, from: data) {
            bodyFatEntries = decoded
            updateAverageBodyFat()
        } else {
            addSampleData()
        }
    }

    private func addSampleData() {
        let calendar = Calendar.current
        let now = Date()

        if let twoDaysAgo = calendar.date(byAdding: .day, value: -2, to: now) {
            bodyFatEntries.append(BodyFatData(date: twoDaysAgo, bodyFatPercentage: 23.1))
        }

        if let oneDayAgo = calendar.date(byAdding: .day, value: -1, to: now) {
            bodyFatEntries.append(BodyFatData(date: oneDayAgo, bodyFatPercentage: 22.8))
        }

        bodyFatEntries.append(BodyFatData(date: now, bodyFatPercentage: 22.5))

        saveBodyFatData()
    }

    private func saveBodyFatData() {
        if let encoded = try? JSONEncoder().encode(bodyFatEntries) {
            UserDefaults.standard.set(encoded, forKey: "savedBodyFatData")
        }
    }

    private func saveNewBodyFatData() {
        guard let bodyFatValue = Double(newBodyFat), bodyFatValue > 0 else { return }

        let newEntry = BodyFatData(date: selectedDate, bodyFatPercentage: bodyFatValue)
        bodyFatEntries.append(newEntry)
        saveBodyFatData()
        updateAverageBodyFat()
        updateChartData()

        newBodyFat = ""
    }

    private func updateAverageBodyFat() {
        if !bodyFatEntries.isEmpty {
            let sum = bodyFatEntries.reduce(0.0) { $0 + $1.bodyFatPercentage }
            averageBodyFat = sum / Double(bodyFatEntries.count)
        }
    }

    private func updateChartData() {
        let dateRange = getDateRange()
        chartData = bodyFatEntries.filter { dateRange.contains($0.date) }
        
        // 根据时间范围排序
        chartData.sort { $0.date < $1.date }
        
        // 更新图表的最大最小值
        if let minValue = chartData.map({ $0.bodyFatPercentage }).min(),
           let maxValue = chartData.map({ $0.bodyFatPercentage }).max() {
            // 添加一些边距使图表更美观
            minBodyFat = max(0, minValue - 2)
            maxBodyFat = maxValue + 2
        }
    }
}

// MARK: - 添加体脂数据视图
struct AddBodyFatDataView: View {
    @Binding var isPresented: Bool
    @Binding var date: Date
    @Binding var time: Date
    @Binding var bodyFatPercentage: String
    var onSave: () -> Void

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Date & Time")) {
                    DatePicker("Date", selection: $date, displayedComponents: .date)
                    DatePicker("Time", selection: $time, displayedComponents: .hourAndMinute)
                }

                Section(header: Text("Body Fat Percentage")) {
                    HStack {
                        TextField("Body Fat %", text: $bodyFatPercentage)
                            .keyboardType(.decimalPad)
                        Text("%")
                            .foregroundColor(.gray)
                    }
                }
            }
            .navigationBarItems(
                leading: Button("Cancel") { isPresented = false },
                trailing: Button("Save") {
                    onSave()
                    isPresented = false
                }
                .disabled(bodyFatPercentage.isEmpty || Double(bodyFatPercentage) == nil)
            )
        }
    }
}
