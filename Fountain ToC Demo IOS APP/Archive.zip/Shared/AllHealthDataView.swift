
import SwiftUI

struct AllHealthDataView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var colorScheme
    
    // Sample health data
    private let healthData = [
        HealthDataItem(
            icon: "lungs.fill",
            title: "Blood Oxygen",
            value: "90",
            unit: "%",
            time: "4:40 PM",
            color: .blue
        ),
         HealthDataItem(
            icon: "bed.double.fill",
            title: "Sleep",
            value: "3h33min",
            unit: "",
            time: "10:40 PM",
            color: .red
        ),
         HealthDataItem(
            icon: "brain",
            title: "Mindfulness",
            value: "1",
            unit: "min",
            time: "6:35 AM",
            color: .green
        )
    ]
    
    var body: some View {
        VStack(spacing: 0) {
            // Custom navigation bar
            HStack {
                Button(action: { dismiss() }) {
                    HStack(spacing: 4) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 16, weight: .semibold))
                        Text("Summary")
                            .font(.system(size: 17))
                    }
                    .foregroundColor(.blue)
                }
                
                Spacer()
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    // Title
                    Text("All Health Data")
                        .font(.system(size: 34, weight: .bold))
                        .foregroundColor(colorScheme == .dark ? .white : .black)
                        .padding(.horizontal, 16)
                        .padding(.top, 8)
                    
                    // Today section
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Today")
                            .font(.system(size: 22, weight: .bold))
                            .foregroundColor(colorScheme == .dark ? .white : .black)
                            .padding(.horizontal, 16)
                        
                        // Health data cards
                        ForEach(healthData) { item in
                            healthDataCard(item: item)
                        }
                    }
                    
                    Spacer(minLength: 500) // Add space at the bottom for scrolling
                }
            }
        }
        .background(backgroundColor.ignoresSafeArea())
        .navigationBarHidden(true)
    }
    
    // Background color based on theme
    private var backgroundColor: Color {
        colorScheme == .dark ? Color.black : Color(UIColor.systemGray6)
    }
    
    // Health data card
    private func healthDataCard(item: HealthDataItem) -> some View {
        VStack(spacing: 12) {
            HStack {
                // Icon and title
                HStack(spacing: 6) {
                    Image(systemName: item.icon)
                        .foregroundColor(item.color)
                        .font(.system(size: 18))
                    
                    Text(item.title)
                        .font(.system(size: 17))
                        .foregroundColor(item.color)
                }
                
                Spacer()
                
                // Time and chevron
                HStack(spacing: 4) {
                    Text(item.time)
                        .font(.system(size: 17))
                        .foregroundColor(.gray)
                    
                    Image(systemName: "chevron.right")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(.gray)
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 16)
            
            // Value display
            HStack(alignment: .firstTextBaseline, spacing: 0) {
                Text(item.value)
                    .font(.system(size: 48, weight: .regular))
                    .foregroundColor(colorScheme == .dark ? .white : .black)
                
                Text(item.unit)
                    .font(.system(size: 24))
                    .foregroundColor(.gray)
                    .padding(.leading, 2)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 16)
            .padding(.bottom, 16)
        }
        .background(cardBackgroundColor)
        .cornerRadius(12)
        .padding(.horizontal, 16)
    }
    
    // Card background color based on theme
    private var cardBackgroundColor: Color {
        colorScheme == .dark ? Color(UIColor.systemGray6) : Color.white
    }
}

// Health data model
struct HealthDataItem: Identifiable {
    let id = UUID()
    let icon: String
    let title: String
    let value: String
    let unit: String
    let time: String
    let color: Color
}

// Preview
struct AllHealthDataView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            AllHealthDataView()
                .preferredColorScheme(.light)
                .previewDisplayName("Light Mode")
            
            AllHealthDataView()
                .preferredColorScheme(.dark)
                .previewDisplayName("Dark Mode")
        }
    }
}
