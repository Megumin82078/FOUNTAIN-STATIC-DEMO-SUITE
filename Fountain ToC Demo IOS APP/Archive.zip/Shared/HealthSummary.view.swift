import SwiftUI

struct HealthSummaryView: View {
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text("健康摘要")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .padding(.horizontal)
                    
                    HealthDataOverview()
                    HealthTrendsCard()
                    QuickAccessButtons()
                    HealthArticles()
                }
            }
            .navigationBarHidden(true)
        }
    }
}

struct HealthDataOverview: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("今日健康数据")
                .font(.headline)
            HStack {
                HealthDataCardd(title: "步数", value: "8,764", unit: "步")
                HealthDataCardd(title: "心率", value: "72", unit: "BPM")
                HealthDataCardd(title: "睡眠", value: "7.5", unit: "小时")
            }
        }
        .padding()
    }
}

struct HealthDataCardd: View {
    var title: String
    var value: String
    var unit: String
    
    var body: some View {
        VStack {
            Text(title).font(.subheadline)
            Text(value).font(.title).bold()
            Text(unit).font(.footnote)
        }
        .frame(width: 100, height: 100)
        .background(Color.blue.opacity(0.1))
        .cornerRadius(12)
    }
}

struct HealthTrendsCard: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("健康趋势")
                .font(.headline)
            Image("health_trend_placeholder") // 这里可以替换为真实趋势图
                .resizable()
                .scaledToFit()
                .frame(height: 150)
                .cornerRadius(12)
        }
        .padding()
    }
}

struct QuickAccessButtons: View {
    var body: some View {
        HStack(spacing: 20) {
            Button(action: {}) {
                Text("编辑首页")
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            Button(action: {}) {
                Text("添加/删除模块")
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
        }
        .padding()
    }
}

struct HealthArticles: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("健康文章推荐")
                .font(.headline)
            ForEach(0..<3) { _ in
                Text("每日健康小知识")
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
            }
        }
        .padding()
    }
}

struct HealthSummaryView_Previews: PreviewProvider {
    static var previews: some View {
        HealthSummaryView()
    }
}
