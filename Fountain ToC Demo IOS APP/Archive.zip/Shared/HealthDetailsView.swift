import SwiftUI

struct HealthDetailsView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        NavigationView {
            VStack {
                // 头像部分
                Image(systemName: "person.crop.circle.fill")
                    .resizable()
                    .frame(width: 100, height: 100)
                    .foregroundColor(.gray)
                    .padding(.top, 20)
                
                Form {
                    Section {
                        ProfileRow1(title: "First Name", value: "Not Set")
                        ProfileRow1(title: "Last Name", value: "Not Set")
                        ProfileRow1(title: "Date of Birth", value: "Not Set", showArrow: true)
                        ProfileRow1(title: "Sex", value: "Not Set", showArrow: true)
                        ProfileRow1(title: "Blood Type", value: "Not Set", showArrow: true)
                        ProfileRow1(title: "Fitzpatrick Skin Type", value: "Not Set", showArrow: true)
                    }
                    
                    Section(header: Text("Wheelchair")) {
                        VStack(alignment: .leading) {
                            ProfileRow1(title: "", value: "Not Set")
                            Text("Track pushes instead of steps on Apple Watch in the Activity app, and in wheelchair workouts in the Workout app, and record them to Health. When this setting is on, your iPhone stops tracking steps.")
                                .font(.footnote)
                                .foregroundColor(.gray)
                        }
                    }
                    
                    Section(header: Text("Medications That Affect Heart Rate")) {
                        VStack(alignment: .leading) {
                            ProfileRow1(title: "", value: "0")
                            Text("Beta blockers or calcium channel blockers can limit your heart rate. Apple Watch can take this into account when estimating your cardio fitness.\n\nChanging this setting does not affect existing data but could change your future cardio fitness predictions.")
                                .font(.footnote)
                                .foregroundColor(.gray)
                        }
                    }
                }
            }
            .navigationBarTitle("Health Details", displayMode: .inline)
            .navigationBarItems(leading: Button(action: {
                // 返回按钮操作
            }) {
                HStack {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.blue)
                    Button("Profile") {
                         presentationMode.wrappedValue.dismiss()
                    }
                        .foregroundColor(.blue)
                }
            }, trailing: Button("Edit") {})
        }
    }
}

struct ProfileRow1: View {
    var title: String
    var value: String
    var showArrow: Bool = false
    
    var body: some View {
        HStack {
            Text(title)
                .foregroundColor(.primary)
            Spacer()
            Text(value)
                .foregroundColor(.gray)
            if showArrow {
                Image(systemName: "chevron.right")
                    .foregroundColor(.gray)
            }
        }
        .padding(.vertical, 8)
    }
}

struct HealthDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            HealthDetailsView()
                .preferredColorScheme(.light)
            HealthDetailsView()
                .preferredColorScheme(.dark)
        }
    }
}
