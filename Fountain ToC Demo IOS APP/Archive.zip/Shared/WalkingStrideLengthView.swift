import SwiftUI

struct WalkingStrideLengthView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.presentationMode) var presentationMode
    
    // Time range selection
    private let timeRanges = ["Day", "Week", "Month", "6 Months", "Year"]
    @State private var selectedTimeRange = 0
    
    // Chart data
    private let chartData: [(hour: Int, value: Double)] = [
        (12, 65), (13, 62), (14, 58), (15, 63),
        (16, 82), (17, 85), (17, 65), (18, 49)
    ]
    
    // Y-axis labels
    private let yAxisValues = [25, 50, 75, 100]
    // X-axis labels
    private let xAxisValues = [0, 6, 12, 18]
    
    var body: some View {
        VStack(spacing: 0) {
            // Custom navigation bar
            customNavigationBar
            
            ScrollView {
                VStack(spacing: 0) {
                    // Time range selector
                    timeRangeSelector
                        .padding(.horizontal, 16)
                        .padding(.top, 16)
                    
                    // Range value display
                    rangeValueView
                        .padding(.top, 20)
                        .padding(.horizontal, 16)
                    
                    // Chart
                    chartView
                        .frame(height: 300)
                        .padding(.top, 20)
                    
                    // Latest data
                    latestDataView
                        .padding(.horizontal, 16)
                        .padding(.top, 16)
                    
                    // Show more button
                    Button("Show More Data") {
                        // Show more data action
                    }
                    .foregroundColor(.blue)
                    .font(.system(size: 17))
                    .frame(maxWidth: .infinity)
                    .padding(.top, 16)
                    
                    // About section
                    aboutSection
                        .padding(.top, 40)
                        .padding(.horizontal, 16)
                }
            }
        }
        .background(Color(colorScheme == .dark ? .black : .white))
        .navigationBarHidden(true)
    }
    
    // Custom navigation bar
    private var customNavigationBar: some View {
        HStack {
            Button(action: { 
                dismiss()
                presentationMode.wrappedValue.dismiss()
            }) {
                HStack(spacing: 2) {
                    Image(systemName: "chevron.left")
                    Text("Mobility")
                }
                .foregroundColor(.blue)
                .font(.system(size: 17))
            }
            
            Spacer()
            
            Text("Walking Stride Length")
                .font(.system(size: 17))
                .foregroundColor(colorScheme == .dark ? .white : .black)
            
            Spacer()
            
            Button("Add Data") {
                // Add data action
            }
            .font(.system(size: 17))
            .foregroundColor(.blue)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color(colorScheme == .dark ? UIColor.systemGray6 : UIColor.systemGray5).opacity(0.8))
    }
    
    // Time range selector
    private var timeRangeSelector: some View {
        HStack(spacing: 0) {
            ForEach(Array(timeRanges.enumerated()), id: \.offset) { index, range in
                Button(action: { selectedTimeRange = index }) {
                    Text(range)
                        .font(.system(size: 17))
                        .foregroundColor(selectedTimeRange == index ? 
                            (colorScheme == .dark ? .white : .black) : .gray)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                        .background(selectedTimeRange == index ? 
                            Color(UIColor.systemGray5) : Color.clear)
                }
            }
        }
        .background(Color(UIColor.systemGray6))
        .cornerRadius(8)
    }
    
    // Range value display
    private var rangeValueView: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Range")
                .font(.system(size: 17))
                .foregroundColor(.gray)
            
            HStack(alignment: .firstTextBaseline, spacing: 0) {
                Text("49-83")
                    .font(.system(size: 48, weight: .regular))
                
                Text(" cm")
                    .font(.system(size: 17))
            }
            .foregroundColor(colorScheme == .dark ? .white : .black)
            
            Text("Today")
                .font(.system(size: 17))
                .foregroundColor(.gray)
        }
    }
    
    // Chart
    private var chartView: some View {
        VStack(spacing: 0) {
            // Chart body
            HStack(alignment: .bottom, spacing: 2) {
                // Y-axis labels
                VStack(alignment: .trailing, spacing: 0) {
                    ForEach(yAxisValues.reversed(), id: \.self) { value in
                        Text("\(value)")
                            .font(.system(size: 13))
                            .foregroundColor(.gray)
                            .frame(height: 40)
                    }
                }
                .padding(.trailing, 8)
                
                // Bar chart and grid lines
                ZStack {
                    // Horizontal grid lines
                    VStack(spacing: 0) {
                        ForEach(0..<4) { _ in
                            Divider()
                                .background(Color.gray.opacity(0.2))
                            Spacer()
                        }
                        Divider()
                            .background(Color.gray.opacity(0.2))
                    }
                    
                    // Vertical grid lines
                    HStack(spacing: 0) {
                        ForEach(0..<4) { _ in
                            Divider()
                                .background(Color.gray.opacity(0.2))
                            Spacer()
                        }
                        Divider()
                            .background(Color.gray.opacity(0.2))
                    }
                    
                    // Data bars
                    HStack(alignment: .bottom, spacing: (UIScreen.main.bounds.width - 100) / CGFloat(chartData.count * 2)) {
                        ForEach(chartData, id: \.hour) { item in
                            RoundedRectangle(cornerRadius: 2)
                                .fill(Color.orange)
                                .frame(width: 4, height: CGFloat(item.value) * 2)
                        }
                    }
                    .padding(.horizontal)
                }
                .frame(height: 160)
            }
            
            // X-axis labels
            HStack {
                Spacer(minLength: 40)
                ForEach(xAxisValues, id: \.self) { hour in
                    Text("\(hour)h")
                        .font(.system(size: 13))
                        .foregroundColor(.gray)
                    Spacer()
                }
            }
            .padding(.top, 8)
        }
        .padding(.horizontal)
    }
    
    // Latest data display
    private var latestDataView: some View {
        HStack {
            Text("Latest: 18:31")
            Spacer()
            Text("49 cm")
        }
        .font(.system(size: 17))
        .foregroundColor(.gray)
        .padding(.vertical, 12)
        .padding(.horizontal, 16)
        .background(Color(UIColor.systemGray6))
        .cornerRadius(8)
    }
    
    // About section
    private var aboutSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("About Walking Stride Length")
                .font(.system(size: 22, weight: .bold))
                .foregroundColor(colorScheme == .dark ? .white : .black)
            
            Text("Stride length is the distance between consecutive steps. A larger stride is associated with long-term mobility and physical activity.")
                .font(.system(size: 17))
                .foregroundColor(.gray)
                .padding(16)
                .background(Color(UIColor.systemGray6))
                .cornerRadius(8)
        }
    }
}

// Preview
struct WalkingStrideLengthView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            WalkingStrideLengthView()
                .preferredColorScheme(.dark)
            
            WalkingStrideLengthView()
                .preferredColorScheme(.light)
        }
    }
}
