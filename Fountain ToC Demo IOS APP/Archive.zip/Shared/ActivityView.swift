import SwiftUI

struct ActivityDataItem: Identifiable {
    let id = UUID()
    let icon: String
    let title: String
    let value: String
    let unit: String
    let time: String
    let chartData: [Double]
    let iconColor: Color
}

struct ActivityView: View {
    let todayData: [ActivityDataItem] = [
        ActivityDataItem(
            icon: "flame.fill",
            title: "Steps",
            value: "93",
            unit: "steps",
            time: "00:49",
            chartData: [0.3, 0.5, 0.4, 0.6, 0.7, 0.8],
            iconColor: .orange
        ),
        ActivityDataItem(
            icon: "flame.fill",
            title: "Walking + Running Distance",
            value: "0.05",
            unit: "km",
            time: "00:49",
            chartData: [0.2, 0.4, 0.3, 0.5, 0.6, 0.7],
            iconColor: .orange
        )
    ]
    
    let pastWeekData: [ActivityDataItem] = [
        ActivityDataItem(
            icon: "flame.fill",
            title: "Flights Climbed",
            value: "8",
            unit: "floors",
            time: "Yesterday",
            chartData: [0.3, 0.5, 0.2, 0.4, 0.3, 0.8, 1.0],
            iconColor: .orange
        )
    ]
    
    let pastMonthData: [ActivityDataItem] = [
        ActivityDataItem(
            icon: "flame.fill",
            title: "Workouts",
            value: "8",
            unit: "min",
            time: "Feb 3",
            chartData: [0, 0, 0, 0.8, 0, 0, 1.0],
            iconColor: .orange
        )
    ]
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                // Today Section
                VStack(alignment: .leading, spacing: 16) {
                    Text("Today")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                    
                    ForEach(todayData) { item in
                        ActivityCardView(data: item)
                    }
                }
                
                // Past 7 Days Section
                VStack(alignment: .leading, spacing: 16) {
                    Text("Past 7 Days")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                    
                    ForEach(pastWeekData) { item in
                        ActivityCardView(data: item)
                    }
                }
                
                // Past 30 Days Section
                VStack(alignment: .leading, spacing: 16) {
                    Text("Past 30 Days")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                    
                    ForEach(pastMonthData) { item in
                        ActivityCardView(data: item)
                    }
                }
            }
            .padding()
        }
        .navigationTitle("Activity")
        .navigationBarTitleDisplayMode(.large)
        .background(Color.black.edgesIgnoringSafeArea(.all))
    }
}

struct ActivityCardView: View {
    let data: ActivityDataItem
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 8) {
                // Title Row
                HStack {
                    Image(systemName: data.icon)
                        .foregroundColor(data.iconColor)
                    Text(data.title)
                        .foregroundColor(data.iconColor)
                    Spacer()
                    Text(data.time)
                        .foregroundColor(.gray)
                    Image(systemName: "chevron.right")
                        .foregroundColor(.gray)
                }
                
                // Value Row
                HStack(alignment: .firstTextBaseline) {
                    Text(data.value)
                        .font(.system(size: 32, weight: .regular))
                        .foregroundColor(.white)
                    Text(data.unit)
                        .font(.system(size: 16))
                        .foregroundColor(.gray)
                    Spacer()
                    
                    // Chart
                    HStack(alignment: .bottom, spacing: 4) {
                        ForEach(data.chartData, id: \.self) { value in
                            Rectangle()
                                .fill(Color.gray.opacity(0.3))
                                .frame(width: 4, height: 20 * value)
                        }
                    }
                }
            }
            .padding()
        }
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
}

struct ActivityView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            ActivityView()
        }
        .preferredColorScheme(.dark)
    }
}
