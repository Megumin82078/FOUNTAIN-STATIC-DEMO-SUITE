import SwiftUI

struct ArticleDetailView: View {
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                // 模拟图片的背景色
                ZStack {
                    Color.blue
                        .frame(height: 200)
                        .cornerRadius(10)
                    
                    Text("Image Placeholder")
                        .foregroundColor(.white)
                        .font(.headline)
                }

                // 文章标题
                Text("Understanding Respiratory Rate")
                    .font(.title)
                    .fontWeight(.bold)

                // 文章内容
                Text("""
                Respiratory rate is the number of breaths you take per minute. Monitoring it can provide insights into your health condition.

                A normal resting adult breathes about 12–20 times per minute, while children breathe slightly faster at 18–30 breaths per minute.

                Tracking respiratory rate can help identify potential health issues early.
                """)
                    .font(.body)
                    .foregroundColor(.secondary)

                Spacer()
            }
            .padding()
        }
    }
}

// 预览
struct ArticleDetailView_Previews: PreviewProvider {
    static var previews: some View {
        ArticleDetailView()
    }
}
