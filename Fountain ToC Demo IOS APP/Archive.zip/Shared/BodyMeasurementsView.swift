import SwiftUI

struct BodyMeasurementsView: View {
    @Environment(\.colorScheme) var colorScheme
    @Environment(\.presentationMode) var presentationMode
    
    // 示例数据
    @State private var leanBodyMass: Double = 0.0
    @State private var bodyMassIndex: Double = 0.0
    @State private var bodyFatPercentage: Double = 0.0
    @State private var weight: Double = 0.0
    
    // 时间格式化
    @State private var todayTimeString: String = ""
    @State private var pastDateString: String = ""
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // 今日数据部分
                Text("Today")
                    .font(.title2)
                    .fontWeight(.bold)
                    .padding(.horizontal)
                    .padding(.top, 10)
                
                // 瘦体重
                NavigationLink {
                    LeanBodyMassView()
                } label: {
                    MeasurementCard(
                        title: "Lean Body Mass",
                        value: String(format: "%.1f", leanBodyMass),
                        unit: "lbs",
                        time: todayTimeString,
                        iconName: "figure.stand",
                        iconColor: .purple
                    )
                }.buttonStyle(.plain)
                
                // 体重指数
                NavigationLink {
                    BMIView()
                } label: {
                    MeasurementCard(
                        title: "Body Mass Index",
                        value: String(format: "%.1f", bodyMassIndex),
                        unit: "BMI",
                        time: todayTimeString,
                        iconName: "figure.stand",
                        iconColor: .purple
                    )
                }.buttonStyle(.plain)
                
                // 体脂率
                NavigationLink {
                    BodyFatPercentageView()
                } label: {
                    MeasurementCard(
                        title: "Body Fat Percentage",
                        value: String(format: "%.1f", bodyFatPercentage),
                        unit: "%",
                        time: todayTimeString,
                        iconName: "figure.stand",
                        iconColor: .purple
                    )
                }.buttonStyle(.plain)
                
                // 过去7天部分
                Text("Past 7 Days")
                    .font(.title2)
                    .fontWeight(.bold)
                    .padding(.horizontal)
                    .padding(.top, 10)
                
                // 体重记录
                NavigationLink {
                    WeightDetailView()
                } label: {
                    MeasurementCard(
                        title: "Weight",
                        value: String(format: "%.1f", weight),
                        unit: "lbs",
                        time: pastDateString,
                        iconName: "figure.stand",
                        iconColor: .purple
                    )
                }.buttonStyle(.plain)
                
                Spacer(minLength: 50)
            }
            .padding(.bottom, 20)
        }
        .background(colorScheme == .dark ? Color.black : Color(.systemGroupedBackground))
        .navigationTitle("Body Measurements")
        .navigationBarTitleDisplayMode(.large)
        .onAppear {
            loadAllMeasurementData()
            formatTimeStrings()
        }
    }
    
    // 加载所有测量数据
    private func loadAllMeasurementData() {
        loadLeanBodyMassData()
        loadBMIData()
        loadBodyFatData()
        loadWeightData()
    }
    
    // 格式化时间字符串
    private func formatTimeStrings() {
        let dateFormatter = DateFormatter()
        
        // 今天的时间格式
        dateFormatter.dateFormat = "h:mm a"
        todayTimeString = dateFormatter.string(from: Date())
        
        // 过去日期格式
        dateFormatter.dateFormat = "MMM d"
        if let sevenDaysAgo = Calendar.current.date(byAdding: .day, value: -7, to: Date()) {
            pastDateString = dateFormatter.string(from: sevenDaysAgo)
        }
    }
    
    // 加载瘦体重数据
    private func loadLeanBodyMassData() {
        if let data = UserDefaults.standard.data(forKey: "savedLeanBodyMassData") {
            if let decoded = try? JSONDecoder().decode([LeanBodyMassData].self, from: data) {
                if !decoded.isEmpty {
                    let sum = decoded.reduce(0.0) { $0 + $1.leanBodyMass }
                    leanBodyMass = sum / Double(decoded.count)
                }
            }
        }
    }
    
    // 加载BMI数据
    private func loadBMIData() {
        if let data = UserDefaults.standard.data(forKey: "savedBMIData") {
            if let decoded = try? JSONDecoder().decode([BMIData].self, from: data) {
                if !decoded.isEmpty {
                    let sum = decoded.reduce(0.0) { $0 + $1.bmi }
                    bodyMassIndex = sum / Double(decoded.count)
                }
            }
        }
    }
    
    // 加载体脂率数据
    private func loadBodyFatData() {
        if let data = UserDefaults.standard.data(forKey: "savedBodyFatData") {
            if let decoded = try? JSONDecoder().decode([BodyFatData].self, from: data) {
                if !decoded.isEmpty {
                    let sum = decoded.reduce(0.0) { $0 + $1.bodyFatPercentage }
                    bodyFatPercentage = sum / Double(decoded.count)
                }
            }
        }
    }
    
    // 加载体重数据
    private func loadWeightData() {
        if let data = UserDefaults.standard.data(forKey: "savedWeightData") {
            if let decoded = try? JSONDecoder().decode([WeightData].self, from: data) {
                if !decoded.isEmpty {
                    let sum = decoded.reduce(0.0) { $0 + $1.weight }
                    weight = sum / Double(decoded.count)
                }
            }
        }
    }
}

struct MeasurementCard: View {
    var title: String
    var value: String
    var unit: String
    var time: String
    var iconName: String
    var iconColor: Color
    
    var body: some View {
        VStack {
            HStack {
                Image(systemName: iconName)
                    .foregroundColor(iconColor)
                    .font(.system(size: 16))
                
                Text(title)
                    .foregroundColor(iconColor)
                    .font(.system(size: 16))
                
                Spacer()
                
                Text(time)
                    .foregroundColor(.secondary)
                    .font(.system(size: 16))
                
                Image(systemName: "chevron.right")
                    .foregroundColor(.secondary)
                    .font(.system(size: 14))
            }
            .padding(.horizontal)
            .padding(.top, 12)
            
            HStack(alignment: .firstTextBaseline) {
                Text(value)
                    .font(.system(size: 40, weight: .regular))
                    .padding(.leading)
                
                Text(unit)
                    .font(.system(size: 22))
                    .foregroundColor(.secondary)
                
                Spacer()
            }
            .padding(.bottom, 12)
        }
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .padding(.horizontal)
    }
}

struct BodyMeasurementsView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            BodyMeasurementsView()
        }
        .preferredColorScheme(.light)
        
        NavigationView {
            BodyMeasurementsView()
        }
        .preferredColorScheme(.dark)
    }
}
