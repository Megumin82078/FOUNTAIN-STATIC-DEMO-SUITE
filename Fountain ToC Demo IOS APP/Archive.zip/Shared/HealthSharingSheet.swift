import SwiftUI
import Combine  // Add this import for Cancellable

// 诊所数据模型
struct Clinic: Identifiable {
    let id = UUID()
    let name: String
    let address: String
    let isAuthorized: Bool
    let authorizationDate: Date?
    let expirationDate: Date?
    // 新增字段
    let logo: String  // 存储logo图标名称或首字母
    let doctorName: String
    let businessHours: String
    let email: String
    let phone: String
    
    var authorizationStatus: AuthorizationStatus {
        if !isAuthorized {
            return .notAuthorized
        }
        
        if let expDate = expirationDate, expDate < Date() {
            return .expired
        }
        
        return .authorized
    }
    
    enum AuthorizationStatus {
        case authorized
        case expired
        case notAuthorized
        
        var text: String {
            switch self {
            case .authorized: return "Authorized"
            case .expired: return "Expired"
            case .notAuthorized: return "Not Authorized"
            }
        }
        
        var color: Color {
            switch self {
            case .authorized: return .green
            case .expired: return .orange
            case .notAuthorized: return .gray
            }
        }
    }
}

struct HealthSharingSheet: View {
    @Environment(\.colorScheme) var colorScheme
    @State private var clinics: [Clinic] = []
    @State private var showAddClinic = false
    @State private var selectedClinic: Clinic? = nil
    @State private var expandedClinic: UUID? = nil
    @State private var showAuthConfirmation = false  // 显示授权确认弹窗
    @State private var pendingClinic: Clinic? = nil  // 待确认的诊所
    
    // 颜色和主题
    var backgroundColor: Color {
        colorScheme == .dark ? Color(.systemBackground) : Color(.systemBackground)
    }
    
    var cardBackgroundColor: Color {
        colorScheme == .dark ? Color(.secondarySystemBackground) : Color(.secondarySystemBackground)
    }
    
    var textColor: Color {
        colorScheme == .dark ? .white : .black
    }
    
    var body: some View {
        ZStack {  // 使用ZStack来叠加确认弹窗
            VStack(alignment: .leading, spacing: 0) {
                // 标题
                Text("Health Data Sharing")
                    .font(.system(size: 28, weight: .bold))
                    .foregroundColor(textColor)
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
                    .padding(.bottom, 8)
                
                // 说明文字
                Text("You can authorize clinics to access your health data so doctors can better understand your health condition.")
                    .font(.system(size: 16))
                    .foregroundColor(.secondary)
                    .padding(.horizontal, 20)
                    .padding(.bottom, 20)
                
                // 已授权诊所列表 - 修改为卡片式布局
                if clinics.isEmpty {
                    emptyStateView
                        .frame(height: 200) // 设置固定高度
                } else {
                    ScrollView {
                        VStack(spacing: 16) {
                            ForEach(clinics) { clinic in
                                ClinicCard(
                                    clinic: clinic, 
                                    isExpanded: expandedClinic == clinic.id,
                                    onTap: {
                                        withAnimation(.spring()) {
                                            if expandedClinic == clinic.id {
                                                expandedClinic = nil
                                            } else {
                                                expandedClinic = clinic.id
                                            }
                                        }
                                    },
                                    onDetail: {
                                        selectedClinic = clinic
                                    }
                                )
                            }
                        }
                        .padding(.horizontal, 20)
                        .padding(.bottom, 20)
                    }
                    .frame(minHeight: 400, maxHeight: .infinity)
                }
                
                // 添加按钮
                HStack {
                    Spacer()
                    Button(action: {
                        showAddClinic = true
                    }) {
                        Image(systemName: "plus")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.white)
                            .padding(12)
                            .background(Circle().fill(Color.blue))
                    }
                    .padding(.trailing, 20)
                    .padding(.bottom, 20)
                }
            }
            .background(backgroundColor)
            .sheet(isPresented: $showAddClinic) {
                // 修改AddClinicView的回调
                AddClinicView(onClinicSelected: { clinic in
                    pendingClinic = clinic  // 存储待确认的诊所
                    showAddClinic = false
                    // 延迟显示确认弹窗，确保AddClinicView已关闭
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        showAuthConfirmation = true
                    }
                })
            }
            .sheet(item: $selectedClinic) { clinic in
                ClinicDetailView(clinic: clinic, onDelete: { deletedClinic in
                    clinics.removeAll { $0.id == deletedClinic.id }
                    selectedClinic = nil
                })
            }
            // 新增：使用sheet显示授权确认弹窗
            .sheet(isPresented: $showAuthConfirmation, onDismiss: {
                if pendingClinic != nil && !showAuthConfirmation {
                    pendingClinic = nil
                }
            }) {
                if let clinic = pendingClinic {
                    AuthorizationConfirmationView(
                        clinic: clinic,
                        onApprove: {
                            // 创建一个新的已授权诊所，包含所有必要字段
                            let authorizedClinic = Clinic(
                                name: clinic.name,
                                address: clinic.address,
                                isAuthorized: true,
                                authorizationDate: Date(),
                                expirationDate: Calendar.current.date(byAdding: .day, value: 90, to: Date()),
                                logo: clinic.logo,
                                doctorName: clinic.doctorName,
                                businessHours: clinic.businessHours,
                                email: clinic.email,
                                phone: clinic.phone
                            )
                            clinics.append(authorizedClinic)
                            showAuthConfirmation = false
                            pendingClinic = nil
                        },
                        onDeny: {
                            showAuthConfirmation = false
                            pendingClinic = nil
                        }
                    )
                }
            }
            .onAppear {
                // 加载示例数据
                if clinics.isEmpty {
                    loadSampleClinics()
                }
            }
            
            // 授权确认弹窗
            if showAuthConfirmation, let clinic = pendingClinic {
                Color.black.opacity(0.4)
                    .edgesIgnoringSafeArea(.all)
                    .onTapGesture {
                        showAuthConfirmation = false
                        pendingClinic = nil
                    }
                
                VStack(spacing: 0) {
                    // 医院Logo
                    VStack {
                        ZStack {
                            Rectangle()
                                .fill(Color.gray.opacity(0.1))
                                .frame(width: 100, height: 50)
                            
                            Text("YOUR LOGO HERE")
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(.secondary)
                        }
                        .padding(.top, 20)
                        .padding(.bottom, 10)
                        
                        // 确认文案
                        Text("Are you authorizing your data to \(clinic.name)?")
                            .font(.system(size: 17, weight: .semibold))
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 20)
                            .padding(.top, 20)
                            .padding(.bottom, 10)
                        
                        // 用户信息
                        VStack(spacing: 12) {
                            infoRow(icon: "mappin.circle.fill", text: clinic.address)
                            infoRow(icon: "clock.fill", text: clinic.businessHours)
                            infoRow(icon: "desktopcomputer", text: "Browser")
                            infoRow(icon: "person.fill", text: clinic.doctorName)
                            infoRow(icon: "envelope.fill", text: clinic.email)
                            infoRow(icon: "phone.fill", text: clinic.phone)
                        }
                        .padding(.vertical, 20)
                        
                        // 按钮
                        HStack(spacing: 20) {
                            // 拒绝按钮
                            Button(action: {
                                showAuthConfirmation = false
                                pendingClinic = nil
                            }) {
                                VStack {
                                    Circle()
                                        .fill(Color.red)
                                        .frame(width: 60, height: 60)
                                        .overlay(
                                            Image(systemName: "xmark")
                                                .font(.system(size: 24, weight: .bold))
                                                .foregroundColor(.white)
                                        )
                                    
                                    Text("Deny")
                                        .font(.system(size: 14))
                                        .foregroundColor(.red)
                                        .padding(.top, 4)
                                }
                            }
                            
                            // 确认按钮
                            Button(action: {
                                // 创建一个新的已授权诊所
                                let authorizedClinic = Clinic(
                                    name: clinic.name,
                                    address: clinic.address,
                                    isAuthorized: true,
                                    authorizationDate: Date(),
                                    expirationDate: Calendar.current.date(byAdding: .day, value: 90, to: Date()),
                                    logo: clinic.logo,
                                    doctorName: clinic.doctorName,
                                    businessHours: clinic.businessHours,
                                    email: clinic.email,
                                    phone: clinic.phone
                                )
                                clinics.append(authorizedClinic)
                                showAuthConfirmation = false
                                pendingClinic = nil
                            }) {
                                VStack {
                                    Circle()
                                        .fill(Color.green)
                                        .frame(width: 60, height: 60)
                                        .overlay(
                                            Image(systemName: "checkmark")
                                                .font(.system(size: 24, weight: .bold))
                                                .foregroundColor(.white)
                                        )
                                    
                                    Text("Approve")
                                        .font(.system(size: 14))
                                        .foregroundColor(.green)
                                        .padding(.top, 4)
                                }
                            }
                        }
                        .padding(.bottom, 30)
                    }
                    .frame(maxWidth: .infinity)
                    .background(Color(.systemBackground))
                    .cornerRadius(20)
                    .shadow(radius: 10)
                    .padding(.horizontal, 20)
                }
                .transition(.move(edge: .bottom))
                .animation(.spring(), value: showAuthConfirmation)
            }
        }
    }
    
    // 信息行视图
    private func infoRow(icon: String, text: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 16))
                .foregroundColor(.secondary)
                .frame(width: 24)
            
            Text(text)
                .font(.system(size: 16))
                .foregroundColor(.primary)
            
            Spacer()
        }
        .padding(.horizontal, 20)
    }
    
    // 空状态视图
    private var emptyStateView: some View {
        VStack(spacing: 16) {
            Image(systemName: "heart.text.square")
                .font(.system(size: 60))
                .foregroundColor(.secondary)
            
            Text("No Shared Clinics")
                .font(.system(size: 18, weight: .medium))
                .foregroundColor(.secondary)
            
            Text("Tap the + button in the top right to add a clinic")
                .font(.system(size: 16))
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(.bottom, 40)
    }
    
    // 诊所列表视图
    private var clinicListView: some View {
        List {
            Section(header: Text("Authorized Clinics").font(.system(size: 16, weight: .medium))) {
                ForEach(clinics) { clinic in
                    Button(action: {
                        selectedClinic = clinic
                    }) {
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(clinic.name)
                                    .font(.system(size: 17))
                                    .foregroundColor(textColor)
                                
                                Text(clinic.address)
                                    .font(.system(size: 14))
                                    .foregroundColor(.secondary)
                            }
                            
                            Spacer()
                            
                            Text(clinic.authorizationStatus.text)
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(clinic.authorizationStatus.color)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 4)
                                .background(
                                    RoundedRectangle(cornerRadius: 4)
                                        .fill(clinic.authorizationStatus.color.opacity(0.1))
                                )
                            
                            Image(systemName: "chevron.right")
                                .font(.system(size: 14))
                                .foregroundColor(.secondary)
                        }
                        .padding(.vertical, 4)
                    }
                }
            }
        }
        .listStyle(InsetGroupedListStyle())
    }
    
    // 加载示例数据
    // 加载示例数据
    private func loadSampleClinics() {
        clinics = [
            Clinic(
                name: "Toronto General Hospital",
                address: "200 Elizabeth St, Toronto, ON M5G 2C4",
                isAuthorized: true,
                authorizationDate: Calendar.current.date(byAdding: .day, value: -30, to: Date()),
                expirationDate: Calendar.current.date(byAdding: .day, value: 60, to: Date()),
                logo: "T",
                doctorName: "Dr. Sarah Johnson",
                businessHours: "Mon-Fri: 8AM-6PM",
                email: "contact@tgh.ca",
                phone: "416-340-3111"
            ),
            Clinic(
                name: "Sunnybrook Health Sciences Centre",
                address: "2075 Bayview Ave, Toronto, ON M4N 3M5",
                isAuthorized: true,
                authorizationDate: Calendar.current.date(byAdding: .day, value: -45, to: Date()),
                expirationDate: Calendar.current.date(byAdding: .day, value: -5, to: Date()),
                logo: "S",
                doctorName: "Dr. Michael Chen",
                businessHours: "Mon-Sun: 7AM-8PM",
                email: "info@sunnybrook.ca",
                phone: "416-480-6100"
            ),
            Clinic(
                name: "Mount Sinai Hospital",
                address: "600 University Ave, Toronto, ON M5G 1X5",
                isAuthorized: true,
                authorizationDate: Calendar.current.date(byAdding: .day, value: -10, to: Date()),
                expirationDate: Calendar.current.date(byAdding: .day, value: 80, to: Date()),
                logo: "M",
                doctorName: "Dr. Emily Wilson",
                businessHours: "Mon-Fri: 9AM-5PM",
                email: "contact@sinai.ca",
                phone: "416-596-4200"
            )
        ]
    }
}

// MARK: - 诊所详情视图
struct ClinicDetailView: View {
    let clinic: Clinic
    let onDelete: (Clinic) -> Void
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) var colorScheme
    @State private var showDeleteConfirmation = false
    
    var textColor: Color {
        colorScheme == .dark ? .white : .black
    }
    
    var body: some View {
        NavigationView {
            List {
                Section {
                    VStack(alignment: .center, spacing: 16) {
                        Image(systemName: "building.2")
                            .font(.system(size: 50))
                            .foregroundColor(.blue)
                            .padding(.top, 20)
                        
                        Text(clinic.name)
                            .font(.system(size: 22, weight: .bold))
                            .foregroundColor(textColor)
                        
                        Text(clinic.address)
                            .font(.system(size: 16))
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                        
                        HStack {
                            Text(clinic.authorizationStatus.text)
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(clinic.authorizationStatus.color)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 6)
                                .background(
                                    RoundedRectangle(cornerRadius: 4)
                                        .fill(clinic.authorizationStatus.color.opacity(0.1))
                                )
                        }
                        .padding(.bottom, 20)
                    }
                    .frame(maxWidth: .infinity)
                }
                .listRowBackground(colorScheme == .dark ? Color(.secondarySystemBackground) : Color(.systemBackground))
                
                Section(header: Text("Authorization Information")) {
                    if let authDate = clinic.authorizationDate {
                        HStack {
                            Text("Authorization Date")
                            Spacer()
                            Text(formatDate(authDate))
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    if let expDate = clinic.expirationDate {
                        HStack {
                            Text("Expiration Date")
                            Spacer()
                            Text(formatDate(expDate))
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    HStack {
                        Text("Authorization Status")
                        Spacer()
                        Text(clinic.authorizationStatus.text)
                            .foregroundColor(clinic.authorizationStatus.color)
                    }
                }
                
                Section(header: Text("Shared Data Types")) {
                    dataTypeRow(icon: "heart.text.square", color: .red, title: "Medical Record")
                    dataTypeRow(icon: "cross.case.fill", color: .blue, title: "Lab Results")
                    dataTypeRow(icon: "doc.text.fill", color: .orange, title: "Doctor's Note")
                    dataTypeRow(icon: "pills.fill", color: .green, title: "Medication Records")
                    dataTypeRow(icon: "exclamationmark.shield.fill", color: .purple, title: "Allergy Information")
                }
                
                Section {
                    Button(action: {
                        showDeleteConfirmation = true
                    }) {
                        HStack {
                            Spacer()
                            Text("Revoke Access")
                                .foregroundColor(.red)
                            Spacer()
                        }
                    }
                }
            }
            .listStyle(InsetGroupedListStyle())
            .navigationBarTitle("Clinic Details", displayMode: .inline)
            .navigationBarItems(trailing: Button("Done") {
                dismiss()
            })
            .alert(isPresented: $showDeleteConfirmation) {
                Alert(
                    title: Text("Revoke Access"),
                    message: Text("Are you sure you want to revoke access to \"\(clinic.name)\"'s health data?"),
                    primaryButton: .destructive(Text("Revoke")) {
                        onDelete(clinic)
                    },
                    secondaryButton: .cancel(Text("Cancel"))
                )
            }
        }
    }
    
    private func dataTypeRow(icon: String, color: Color, title: String) -> some View {
        HStack {
            Image(systemName: icon)
                .foregroundColor(color)
                .frame(width: 24)
            Text(title)
            Spacer()
            Image(systemName: "checkmark")
                .foregroundColor(.green)
        }
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}

// MARK: - 添加诊所视图
struct AddClinicView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) var colorScheme
    @State private var searchText = ""
    @State private var searchResults: [Clinic] = []
    // 删除这里的showConfirmation和selectedClinic相关代码，因为我们不再使用alert
    
    let onClinicSelected: (Clinic) -> Void
    
    var textColor: Color {
        colorScheme == .dark ? .white : .black
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // 搜索框
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.secondary)
                    
                    TextField("Search for clinics", text: $searchText)
                        .onChange(of: searchText) { _ in
                            searchClinics()
                        }
                    
                    if !searchText.isEmpty {
                        Button(action: {
                            searchText = ""
                            searchResults = []
                        }) {
                            Image(systemName: "xmark.circle.fill")
                                .foregroundColor(.secondary)
                        }
                    }
                }
                .padding(10)
                .background(
                    RoundedRectangle(cornerRadius: 10)
                        .fill(colorScheme == .dark ? Color(.systemGray6) : Color(.systemGray6))
                )
                .padding(.horizontal, 16)
                .padding(.top, 16)
                .padding(.bottom, 8)
                
                if searchText.isEmpty {
                    // 推荐诊所
                    recommendedClinicsView
                } else if searchResults.isEmpty {
                    // 无搜索结果
                    noResultsView
                } else {
                    // 搜索结果
                    searchResultsView
                }
            }
            .navigationBarTitle("Add Clinic", displayMode: .inline)
            .navigationBarItems(leading: Button("Cancel") {
                dismiss()
            })
            // 删除这里的alert部分
        }
    }
    
    // 推荐诊所视图
    private var recommendedClinicsView: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Recommended Clinics")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(textColor)
                    .padding(.horizontal, 16)
                    .padding(.top, 16)
                
                ForEach(getSampleClinics()) { clinic in
                    Button(action: {
                        // 直接调用回调，不再显示确认弹窗
                        onClinicSelected(clinic)
                    }) {
                        clinicRow(clinic)
                    }
                    .buttonStyle(PlainButtonStyle())
                }
            }
        }
    }
    
    // 搜索结果视图
    private var searchResultsView: some View {
        List {
            ForEach(searchResults) { clinic in
                Button(action: {
                    // 直接调用回调，不再显示确认弹窗
                    onClinicSelected(clinic)
                }) {
                    clinicRow(clinic)
                }
            }
        }
        .listStyle(PlainListStyle())
    }
    
    // 无搜索结果视图
    private var noResultsView: some View {
        VStack(spacing: 16) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 40))
                .foregroundColor(.secondary)
            
            Text("No Clinics Found")
                .font(.system(size: 18, weight: .medium))
                .foregroundColor(.secondary)
            
            Text("Try different keywords or select from recommended clinics")
                .font(.system(size: 16))
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
    
    // 诊所行视图
    private func clinicRow(_ clinic: Clinic) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(clinic.name)
                    .font(.system(size: 17))
                    .foregroundColor(textColor)
                
                Text(clinic.address)
                    .font(.system(size: 14))
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Image(systemName: "chevron.right")
                .font(.system(size: 14))
                .foregroundColor(.secondary)
        }
        .padding(.vertical, 8)
        .padding(.horizontal, 16)
    }
    
    // 搜索诊所
    private func searchClinics() {
        guard !searchText.isEmpty else {
            searchResults = []
            return
        }
        
        // 模拟搜索结果
        let allClinics = getSampleClinics()
        searchResults = allClinics.filter {
            $0.name.lowercased().contains(searchText.lowercased()) ||
            $0.address.lowercased().contains(searchText.lowercased())
        }
    }
    // 获取示例诊所
    private func getSampleClinics() -> [Clinic] {
        return [
            Clinic(
                name: "Toronto General Hospital",
                address: "200 Elizabeth St, Toronto, ON M5G 2C4",
                isAuthorized: false,
                authorizationDate: nil,
                expirationDate: nil,
                logo: "T",
                doctorName: "Dr. Sarah Johnson",
                businessHours: "Mon-Fri: 8AM-6PM",
                email: "contact@tgh.ca",
                phone: "416-340-3111"
            ),
            Clinic(
                name: "Montreal General Hospital",
                address: "1650 Cedar Ave, Montreal, QC H3G 1A4",
                isAuthorized: false,
                authorizationDate: nil,
                expirationDate: nil,
                logo: "M",
                doctorName: "Dr. Jean Tremblay",
                businessHours: "Mon-Sat: 7AM-7PM",
                email: "info@mgh.ca",
                phone: "514-934-1934"
            ),
            Clinic(
                name: "Vancouver General Hospital",
                address: "899 W 12th Ave, Vancouver, BC V5Z 1M9",
                isAuthorized: false,
                authorizationDate: nil,
                expirationDate: nil,
                logo: "V",
                doctorName: "Dr. David Wong",
                businessHours: "24/7",
                email: "info@vgh.ca",
                phone: "604-875-4111"
            ),
            Clinic(
                name: "Sunnybrook Health Sciences Centre",
                address: "2075 Bayview Ave, Toronto, ON M4N 3M5",
                isAuthorized: false,
                authorizationDate: nil,
                expirationDate: nil,
                logo: "S",
                doctorName: "Dr. Michael Chen",
                businessHours: "Mon-Sun: 7AM-8PM",
                email: "info@sunnybrook.ca",
                phone: "416-480-6100"
            ),
            Clinic(
                name: "Calgary Foothills Medical Centre",
                address: "1403 29 St NW, Calgary, AB T2N 2T9",
                isAuthorized: false,
                authorizationDate: nil,
                expirationDate: nil,
                logo: "C",
                doctorName: "Dr. Robert Anderson",
                businessHours: "24/7",
                email: "info@foothills.ca",
                phone: "403-944-1110"
            )
        ]
    }
}

// MARK: - 预览
struct HealthSharingSheet_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            HealthSharingSheet()
                .preferredColorScheme(.light)
                .previewDisplayName("Light Mode")
            
            HealthSharingSheet()
                .preferredColorScheme(.dark)
                .previewDisplayName("Dark Mode")
        }
    }
}

// 新增：诊所卡片组件
struct ClinicCard: View {
     let clinic: Clinic
    let isExpanded: Bool
    let onTap: () -> Void
    let onDetail: () -> Void
    @Environment(\.colorScheme) var colorScheme
    
    // 添加状态变量
    @State private var passcode: String = ""
    @State private var timeRemaining: Int = 60
    @State private var timer: Timer.TimerPublisher = Timer.publish(every: 1, on: .main, in: .common)
    @State private var timerCancellable: Cancellable? = nil
    
    var textColor: Color {
        colorScheme == .dark ? .white : .black
    }
    
    // 生成随机密码
    private func generatePasscode() -> String {
        let digits = Array("0123456789")
        return String((0..<6).map { _ in digits.randomElement()! })
    }
    
    // 复制密码到剪贴板
    private func copyPasscode() {
        UIPasteboard.general.string = passcode
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // 诊所信息
            HStack {
                // 医院logo
                Image(systemName: "building.2.fill")
                    .font(.system(size: 24))
                    .foregroundColor(.blue)
                    .frame(width: 40, height: 40)
                    .background(Color.blue.opacity(0.1))
                    .clipShape(Circle())
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(clinic.name)
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundColor(textColor)
                    
                    Text(clinic.address)
                        .font(.system(size: 14))
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                }
                
                Spacer()
                
                // 展开/收起按钮
                Button(action: onTap) {
                    Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                        .font(.system(size: 14))
                        .foregroundColor(.secondary)
                        .padding(8)
                        .background(Color(.systemGray6))
                        .clipShape(Circle())
                }
            }
            
            // 展开后显示的内容
            if isExpanded {
                Divider()
                
                // 授权状态
                HStack {
                    Text("Status:")
                        .font(.system(size: 14))
                        .foregroundColor(.secondary)
                    
                    Text(clinic.authorizationStatus.text)
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(clinic.authorizationStatus.color)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 2)
                        .background(
                            RoundedRectangle(cornerRadius: 4)
                                .fill(clinic.authorizationStatus.color.opacity(0.1))
                        )
                    
                    Spacer()
                    
                    // 医生信息
                    Text(clinic.doctorName)
                        .font(.system(size: 14))
                        .foregroundColor(textColor)
                }
                                // 添加验证密码区域
                VStack(spacing: 8) {
                    HStack {
                        Text("Passcode")
                            .font(.system(size: 16))
                            .foregroundColor(.secondary)
                        
                        Spacer()
                        
                        Text(passcode)
                            .font(.system(size: 28, weight: .bold))
                            .foregroundColor(textColor)
                        
                        Button(action: copyPasscode) {
                            Text("Copy")
                                .font(.system(size: 16))
                                .foregroundColor(.blue)
                                .padding(.leading, 8)
                        }
                    }
                    .padding(.vertical, 8)
                    
                    // 进度条和倒计时 - 修复宽度抖动问题
                    VStack(spacing: 4) {
                        ZStack(alignment: .leading) {
                            // 背景条
                            Rectangle()
                                .fill(Color.gray.opacity(0.3))
                                .frame(height: 4)
                            
                            // 进度条 - 使用固定宽度的容器
                            Rectangle()
                                .fill(Color.blue)
                                .frame(width: CGFloat(timeRemaining) / 60.0 * 100.0, height: 4)
                                .animation(.linear, value: timeRemaining)
                        }
                        .frame(width: 100) // 固定宽度为100
                        .frame(maxWidth: .infinity, alignment: .center) // 居中显示
                        
                        Text("\(timeRemaining)s until refresh")
                            .font(.system(size: 14))
                            .foregroundColor(.secondary)
                            .frame(maxWidth: .infinity, alignment: .center)
                    }
                }
                .padding(.vertical, 8)
                .padding(.horizontal, 4)
                .background(Color(.systemGray6).opacity(0.5))
                .cornerRadius(8)
                // 联系方式
                HStack {
                    Image(systemName: "envelope.fill")
                        .font(.system(size: 12))
                        .foregroundColor(.secondary)
                    
                    Text("contact@\(clinic.name.lowercased().replacingOccurrences(of: " ", with: "")).com")
                        .font(.system(size: 14))
                        .foregroundColor(.blue)
                    
                    Spacer()
                }
                
                // 查看详情按钮
                Button(action: onDetail) {
                    Text("View Details")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                        .background(Color.blue)
                        .cornerRadius(8)
                }
                .padding(.top, 4)
            }
        }
        .padding(16)
        .background(Color(.secondarySystemBackground))
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 2, x: 0, y: 1)
        .onAppear {
            if isExpanded {
                startTimer()
            }
        }
        .onChange(of: isExpanded) { expanded in
            if expanded {
                startTimer()
            } else {
                stopTimer()
            }
        }
    }
     // 启动计时器
    private func startTimer() {
        passcode = generatePasscode()
        timeRemaining = 60
        timer = Timer.publish(every: 1, on: .main, in: .common)
        timerCancellable = timer.connect()
        
        // 订阅计时器事件
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            if timeRemaining > 0 {
                timeRemaining -= 1
            } else {
                // 重新生成密码
                passcode = generatePasscode()
                timeRemaining = 60
            }
        }
    }
    
    // 停止计时器
    private func stopTimer() {
        timerCancellable?.cancel()
    }
}

// 新增：授权确认视图作为独立组件
struct AuthorizationConfirmationView: View {
    let clinic: Clinic
    let onApprove: () -> Void
    let onDeny: () -> Void
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        VStack(spacing: 20) {
            // 医院Logo - 使用诊所名称首字母作为Logo
            ZStack {
                Rectangle()
                    .fill(Color.gray.opacity(0.1))
                    .frame(height: 60)
                
                if let firstChar = clinic.name.first {
                    Text(String(firstChar))
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.secondary)
                } else {
                    Text("YOUR LOGO HERE")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.secondary)
                }
            }
            .frame(width: 120)
            .cornerRadius(8)
            .padding(.top, 30)
            
            // 确认文案 - 使用诊所名称
            Text("Are you authorizing your data to \(clinic.name)?")
                .font(.system(size: 20, weight: .semibold))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 20)
                .padding(.top, 10)
            
            // 用户信息 - 包含诊所地址
            VStack(spacing: 16) {
                infoRow(icon: "mappin.circle.fill", text: clinic.address)
                infoRow(icon: "clock.fill", text: clinic.businessHours)
                infoRow(icon: "desktopcomputer", text: "Browser")
                infoRow(icon: "person.fill", text: clinic.doctorName)
                infoRow(icon: "envelope.fill", text: clinic.email)
                infoRow(icon: "phone.fill", text: clinic.phone)
            }
            .padding(.vertical, 20)
            
            // 按钮
            HStack(spacing: 40) {
                // 拒绝按钮
                Button(action: onDeny) {
                    VStack {
                        Circle()
                            .fill(Color.red)
                            .frame(width: 60, height: 60)
                            .overlay(
                                Image(systemName: "xmark")
                                    .font(.system(size: 24, weight: .bold))
                                    .foregroundColor(.white)
                            )
                        
                        Text("Deny")
                            .font(.system(size: 16))
                            .foregroundColor(.red)
                            .padding(.top, 8)
                    }
                }
                
                // 确认按钮
                Button(action: onApprove) {
                    VStack {
                        Circle()
                            .fill(Color.green)
                            .frame(width: 60, height: 60)
                            .overlay(
                                Image(systemName: "checkmark")
                                    .font(.system(size: 24, weight: .bold))
                                    .foregroundColor(.white)
                            )
                        
                        Text("Approve")
                            .font(.system(size: 16))
                            .foregroundColor(.green)
                            .padding(.top, 8)
                    }
                }
            }
            .padding(.bottom, 40)
            
            Spacer()
        }
        .frame(maxWidth: .infinity)
        .background(colorScheme == .dark ? Color(.systemBackground) : Color(.systemBackground))
    }
    
    private func infoRow(icon: String, text: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 16))
                .foregroundColor(.secondary)
                .frame(width: 24)
            
            Text(text)
                .font(.system(size: 16))
                .foregroundColor(colorScheme == .dark ? .white : .black)
            
            Spacer()
        }
        .padding(.horizontal, 30)
    }
}
